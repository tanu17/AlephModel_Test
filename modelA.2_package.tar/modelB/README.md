# Model B — reference implementation and validation

Model B repairs the errors found in Model A (E1–E9) and the ten priority fixes, and validates the
result against FlyWire, Allen Neuropixels and MICrONS data. The specification and results are in the
companion document "Model B: Repaired Specification and Validation".

## Layout
- `modelb/core.py` — the model (rate network with Na+-debt energy ledger, energy-aware homeostasis,
  supply domains with blood flow, exact energy barrier with eviction, tag + energy-gated capture, sleep maps)
- `tests_structural.py` — conservation, ischaemia/controller test, energy barrier and eviction, sleep-map Lipschitz
- `benchmarks.py`, `bench_fix.py` — Padamsey 2022, Plaçais & Preat 2013, spacing, sleep downscaling,
  forgetting, CBF/CMRO2, energy per neuron (run benchmarks.py first; bench_fix.py supersedes B1, B2, B5)
- `validate_fly.py` — FlyWire scale, energy per synapse, Kenyon-cell in-degree, distance rule, reciprocity
- `validate_fly_kc.py` — odor coding on the real PN→KC and KC↔APL wiring
- `validate_mouse.py` — Allen rate distributions vs energy-sustainable band; MICrONS motif statistics
- `sensitivity.py` — Morris screening of the energy core
- `results/` — JSON outputs used in the document

## Run
    pip install numpy scipy pandas pyarrow networkx SALib
    ./get_data.sh
    python3 tests_structural.py && python3 benchmarks.py && python3 bench_fix.py
    python3 validate_fly.py && python3 validate_fly_kc.py && python3 validate_mouse.py && python3 sensitivity.py

Total run time is about 45 minutes on one CPU. Slow processes (homeostasis, capture, sleep) are
time-compressed; units are normalised as described in `modelb/core.py`.

## Data notes
Raw Allen (S3/DANDI) and MICrONS (CAVE/BossDB) downloads were not reachable from the build environment,
so mouse validation uses the summary tables those projects published on GitHub. The Attwell & Laughlin
2001 ATP figures in `benchmarks.py` should be checked against the paper.
