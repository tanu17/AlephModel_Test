import json, numpy as np
from modelb.core import ModelB
import benchmarks_lib as bl
R = json.load(open('results/benchmarks.json'))

# B1 rerun with wider threshold range so the fed state sits at its set point
m, pref, rng = bl.tuning_net(params=dict(tau_th=40.0, th_min=-4.0)); m.p['J0'] *= 2.5
bl.run_block(m, pref, 900); fed = bl.run_block(m, pref, 80, measure=True)
m.G = 0.71; bl.run_block(m, pref, 1200); fr = bl.run_block(m, pref, 80, measure=True)
m2, pref2, _ = bl.tuning_net(params=dict(tau_th=40.0, th_min=-4.0)); m2.p['J0'] *= 2.5
bl.run_block(m2, pref2, 900); m2.G = 0.71; m2.p['tau_th'] = 1e12; ac = bl.run_block(m2, pref2, 80, measure=True)
wf, of = bl.tuning_width(fed['tc']); wr, orr = bl.tuning_width(fr['tc']); wa, oa = bl.tuning_width(ac['tc'])
R['B1_padamsey'] = dict(G=0.71,
    synaptic_ATP_change_pct=100*(fr['syn_ATP_rate']/fed['syn_ATP_rate']-1),
    total_ATP_change_pct=100*(fr['total_ATP_rate']/fed['total_ATP_rate']-1),
    mean_rate_fed=float(fed['tc'].mean()), mean_rate_restricted=float(fr['tc'].mean()),
    mean_rate_acute_no_homeostasis=float(ac['tc'].mean()),
    halfwidth_fed_deg=wf, halfwidth_restricted_deg=wr, halfwidth_acute_deg=wa,
    OSI_fed=of, OSI_restricted=orr, OSI_acute=oa,
    e_fed=None,
    target=dict(synaptic_ATP_change_pct=-29, rate='preserved', tuning='broader, lower precision'))
print('B1', json.dumps(R['B1_padamsey'], default=float))

# B2 starvation and spacing
def ltm(eQ_level, schedule, N=40, seed=5, T_ret=1000.0):
    rng = np.random.default_rng(seed)
    W0 = (rng.random((N, N)) < 0.5) * 0.1
    m = ModelB(N, np.zeros(N, int), np.ones(N), W0,
               params=dict(tau_w=2.0, gam_dec=0.01, tau_Om=60.0, kap_Om=8.0, tau_c=120.0, gam_c=0.0, c_dep=0.05))
    m.plastic = m.W > 0
    pat = (rng.random(N) < 0.3).astype(float) * 20
    mk = np.outer(pat > 0, pat > 0) & m.plastic
    dt = 0.05
    def advance(T, learn):
        for t in range(int(T / dt)):
            m.eQ[:] = eQ_level; m.DAp = 1.0 if learn else 0.0
            r = pat if learn else np.zeros(N)
            m.W = np.clip(m.W + dt * m.plasticity_rate(r), 0, 1); m.update_tags(dt, r)
    for (T_on, T_off) in schedule:
        advance(T_on, True); advance(T_off, False)
    stm = m.W[mk].mean()
    advance(T_ret, False)
    return dict(STM_weight=float(stm), LTM_weight=float(m.W[mk].mean()), retention=float(m.W[mk].mean()/stm), c_mean=float(m.c[mk].mean()))
spaced = [(3.0, 60.0)] * 5; massed = [(15.0, 60.0)]
R['B2_starvation_LTM'] = dict(fed_spaced=ltm(0.85, spaced), starved_spaced=ltm(0.25, spaced),
                              fed_massed=ltm(0.85, massed),
                              target='starvation blocks LTM, STM intact (Placais & Preat 2013); spaced > massed (spacing effect, mitochondrial metabolism: Placais 2017; eLife 2024)')
print('B2', json.dumps(R['B2_starvation_LTM'], indent=0))

# B5 calibrate kap_N to the measured n
R['B5_nvc'] = [bl.nvc(k) for k in (0.5, 1.0, 1.4, 2.0)]
for d in R['B5_nvc']: print('B5', {k: round(float(v), 3) for k, v in d.items()})
json.dump(R, open('results/benchmarks.json', 'w'), indent=1, default=float)
