"""Benchmarks for Model B against published measurements (Section 7 of the evaluation)."""
import json, os, numpy as np
from modelb.core import ModelB

R = {}
os.makedirs('results', exist_ok=True)

# ---------------------------------------------------------------------------
# B1  Padamsey et al. 2022: food restriction -> synaptic ATP -29%, rate kept,
#     tuning broader.  Model: systemic gain G scales all synaptic conductances
#     (feedforward and recurrent) and their Na+ load; homeostasis restores rate.
# ---------------------------------------------------------------------------
def tuning_net(seed=2, N=120):
    rng = np.random.default_rng(seed)
    sign = np.where(rng.random(N) < 0.8, 1, -1)
    W = (rng.random((N, N)) < 0.1) * rng.uniform(0.5, 1.5, (N, N)) * np.where(sign[None, :] > 0, 0.03, 0.2)
    m = ModelB(N, np.repeat(np.arange(4), N // 4), sign, W, seed=seed, params=dict(tau_th=40.0))
    pref = rng.uniform(0, np.pi, N)
    return m, pref, rng

def ff_input(pref, ori, b=0.9, A=1.6, kap=2.0):
    return b + A * np.exp(kap * (np.cos(2 * (ori - pref)) - 1))

def run_block(m, pref, T, dt=0.002, oris=np.linspace(0, np.pi, 8, endpoint=False), measure=False):
    """cycle orientations (0.5 s each); return tuning curves and ATP rates."""
    nsteps = int(T / dt); seg = int(0.5 / dt)
    tc = np.zeros((len(oris), m.N)); cnt = np.zeros(len(oris))
    e0 = m.ledger['consumed']; s0 = m.syn_cost_acc
    for t in range(nsteps):
        k = (t // seg) % len(oris)
        r = m.step(dt, 0.0, I_syn=ff_input(pref, oris[k]))
        if measure and (t % seg) > seg // 2:
            tc[k] += r; cnt[k] += 1
    out = dict(total_ATP_rate=(m.ledger['consumed'] - e0) / T, syn_ATP_rate=(m.syn_cost_acc - s0) / T)
    if measure:
        tc /= cnt[:, None]; out['tc'] = tc
    return out

def tuning_width(tc):
    """half-width at half max (deg) averaged over responsive cells, aligned to peak."""
    nO = tc.shape[0]; widths = []; osis = []
    angles = np.linspace(0, 180, nO, endpoint=False)
    for i in range(tc.shape[1]):
        c = tc[:, i]
        if c.max() < 0.5: continue
        base = c.min(); amp = c.max() - base
        frac_above = (c - base > amp / 2).sum() / nO
        widths.append(frac_above * 180 / 2)
        z = (c * np.exp(2j * np.deg2rad(angles))).sum() / c.sum()
        osis.append(abs(z))
    return float(np.mean(widths)), float(np.mean(osis))

m, pref, rng = tuning_net()
run_block(m, pref, 600)                       # equilibrate fed
fed = run_block(m, pref, 80, measure=True)
G_new = 0.71
m.G = G_new
run_block(m, pref, 900)                       # adapt
acute = None
fr = run_block(m, pref, 80, measure=True)
# acute (no homeostatic adaptation) reference: same G, thresholds frozen at fed values
m2, pref2, _ = tuning_net()
run_block(m2, pref2, 600); m2.G = G_new; m2.p['tau_th'] = 1e12
ac = run_block(m2, pref2, 80, measure=True)
wf, of = tuning_width(fed['tc']); wr, orr = tuning_width(fr['tc']); wa, oa = tuning_width(ac['tc'])
R['B1_padamsey'] = dict(
    G=G_new,
    synaptic_ATP_change_pct=100 * (fr['syn_ATP_rate'] / fed['syn_ATP_rate'] - 1),
    total_ATP_change_pct=100 * (fr['total_ATP_rate'] / fed['total_ATP_rate'] - 1),
    mean_rate_fed=float(fed['tc'].mean()), mean_rate_restricted=float(fr['tc'].mean()),
    mean_rate_acute_no_homeostasis=float(ac['tc'].mean()),
    halfwidth_fed_deg=wf, halfwidth_restricted_deg=wr,
    OSI_fed=of, OSI_restricted=orr,
    threshold_shift=float(m.th.mean()),
    target=dict(synaptic_ATP_change_pct=-29, rate='preserved', tuning='broader, lower precision'))
print('B1', json.dumps({k: v for k, v in R['B1_padamsey'].items()}, default=float))

# ---------------------------------------------------------------------------
# B2  Placais & Preat 2013: starvation disables costly long-term memory.
#     Plasticity subsystem with imposed activity; eQ clamped fed vs starved.
# ---------------------------------------------------------------------------
def ltm(eQ_level, N=40, seed=5, spaced=True):
    rng = np.random.default_rng(seed)
    W0 = (rng.random((N, N)) < 0.5) * 0.1
    m = ModelB(N, np.zeros(N, int), np.ones(N), W0,
               params=dict(tau_w=2.0, gam_dec=0.01, tau_Om=60.0, tau_c=200.0, gam_c=0.0005, c_dep=0.05))
    m.plastic = m.W > 0
    pat = (rng.random(N) < 0.3).astype(float) * 20
    mk = np.outer(pat > 0, pat > 0) & m.plastic
    base = m.W[mk].mean()
    dt = 0.05; trace = []
    def advance(T, r, learn):
        nonlocal trace
        for t in range(int(T / dt)):
            m.eQ[:] = eQ_level
            m.DAp = 1.0 if learn else 0.0
            if learn: m.W = np.clip(m.W + dt * m.plasticity_rate(r), 0, 1)
            else:     m.W = np.clip(m.W + dt * m.plasticity_rate(np.zeros(N)), 0, 1)
            m.update_tags(dt, r if learn else np.zeros(N))
            trace.append(m.W[mk].mean() - base)
    n_trials = 5 if spaced else 1
    for k in range(n_trials):
        advance(3.0, pat, True); advance(60.0 if spaced else 0.0, pat, False)
    stm = trace[-1]
    advance(3000.0, pat, False)          # long retention interval (time-compressed "24 h")
    return dict(STM_dW=float(stm), LTM_dW=float(trace[-1]), retention=float(trace[-1] / stm),
                c_mean=float(m.c[mk].mean()))
R['B2_starvation_LTM'] = dict(fed=ltm(0.85), starved=ltm(0.25),
                              target='starvation blocks long-term (protein-synthesis) memory; short-term memory intact')
print('B2', R['B2_starvation_LTM'])

# ---------------------------------------------------------------------------
# B3  Sleep downscaling (de Vivo 2017): ~18% mean ASI shrinkage, large synapses spared.
# ---------------------------------------------------------------------------
rng = np.random.default_rng(7)
W = rng.lognormal(np.log(0.25), 0.6, 20000); W = np.clip(W, 0, 1)
# tags/capture accumulate on strongly potentiated synapses: P rises with size
P = 1 / (1 + np.exp(-(W - np.quantile(W, 0.8)) / 0.04))
for delta in [0.20, 0.22, 0.25]:
    Wn = W * (1 - delta * (1 - P))
    q = np.quantile(W, [0, 0.2, 0.4, 0.6, 0.8, 1.0])
    by_q = [float(100 * (1 - Wn[(W >= q[i]) & (W < q[i + 1])].mean() / W[(W >= q[i]) & (W < q[i + 1])].mean())) for i in range(5)]
    R.setdefault('B3_sleep', {})[f'delta={delta}'] = dict(mean_shrink_pct=float(100 * (1 - Wn.mean() / W.mean())),
                                                          shrink_by_size_quintile_pct=by_q)
R['B3_sleep']['target'] = '~18% mean ASI shrinkage; largest synapses spared'
print('B3', R['B3_sleep'])

# ---------------------------------------------------------------------------
# B4  Forgetting curves: heterogeneous consolidated-state lifetimes
# ---------------------------------------------------------------------------
t = np.logspace(0, 3, 40)
rng = np.random.default_rng(8)
a = 0.5
gam = (rng.random(200000) ** (1 / a)) * 1.0 + 1e-4       # density ~ gam^(a-1) on (0,1]
ret_pl = np.array([np.exp(-gam * ti).mean() for ti in t])
ret_ex = np.exp(-0.05 * t)
sl = np.polyfit(np.log(t[10:]), np.log(ret_pl[10:]), 1)[0]
R['B4_forgetting'] = dict(powerlaw_slope=float(sl), lifetime_density_exponent=a,
                          single_lifetime='exponential (as v7.3 notes)',
                          target='power-law retention (Wixted & Ebbesen 1991); slope set by spine-lifetime distribution')
print('B4', R['B4_forgetting'])

# ---------------------------------------------------------------------------
# B5  Neurovascular coupling: CBF/CMRO2 ratio n (target 2-4, V1 2.45+/-0.42)
# ---------------------------------------------------------------------------
def nvc(kap_N=0.6, E0=0.4):
    rng = np.random.default_rng(1)
    N = 40; sign = np.where(rng.random(N) < 0.8, 1, -1)
    W = (rng.random((N, N)) < 0.1) * rng.uniform(0.5, 1.5, (N, N)) * np.where(sign[None, :] > 0, 0.03, 0.2)
    m = ModelB(N, np.zeros(N, int), sign, W, params=dict(kap_N=kap_N, E0=E0, tau_th=1e9))
    I0 = 0.9 + 0.2 * rng.standard_normal(N)
    for t in range(int(60 / 0.002)): m.step(0.002, 0.0, I_syn=I0)
    c0 = m.ledger['consumed'];
    for t in range(int(10 / 0.002)): m.step(0.002, 0.0, I_syn=I0)
    base_cmr = (m.ledger['consumed'] - c0) / 10; base_f = m.f.mean(); base_r = m.r.mean()
    for t in range(int(10 / 0.002)): m.step(0.002, 0.0, I_syn=I0 * 1.6)
    c1 = m.ledger['consumed']
    for t in range(int(10 / 0.002)): m.step(0.002, 0.0, I_syn=I0 * 1.6)
    stim_cmr = (m.ledger['consumed'] - c1) / 10
    dCBF = m.f.mean() / base_f - 1; dCMR = stim_cmr / base_cmr - 1
    # BOLD proxy: deoxyhaemoglobin ~ CMRO2 / CBF ; positive BOLD if it falls
    dHb = (1 + dCMR) / (1 + dCBF) - 1
    return dict(kap_N=kap_N, dCBF_pct=100 * dCBF, dCMRO2_pct=100 * dCMR, n=dCBF / dCMR,
                deoxyHb_change_pct=100 * dHb, rate_base=float(base_r), rate_stim=float(m.r.mean()))
R['B5_nvc'] = [nvc(k) for k in (0.3, 0.6, 1.0)]
R['B5_target'] = 'n = 2-4 (calibrated BOLD); V1 2.45 +/- 0.42 (Leontiev, Dubowitz & Buxton 2007)'
print('B5', R['B5_nvc'])

# ---------------------------------------------------------------------------
# B6  Energy per neuron (Herculano-Houzel 2011) from Model B cost structure
#     p = P_rest + r * (c_AP + c_syn_per_spike) with Attwell & Laughlin 2001 values
# ---------------------------------------------------------------------------
P_rest = 4.44e8; c_spike = 3.84e8 + 3.28e8     # ATP/s and ATP/spike (rodent, AL 2001)
ATP_per_glc = 31.0; NA = 6.022e23
def atp_to_glc_umol_min(atp_s): return atp_s / ATP_per_glc / NA * 60 * 1e6
pred = {r: atp_to_glc_umol_min(P_rest + r * c_spike) for r in (2, 4, 6, 8)}
obs_cortex = 1.50e-8; obs_sd = 0.49e-8
def glc_to_atp(g): return g / 1e6 / 60 * ATP_per_glc * NA
r_sust = (glc_to_atp(obs_cortex) - P_rest) / c_spike
r_lo = (glc_to_atp(obs_cortex - obs_sd) - P_rest) / c_spike
r_hi = (glc_to_atp(obs_cortex + obs_sd) - P_rest) / c_spike
hh = dict(mouse=5.20e-9, rat=6.10e-9, squirrel=7.05e-9, monkey=4.93e-9, baboon=6.00e-9, human=5.44e-9)
R['B6_energy_per_neuron'] = dict(
    predicted_cortical_glucose_umol_per_min=pred, observed_cortex=obs_cortex, observed_sd=obs_sd,
    sustainable_mean_rate_Hz=float(r_sust), sustainable_range_Hz=[float(r_lo), float(r_hi)],
    whole_brain_per_neuron_observed=hh,
    whole_brain_per_neuron_CV=float(np.std(list(hh.values())) / np.mean(list(hh.values()))),
    note='Model B predicts a fixed per-neuron budget because homeostasis pins mean rate (rho) and the CBF gate pins synaptic weight per neuron; total brain cost is then linear in N.')
print('B6', R['B6_energy_per_neuron'])

json.dump(R, open('results/benchmarks.json', 'w'), indent=1, default=float)
