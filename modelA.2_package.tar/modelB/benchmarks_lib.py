import json, os, numpy as np
from modelb.core import ModelB

R = {}
os.makedirs('results', exist_ok=True)

def tuning_net(seed=2, N=120, params=None):
    rng = np.random.default_rng(seed)
    sign = np.where(rng.random(N) < 0.8, 1, -1)
    W = (rng.random((N, N)) < 0.1) * rng.uniform(0.5, 1.5, (N, N)) * np.where(sign[None, :] > 0, 0.03, 0.2)
    m = ModelB(N, np.repeat(np.arange(4), N // 4), sign, W, seed=seed, params=params or dict(tau_th=40.0))
    pref = rng.uniform(0, np.pi, N)
    return m, pref, rng

def ff_input(pref, ori, b=0.9, A=1.6, kap=2.0):
    return b + A * np.exp(kap * (np.cos(2 * (ori - pref)) - 1))

def run_block(m, pref, T, dt=0.002, oris=np.linspace(0, np.pi, 8, endpoint=False), measure=False):
    """cycle orientations (0.5 s each); return tuning curves and ATP rates."""
    nsteps = int(T / dt); seg = int(0.5 / dt)
    tc = np.zeros((len(oris), m.N)); cnt = np.zeros(len(oris))
    e0 = m.ledger['consumed']; s0 = m.syn_cost_acc
    for t in range(nsteps):
        k = (t // seg) % len(oris)
        r = m.step(dt, 0.0, I_syn=ff_input(pref, oris[k]))
        if measure and (t % seg) > seg // 2:
            tc[k] += r; cnt[k] += 1
    out = dict(total_ATP_rate=(m.ledger['consumed'] - e0) / T, syn_ATP_rate=(m.syn_cost_acc - s0) / T)
    if measure:
        tc /= cnt[:, None]; out['tc'] = tc
    return out

def tuning_width(tc):
    """half-width at half max (deg) averaged over responsive cells, aligned to peak."""
    nO = tc.shape[0]; widths = []; osis = []
    angles = np.linspace(0, 180, nO, endpoint=False)
    for i in range(tc.shape[1]):
        c = tc[:, i]
        if c.max() < 0.5: continue
        base = c.min(); amp = c.max() - base
        frac_above = (c - base > amp / 2).sum() / nO
        widths.append(frac_above * 180 / 2)
        z = (c * np.exp(2j * np.deg2rad(angles))).sum() / c.sum()
        osis.append(abs(z))
    return float(np.mean(widths)), float(np.mean(osis))

def ltm(eQ_level, N=40, seed=5, spaced=True):
    rng = np.random.default_rng(seed)
    W0 = (rng.random((N, N)) < 0.5) * 0.1
    m = ModelB(N, np.zeros(N, int), np.ones(N), W0,
               params=dict(tau_w=2.0, gam_dec=0.01, tau_Om=60.0, tau_c=200.0, gam_c=0.0005, c_dep=0.05))
    m.plastic = m.W > 0
    pat = (rng.random(N) < 0.3).astype(float) * 20
    mk = np.outer(pat > 0, pat > 0) & m.plastic
    base = m.W[mk].mean()
    dt = 0.05; trace = []
    def advance(T, r, learn):
        nonlocal trace
        for t in range(int(T / dt)):
            m.eQ[:] = eQ_level
            m.DAp = 1.0 if learn else 0.0
            if learn: m.W = np.clip(m.W + dt * m.plasticity_rate(r), 0, 1)
            else:     m.W = np.clip(m.W + dt * m.plasticity_rate(np.zeros(N)), 0, 1)
            m.update_tags(dt, r if learn else np.zeros(N))
            trace.append(m.W[mk].mean() - base)
    n_trials = 5 if spaced else 1
    for k in range(n_trials):
        advance(3.0, pat, True); advance(60.0 if spaced else 0.0, pat, False)
    stm = trace[-1]
    advance(3000.0, pat, False)          # long retention interval (time-compressed "24 h")
    return dict(STM_dW=float(stm), LTM_dW=float(trace[-1]), retention=float(trace[-1] / stm),
                c_mean=float(m.c[mk].mean()))
def nvc(kap_N=0.6, E0=0.4):
    rng = np.random.default_rng(1)
    N = 40; sign = np.where(rng.random(N) < 0.8, 1, -1)
    W = (rng.random((N, N)) < 0.1) * rng.uniform(0.5, 1.5, (N, N)) * np.where(sign[None, :] > 0, 0.03, 0.2)
    m = ModelB(N, np.zeros(N, int), sign, W, params=dict(kap_N=kap_N, E0=E0, tau_th=1e9))
    I0 = 0.9 + 0.2 * rng.standard_normal(N)
    for t in range(int(60 / 0.002)): m.step(0.002, 0.0, I_syn=I0)
    c0 = m.ledger['consumed'];
    for t in range(int(10 / 0.002)): m.step(0.002, 0.0, I_syn=I0)
    base_cmr = (m.ledger['consumed'] - c0) / 10; base_f = m.f.mean(); base_r = m.r.mean()
    for t in range(int(10 / 0.002)): m.step(0.002, 0.0, I_syn=I0 * 1.6)
    c1 = m.ledger['consumed']
    for t in range(int(10 / 0.002)): m.step(0.002, 0.0, I_syn=I0 * 1.6)
    stim_cmr = (m.ledger['consumed'] - c1) / 10
    dCBF = m.f.mean() / base_f - 1; dCMR = stim_cmr / base_cmr - 1
    # BOLD proxy: deoxyhaemoglobin ~ CMRO2 / CBF ; positive BOLD if it falls
    dHb = (1 + dCMR) / (1 + dCBF) - 1
    return dict(kap_N=kap_N, dCBF_pct=100 * dCBF, dCMRO2_pct=100 * dCMR, n=dCBF / dCMR,
                deoxyHb_change_pct=100 * dHb, rate_base=float(base_r), rate_stim=float(m.r.mean()))
P_rest = 4.44e8; c_spike = 3.84e8 + 3.28e8     # ATP/s and ATP/spike (rodent, AL 2001)
ATP_per_glc = 31.0; NA = 6.022e23
def atp_to_glc_umol_min(atp_s): return atp_s / ATP_per_glc / NA * 60 * 1e6
def glc_to_atp(g): return g / 1e6 / 60 * ATP_per_glc * NA