#!/usr/bin/env bash
# Fetch the public data used for validation into /tmp/data (paths are hard-coded in validate_*.py)
set -e
mkdir -p /tmp/data && cd /tmp/data
git clone --depth 1 https://github.com/philshiu/Drosophila_brain_model.git fly            # FlyWire v783 connectivity
git clone --depth 1 https://github.com/flyconnectome/flywire_annotations.git flyann       # FlyWire cell types
git clone --depth 1 https://github.com/AllenInstitute/neuropixels_platform_paper.git neuropixels_platform_paper
git clone --depth 1 https://github.com/AllenInstitute/MicronsBinder.git mb                 # MICrONS motif notebooks
