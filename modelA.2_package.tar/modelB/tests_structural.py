"""Structural tests of Model B: conservation, controller interaction, CBF, hybrid sleep."""
import json, numpy as np
from modelb.core import ModelB

def build(seed=1, N=80, gE=0.03, gI=0.2, p=0.1, nQ=4, params=None):
    rng = np.random.default_rng(seed)
    dom = np.repeat(np.arange(nQ), N // nQ); sign = np.where(rng.random(N) < 0.8, 1, -1)
    W = (rng.random((N, N)) < p) * rng.uniform(0.5, 1.5, (N, N))
    W *= np.where(sign[None, :] > 0, gE, gI)
    return ModelB(N, dom, sign, W, params=params, seed=seed), rng

import os
out = json.load(open('results/structural.json')) if os.path.exists('results/structural.json') else {}
RERUN_SLOW = not os.path.exists('results/structural.json')

# S1 conservation -----------------------------------------------------------
if RERUN_SLOW:
    m, rng = build(); I = 1.3 + 0.3 * rng.standard_normal(m.N)
    c0 = m.energy_content(); n0 = m.n.sum()
    for t in range(int(200 / 0.002)):
        m.step(0.002, I)
    L = m.ledger
    res_e = (m.energy_content() - c0) - (L['supply'] - L['consumed'])
    res_n = (m.n.sum() - n0) - (L['Na_in'] - L['pumped_Na'])
    out['S1_energy_residual_rel'] = float(res_e / L['consumed'])
    out['S1_Na_residual'] = float(res_n)
    out['S1_spike_energy_paid_fraction'] = float(L['pumped_Na'] / L['Na_in'])  # long-run -> 1
    print("S1", out['S1_energy_residual_rel'], out['S1_Na_residual'], out['S1_spike_energy_paid_fraction'])

    # S2 local ischemia: energy-aware vs fixed set point ---------------------------
    def ischemia(energy_aware, J_left=0.25, T_pre=300, T_post=600):
        m, rng = build(params=None if energy_aware else dict(e_h=1e-6))
        I = 1.3 + 0.3 * rng.standard_normal(m.N)
        for t in range(int(T_pre / 0.002)): m.step(0.002, I)
        base = dict(r=m.r[m.domain == 0].mean(), e=m.e[m.domain == 0].mean())
        m.J_scale[0] = J_left
        for t in range(int(T_post / 0.002)): m.step(0.002, I)
        d0 = m.domain == 0
        return dict(rate_before=float(base['r']), rate_after=float(m.r[d0].mean()),
                    e_before=float(base['e']), e_after=float(m.e[d0].mean()),
                    theta_after=float(m.th[d0].mean()),
                    frac_theta_at_min=float((m.th[d0] <= m.p['th_min'] + 1e-6).mean()),
                    Na_after=float(m.n[d0].mean()))
    out['S2_energy_aware'] = ischemia(True)
    out['S2_fixed_setpoint'] = ischemia(False)
    print("S2", json.dumps(out['S2_energy_aware']), "\n  ", json.dumps(out['S2_fixed_setpoint']))

# S3 CBF + matched eviction (plasticity subsystem, imposed activity patterns) --
def memories(psi, n_mem=30, N=60, seed=3):
    rng = np.random.default_rng(seed)
    W0 = (rng.random((N, N)) < 0.5) * 0.05
    m = ModelB(N, np.zeros(N, int), np.ones(N), W0, params=dict(gam_dec=0.0, tau_w=1.0, c_dep=0.02, tau_Om=2.0))
    m.plastic = m.W > 0
    Cmax = m.p['beta_w'] * m.plastic.sum() * 0.25 * m.p['w_max']   # budget: 25% of max total weight
    m.p['C_max'] = np.array([Cmax])
    m.DAp = 1.0; m.psi = psi
    pats = [(rng.random(N) < 0.15).astype(float) * 20 for _ in range(n_mem)]
    hmin = np.inf; h0 = m.headroom()[0]; learned_on_arrival = 0
    for k, rp in enumerate(pats):
        for t in range(400):
            dW = m.plasticity_rate(rp); m.W = np.clip(m.W + 0.01 * dW, 0, 1)
            m.update_tags(0.01, rp)
            hmin = min(hmin, m.headroom()[0])
        mk = np.outer(rp > 0, rp > 0) & m.plastic
        if m.W[mk].mean() > 2 * m.W[m.plastic & ~mk].mean(): learned_on_arrival += 1
        for t in range(300):                     # inter-trial interval: tags decay, no learning
            m.update_tags(0.01, np.zeros(N))
    # retrieval: each memory's synapses (co-active pairs) must exceed 2x mean weight of others
    ok = 0
    for rp in pats:
        mask = np.outer(rp > 0, rp > 0) & m.plastic
        if mask.sum() and m.W[mask].mean() > 2 * m.W[m.plastic & ~mask].mean():
            ok += 1
    last = pats[-1]; maskL = np.outer(last > 0, last > 0) & m.plastic
    return dict(h0=float(h0), h_min=float(hmin), h_never_negative=bool(hmin >= -1e-9), learned_on_arrival=learned_on_arrival,
                memories_retrievable=ok, latest_learned=bool(m.W[maskL].mean() > 2 * m.W[m.plastic & ~maskL].mean()))
out['S3_no_eviction'] = memories(0.0)
out['S3_eviction'] = memories(1.0)
print("S3", out['S3_no_eviction'], out['S3_eviction'])

# S4 hybrid sleep maps are non-expansive -------------------------------------
m, rng = build()
worst = 0.0
for trial in range(200):
    m.Om = rng.random((m.N, m.N)); m.c = rng.random((m.N, m.N)) * 0.5
    W1 = rng.random((m.N, m.N)) * m.plastic; W2 = np.clip(W1 + 0.05 * rng.standard_normal(W1.shape), 0, 1) * m.plastic
    def T(W):
        m.W = W.copy(); m.sws(); m.rem(); return m.W.copy()
    ratio = np.abs(T(W1) - T(W2)).max() / np.abs(W1 - W2).max()
    worst = max(worst, ratio)
out['S4_sleep_map_max_lipschitz'] = float(worst)
# S4b: away from the REM prune threshold (|W - w_p| > 0.1) the jump map is non-expansive
worst2 = 0.0
for trial in range(200):
    m.Om = rng.random((m.N, m.N)); m.c = rng.random((m.N, m.N)) * 0.5
    base = rng.choice([0.0, 1.0], size=(m.N, m.N)) * 0.0 + rng.uniform(0.3, 1.0, (m.N, m.N))
    W1 = base * m.plastic; W2 = np.clip(W1 + 0.02 * rng.standard_normal(W1.shape), 0.27, 1) * m.plastic
    def T(W):
        m.W = W.copy(); m.sws(); m.rem(); return m.W.copy()
    worst2 = max(worst2, np.abs(T(W1) - T(W2)).max() / np.abs(W1 - W2).max())
out['S4b_lipschitz_away_from_prune_threshold'] = float(worst2)
lip_bound = 1 + m.p['pi_rem'] * m.p['w_p'] / (4 * 0.02)
out['S4_analytic_bound_near_threshold'] = float(lip_bound)
print("S4", worst, "S4b", worst2, "bound", lip_bound)

json.dump(out, open('results/structural.json', 'w'), indent=1)
