"""Mushroom-body odor coding on the real FlyWire PN->KC and KC<->APL wiring, run with Model B's
rate function, homeostatic thresholds and systemic gain G.  Targets: 5-10% of KCs respond to an
odor; blocking APL broadens responses and raises inter-odor correlation (Lin et al. 2014)."""
import json, numpy as np, pandas as pd
from modelb.core import softplus

D = '/tmp/data/'
con = pd.read_parquet(D + 'fly/Connectivity_783.parquet')
ann = pd.read_csv(D + 'flyann/supplemental_files/Supplemental_file1_neuron_annotations.tsv', sep='\t', low_memory=False)
kc_ids = ann.loc[ann.cell_class == 'Kenyon_Cell', 'root_id'].values
pn = ann.loc[(ann.cell_class == 'ALPN') & (ann.cell_sub_class == 'uniglomerular'), ['root_id', 'cell_type']]
apl = ann.loc[ann.cell_type == 'APL', 'root_id'].values
glom = sorted(pn.cell_type.unique()); gidx = {g: i for i, g in enumerate(glom)}
pn_g = dict(zip(pn.root_id, pn.cell_type.map(gidx)))
kidx = {k: i for i, k in enumerate(kc_ids)}

# glomerulus -> KC weight matrix (synapse counts, >=3 synapses)
e = con[(con.Connectivity >= 3) & con.Presynaptic_ID.isin(pn_g) & con.Postsynaptic_ID.isin(kidx)]
Wgk = np.zeros((len(kc_ids), len(glom)))
np.add.at(Wgk, (e.Postsynaptic_ID.map(kidx).values, e.Presynaptic_ID.map(pn_g).values), e.Connectivity.values)
has_in = Wgk.sum(1) > 0
Wgk = Wgk[has_in]; kc_ids = kc_ids[has_in]; kidx = {k: i for i, k in enumerate(kc_ids)}
# APL <-> KC
a2k = con[con.Presynaptic_ID.isin(apl) & con.Postsynaptic_ID.isin(kidx)]
k2a = con[con.Presynaptic_ID.isin(kidx) & con.Postsynaptic_ID.isin(apl)]
w_ak = np.zeros(len(kc_ids)); np.add.at(w_ak, a2k.Postsynaptic_ID.map(kidx).values, a2k.Connectivity.values)
w_ka = np.zeros(len(kc_ids)); np.add.at(w_ka, k2a.Presynaptic_ID.map(kidx).values, k2a.Connectivity.values)
M = len(kc_ids)
Wgk /= Wgk.sum(1, keepdims=True).mean()          # mean total PN drive per KC = 1 per unit glom rate
w_ak /= w_ak.mean(); w_ka /= w_ka.sum()

r_max, rho_kc, r_on = 8.0, 0.3, 2.0             # KCs fire few spikes per odor (low max rate)             # KC rate scale, homeostatic target, response threshold

def odors(P, seed):
    rng = np.random.default_rng(seed)
    shared = (np.random.default_rng(12345).random(len(glom)) < 0.3) * 1.0     # glomeruli many odors share
    own = (rng.random((P, len(glom))) < 0.25) * rng.lognormal(0, 0.5, (P, len(glom)))
    return 0.6 * shared[None, :] * rng.lognormal(0, 0.3, (P, len(glom))) + own

def kc_resp(X, theta, G=1.0, gA=6.0, iters=60):
    h = G * X @ Wgk.T
    r = np.zeros_like(h); A = np.zeros((X.shape[0], 1))
    for _ in range(iters):
        sp = softplus(h - gA * A * w_ak[None, :] - theta[None, :])
        r_new = r_max * sp / (sp + 1)
        A_new = (r_new * w_ka[None, :]).sum(1, keepdims=True) / r_max
        r = 0.5 * r + 0.5 * r_new; A = 0.5 * A + 0.5 * A_new
    return r

def homeostasis(theta, G, gA, rounds=60, eta=0.05, seed=0):
    for k in range(rounds):
        r = kc_resp(odors(200, seed + k), theta, G, gA)
        theta = theta + eta * (r.mean(0) - rho_kc)
    return theta

def metrics(r, X):
    frac = (r > r_on).mean(1)
    def mean_corr(Y):
        Y = Y - Y.mean(1, keepdims=True); Y /= (np.linalg.norm(Y, axis=1, keepdims=True) + 1e-12)
        C = Y @ Y.T; iu = np.triu_indices(len(Y), 1); return float(C[iu].mean())
    return dict(frac_active_mean=float(frac.mean()), frac_active_sd=float(frac.std()),
                kc_interodor_corr=mean_corr(r), pn_interodor_corr=mean_corr(X))

R = dict(KCs=int(M), glomeruli=len(glom), APL_inputs_per_KC_mean=float(w_ak.mean()))
theta0 = homeostasis(np.zeros(M), 1.0, 6.0)
Xt = odors(300, 999)
R['control'] = metrics(kc_resp(Xt, theta0), Xt)
R['APL_blocked_acute'] = metrics(kc_resp(Xt, theta0, gA=0.0), Xt)
R['bound_T3_active_fraction_max'] = rho_kc / r_on
# systemic scarcity (G=0.7), thresholds re-adapted by homeostasis -> prediction
thetaG = homeostasis(theta0.copy(), 0.7, 6.0, seed=500)
R['starved_G0.7_adapted'] = metrics(kc_resp(Xt, thetaG, G=0.7), Xt)
R['target'] = '5-10% of KCs respond per odor; APL block -> less sparse, more correlated (Lin et al. 2014)'
print(json.dumps(R, indent=1))
json.dump(R, open('results/fly_kc.json', 'w'), indent=1)
