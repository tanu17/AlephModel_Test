"""Mouse validation of Model B.

M1  Allen Brain Observatory Visual Behavior Neuropixels (Siegle et al. 2021 repository data):
    baseline firing-rate distributions in 6 visual cortical areas + LGN/LP, compared with the
    energy-sustainable mean rate from Model B's cost structure (Section B6) and with the
    rate heterogeneity Model B produces.
M2  MICrONS layer-2/3 pyramidal subgraph (363 cells, 1,750 edges; MicronsBinder motif notebooks):
    reciprocity and clustering versus Erdos-Renyi and configuration nulls, compared with networks
    grown by Model B's budget-limited Hebbian plasticity on distance-limited potential synapses.
"""
import json, numpy as np, pandas as pd, networkx as nx
from scipy import stats
from modelb.core import ModelB

R = {}
# ------------------------------------------------------------------ M1 Allen rates
c = pd.read_csv('/tmp/data/neuropixels_platform_paper/data/change_modulation_data.csv')
B = json.load(open('results/benchmarks.json'))['B6_energy_per_neuron']
lo, hi = B['sustainable_range_Hz']
rows = {}
for area, g in c.groupby('Region'):
    r = g['Baseline Rate Passive'].values; r = r[np.isfinite(r) & (r > 0.05)]
    lr = np.log10(r)
    k2, p_norm = stats.normaltest(lr)
    ra = g['Baseline Rate Active'].values; ok = np.isfinite(ra) & np.isfinite(g['Baseline Rate Passive'].values)
    rows[area] = dict(n=int(len(r)), mean_Hz=float(r.mean()), median_Hz=float(np.median(r)),
                      log10_sd=float(lr.std()), log10_skew=float(stats.skew(lr)),
                      lognormal_normaltest_p=float(p_norm),
                      frac_above_sustainable_hi=float((r > hi).mean()),
                      active_over_passive_median=float(np.median(ra[ok] / np.maximum(g['Baseline Rate Passive'].values[ok], 0.05))))
R['M1_allen_rates'] = rows
ctx = c[c.Region.isin(['V1', 'LM', 'AL', 'RL', 'AM', 'PM'])]['Baseline Rate Passive'].values
ctx = ctx[np.isfinite(ctx) & (ctx > 0.05)]
R['M1_cortex_pooled'] = dict(n=int(len(ctx)), mean_Hz=float(ctx.mean()), median_Hz=float(np.median(ctx)),
                             log10_sd=float(np.log10(ctx).std()), sustainable_band_Hz=[lo, hi],
                             mean_within_band=bool(lo <= ctx.mean() <= hi))
print('M1', json.dumps(R['M1_cortex_pooled']))

# Model B rate heterogeneity: identical set points vs heterogeneous per-spike cost vs heterogeneous set points
def rate_spread(nu_sd=0.0, rho_sd=0.0, N=160, T=500, seed=4):
    rng = np.random.default_rng(seed)
    sign = np.where(rng.random(N) < 0.8, 1, -1)
    W = (rng.random((N, N)) < 0.1) * rng.uniform(0.5, 1.5, (N, N)) * np.where(sign[None, :] > 0, 0.03, 0.2)
    m = ModelB(N, np.repeat(np.arange(4), N // 4), sign, W, params=dict(th_min=-4.0))
    m.p['nu_spk'] = 0.18 * rng.lognormal(0, nu_sd, N)
    m.p['rho'] = 4.0 * rng.lognormal(-rho_sd**2 / 2, rho_sd, N)
    I = 1.3 + 0.3 * rng.standard_normal(N)
    acc = np.zeros(N); k = 0
    for t in range(int(T / 0.002)):
        r = m.step(0.002, I)
        if t * 0.002 > T - 100: acc += r; k += 1
    rr = acc / k; rr = rr[rr > 0.05]
    return dict(log10_sd=float(np.log10(rr).std()), mean_Hz=float(rr.mean()))
R['M1_modelB_rate_spread'] = dict(identical_setpoints=rate_spread(),
                                  cost_heterogeneity_sd06=rate_spread(nu_sd=0.6),
                                  setpoint_heterogeneity_sd10=rate_spread(rho_sd=1.0))
print('M1b', R['M1_modelB_rate_spread'])

# ------------------------------------------------------------------ M2 MICrONS motifs
OBS = dict(N=363, edges=1750, p=0.01331750452795154, bi_obs=31, bi_ER=11.652816, bi_CFG=22.574,
           clust_obs=0.09511077158135982, clust_ER=0.02645765312905113, clust_CFG=0.08517955789223566)

def motif_stats(A, n_cfg=30, seed=0):
    rng = np.random.default_rng(seed)
    G = nx.DiGraph(A); n = A.shape[0]; E = A.sum()
    p = E / (n * (n - 1))
    bi = int((A * A.T).sum() // 2); bi_er = p * p * n * (n - 1) / 2
    cl = nx.transitivity(G.to_undirected())
    kin = A.sum(0).astype(int); kout = A.sum(1).astype(int)
    bis, cls = [], []
    for s in range(n_cfg):
        H = nx.directed_configuration_model(kin.tolist(), kout.tolist(), seed=int(rng.integers(1e9)))
        H = nx.DiGraph(H); H.remove_edges_from(nx.selfloop_edges(H))
        Ah = nx.to_numpy_array(H, nodelist=range(n)) > 0
        bis.append((Ah & Ah.T).sum() / 2); cls.append(nx.transitivity(H.to_undirected()))
    return dict(p=float(p), bi=bi, bi_vs_ER=float(bi / bi_er), bi_vs_CFG=float(bi / np.mean(bis)),
                clust=float(cl), clust_vs_ER=float(cl / p / 2 if False else cl / (1 - (1 - p)**2)),
                clust_vs_CFG=float(cl / np.mean(cls)))

obs = dict(bi_vs_ER=OBS['bi_obs'] / OBS['bi_ER'], bi_vs_CFG=OBS['bi_obs'] / OBS['bi_CFG'],
           clust_vs_ER=OBS['clust_obs'] / OBS['clust_ER'], clust_vs_CFG=OBS['clust_obs'] / OBS['clust_CFG'])
R['M2_microns_observed'] = obs

def grow(mode, N=363, seed=1, lam=120.0, p0=0.12, samples=3000):
    rng = np.random.default_rng(seed)
    pos = rng.uniform(0, 250, (N, 2))                                 # um, ~L2/3 sheet patch
    d = np.linalg.norm(pos[:, None] - pos[None], axis=2)
    pot = (rng.random((N, N)) < p0 * np.exp(-d / lam)); np.fill_diagonal(pot, False)
    target = int(OBS['edges'])
    if mode == 'geometry_only':
        Wf = rng.random((N, N)) * pot
    else:
        pref = rng.uniform(0, np.pi, N); rf = rng.uniform(0, 250, (N, 2))
        m = ModelB(N, np.zeros(N, int), np.ones(N), pot * 0.05, params=dict(tau_w=1.0, gam_dec=0.002, c_dep=0.4))
        m.plastic = pot.copy(); m.DAp = 1.0
        m.p['C_max'] = np.array([m.p['beta_w'] * target * 0.6])      # budget ~ observed synapse number
        m.psi = 1.0 if mode == 'modelB_budget_eviction' else 0.0
        if mode == 'hebbian_no_budget': m.p['C_max'] = np.array([1e9])
        for t in range(samples):
            ori = rng.uniform(0, np.pi); loc = rng.uniform(0, 250, 2)
            r = 12 * np.exp(2 * (np.cos(2 * (ori - pref)) - 1)) * np.exp(-np.linalg.norm(rf - loc, axis=1)**2 / (2 * 80**2))
            r = r + rng.exponential(0.5, N)
            m.W = np.clip(m.W + 0.05 * m.plasticity_rate(r), 0, 1)
        Wf = m.W * pot
    thr = np.sort(Wf[pot])[::-1][target - 1]                          # keep the strongest synapses at observed density
    A = (Wf >= thr) & pot
    return motif_stats(A.astype(int))

R['M2_models'] = {mode: grow(mode) for mode in ('geometry_only', 'hebbian_no_budget', 'modelB_budget_eviction')}
print('M2 observed', obs); [print('M2', k, v) for k, v in R['M2_models'].items()]
json.dump(R, open('results/mouse.json', 'w'), indent=1)
