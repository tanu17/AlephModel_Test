# Model A.3 — species-resolved model (macaque, rat, zebrafish, fruit fly)

Naming: Model A (original) → Model A.2 (repaired; formerly "Model B") → Model A.3 (this package) → A.4 next.

## Layout
- `modela/core.py` — Model A.2 equations (class `ModelA2`; `ModelB` kept as an alias). A.3 reuses them unchanged.
- `modela/species.py` — species parameter vectors Θ_s with sources: neuron counts, cell-type censuses,
  transmitter types/counts, temperature, synapses per neuron, expansion layers, sleep.
- `a3_predictions.py` — Model A.3 laws and tests:
  L1 energy-per-neuron law (rat, macaque) · L2 expansion in-degree K* (all four) · L3 sleep law (mammals) ·
  L4 zebrafish single-neuron synapse dynamics (Suppermpool et al. 2024 data) · L5 temperature law (fly) ·
  L6 forgetting as barrier escape · L7 optogenetic actuators in the energy ledger · L8 lateralisation threshold
- `results/a3_predictions.json` — outputs used in the Model A.3 document
- `a2_validation/` — Model A.2 tests and validations (FlyWire, Allen, MICrONS, benchmarks) and their results

## Run
    pip install numpy scipy pandas pyarrow networkx SALib openpyxl
    ./get_data.sh                      # clones public data into /tmp/data
    PYTHONPATH=. python3 a3_predictions.py
    cd a2_validation && PYTHONPATH=.. python3 tests_structural.py   # etc.
