# Model A.3 — species-resolved model (macaque, rat, zebrafish, fruit fly)

Naming: Model A (original) → Model A.2 (repaired; formerly "Model B") → Model A.3 (this package) → A.4 next.

## Layout
- `modela/core.py` — Model A.2 equations (class `ModelA2`; `ModelB` kept as an alias). A.3 reuses them unchanged.
- `modela/species.py` — species parameter vectors Θ_s with sources: neuron counts, cell-type censuses,
  transmitter types/counts, temperature, synapses per neuron, expansion layers, sleep.
- `a3_predictions.py` — Model A.3 laws and tests:
  L1 energy-per-neuron law (rat, macaque) · L2 expansion in-degree K* (all four) · L3 sleep law (mammals) ·
  L4 zebrafish single-neuron synapse dynamics (Suppermpool et al. 2024 data) · L5 temperature law (fly) ·
  L6 forgetting as barrier escape · L7 optogenetic actuators in the energy ledger · L8 lateralisation threshold
- `results/a3_predictions.json` — outputs used in the Model A.3 document
- `a2_validation/` — Model A.2 tests and validations (FlyWire, Allen, MICrONS, benchmarks) and their results

## Run
    pip install numpy scipy pandas pyarrow networkx SALib openpyxl
    ./get_data.sh                      # clones public data into /tmp/data
    PYTHONPATH=. python3 a3_predictions.py
    cd a2_validation && PYTHONPATH=.. python3 tests_structural.py   # etc.

## Model A.4 validation (October 2026)

Scripts (run from this folder with `PYTHONPATH=.`; data via `get_data.sh`, plus the two mammal tables below):

| Script | What it tests | Output |
|---|---|---|
| a4_math_audit.py | Theorems 1, 3, 5; sleep-law derivative; avian ratio; Table 2; Table 1 arithmetic; ephaptic magnitude | results/a4_math.json |
| a4_zebrafish.py | sleep gate variants vs Suppermpool et al. 2024 (groups, drugs, per fish, LOO, regression to mean, lighting) | results/a4_zebrafish.json (about 30 min) |
| a4_sleep_law.py | sleep law on 58 mammals (Allison & Cicchetti), danger index | results/a4_sleep_law.json |
| a4_mouse.py | Allen rate distribution and state stability; MICrONS reciprocity under Hebbian and STDP growth | results/a4_mouse.json |
| a4_fly_theta.py | FlyWire KC global vs local APL; Eq. 23 precession; ChR2 f-I | results/a4_fly_theta.json |
| a4_figures.py | figures 1-6 | results/fig*.png |

Mammal tables: `curl -L -o /tmp/data/msleep/mammals.csv https://raw.githubusercontent.com/vincentarelbundock/Rdatasets/master/csv/openintro/mammals.csv`
