"""Morris elementary-effects screening of Model B's energy core (Colleague 2 lens).
Outputs: steady cellular ATP and rate ratio after supply is cut to 40%, and Na+ debt."""
import json, numpy as np
from SALib.sample import morris as ms
from SALib.analyze import morris as ma
from modela.core import ModelA2 as ModelB

problem = dict(num_vars=8, names=['gK_max', 'K_A', 'nu_spk', 'Pi_max', 'K_e', 'e_h', 'g_x', 'P0'],
               bounds=[[0.5, 3.0], [0.1, 0.4], [0.09, 0.36], [1.8, 7.2], [0.05, 0.3], [0.15, 0.45], [0.5, 4.0], [0.03, 0.12]])

def run(x, seed=4):
    rng = np.random.default_rng(seed); N = 24
    sign = np.where(rng.random(N) < 0.8, 1, -1)
    W = (rng.random((N, N)) < 0.15) * rng.uniform(0.5, 1.5, (N, N)) * np.where(sign[None, :] > 0, 0.03, 0.2)
    pr = dict(zip(problem['names'], x)); pr['tau_th'] = 20.0
    m = ModelB(N, np.zeros(N, int), sign, W, params=pr)
    I = 1.3 + 0.3 * rng.standard_normal(N)
    for t in range(int(60 / 0.005)): m.step(0.005, I)
    r0 = m.r.mean(); m.J_scale[:] = 0.4
    for t in range(int(80 / 0.005)): m.step(0.005, I)
    return [m.e.mean(), m.r.mean() / max(r0, 1e-6), m.n.mean()]

X = ms.sample(problem, N=7, num_levels=4, seed=1)
Y = np.array([run(x) for x in X])
out = {}
for j, name in enumerate(['ATP_under_ischemia', 'rate_ratio_ischemia', 'Na_debt']):
    S = ma.analyze(problem, X, Y[:, j], num_levels=4, seed=1)
    out[name] = {n: dict(mu_star=float(S['mu_star'][i]), sigma=float(S['sigma'][i])) for i, n in enumerate(problem['names'])}
    rank = sorted(out[name], key=lambda n: -out[name][n]['mu_star'])
    print(name, rank[:4])
json.dump(out, open('results/sensitivity.json', 'w'), indent=1)
