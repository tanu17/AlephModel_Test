"""Validation of Model B against the FlyWire v783 whole-brain connectome (Drosophila).

Data: Connectivity_783.parquet (Shiu et al. 2024 repository, FlyWire v783 synapse counts)
      Supplemental_file1_neuron_annotations.tsv (Schlegel et al. 2024, flywire_annotations)
"""
import json, numpy as np, pandas as pd
from scipy import stats

D = '/tmp/data/'
con = pd.read_parquet(D + 'fly/Connectivity_783.parquet')
ann = pd.read_csv(D + 'flyann/supplemental_files/Supplemental_file1_neuron_annotations.tsv', sep='\t', low_memory=False)
R = {}
THR = 5   # FlyWire convention: a connection needs >= 5 synapses

# ---------------------------------------------------------------- F1 scale and energy per synapse
tot_syn = int(con.Connectivity.sum())
strong = con[con.Connectivity >= THR]
neurons = np.union1d(con.Presynaptic_ID.unique(), con.Postsynaptic_ID.unique())
N = len(neurons)
R['F1_scale'] = dict(neurons_with_edges=int(N), total_synapses=tot_syn, edges_ge5=int(len(strong)),
                     mean_in_degree_ge5=float(len(strong) / N), density_ge5=float(len(strong) / (N * (N - 1))))
P_fly = (1.1e-6, 6e-6)                 # W; ex vivo 1.1 uW (Neville 2018 OCR) to ~6 uW in vivo
fW_fly = [p / tot_syn * 1e15 for p in P_fly]
# human: 20 W over 1.5e14 (neocortical, Pakkenberg et al.) to 1e15 (whole-brain upper estimates) synapses
fW_hum = [20 / 1e15 * 1e15, 20 / 1.5e14 * 1e15]
R['F1_energy_per_synapse_fW'] = dict(fly=fW_fly, human=fW_hum,
    overlap=bool(max(fW_fly[0], fW_hum[0]) <= min(fW_fly[1], fW_hum[1])))
print('F1', R['F1_scale'], R['F1_energy_per_synapse_fW'])

# ---------------------------------------------------------------- F2 Kenyon-cell in-degree (T43)
kc = set(ann.loc[ann.cell_class == 'Kenyon_Cell', 'root_id'])
pn = ann.loc[(ann.cell_class == 'ALPN') & (ann.cell_sub_class == 'uniglomerular'), ['root_id', 'cell_type']]
pn_ids = set(pn.root_id)
pk = strong[strong.Presynaptic_ID.isin(pn_ids) & strong.Postsynaptic_ID.isin(kc)]
indeg = pk.groupby('Postsynaptic_ID').Presynaptic_ID.nunique()
# glomerulus-level in-degree (several PNs share a glomerulus)
pk2 = pk.merge(pn, left_on='Presynaptic_ID', right_on='root_id')
glom_indeg = pk2.groupby('Postsynaptic_ID').cell_type.nunique()
n_glom = pn.cell_type.nunique()
R['F2_KC_indegree'] = dict(KCs_with_PN_input=int(len(indeg)), KCs_total=len(kc),
    mean_PN_inputs=float(indeg.mean()), median=float(indeg.median()),
    mean_glomerulus_inputs=float(glom_indeg.mean()),
    hist_1to15=[int((indeg == k).sum()) for k in range(1, 16)],
    n_uniglomerular_PN_types=int(n_glom), n_uniglomerular_PNs=len(pn_ids))
print('F2', R['F2_KC_indegree'])

# energy-normalised expansion dimension (Model B: each input synapse costs upkeep and current)
def expansion_dim(K, n_in=n_glom, M=2000, P=600, f=0.1, seed=0):
    rng = np.random.default_rng(seed)
    X = np.maximum(rng.standard_normal((P, n_in)), 0)            # rectified glomerular odor responses
    J = np.zeros((M, n_in))
    for i in range(M):
        J[i, rng.choice(n_in, K, replace=False)] = 1.0
    H = X @ J.T
    H = H - H.mean(0)                                             # per-KC threshold (homeostatic)
    thr = np.quantile(H, 1 - f, axis=0)                           # each KC active on fraction f of odors
    Y = np.maximum(H - thr, 0)
    C = np.cov(Y.T); ev = np.linalg.eigvalsh(C)
    return ev.sum()**2 / (ev**2).sum()
Ks = list(range(1, 21))
dims = np.array([np.mean([expansion_dim(k, seed=s) for s in range(2)]) for k in Ks])
opt = {}
for ratio in (0.0, 2.0, 5.0, 10.0, 20.0):       # c0/c_syn: fixed per-KC cost in units of per-input cost
    eff = dims / (ratio + np.array(Ks))
    opt[f'c0/c_syn={ratio}'] = Ks[int(np.argmax(eff if ratio > 0 else dims / np.array(Ks)))]
R['F2_expansion'] = dict(K=Ks, dimension=dims.tolist(), K_max_dimension=Ks[int(np.argmax(dims))],
                         K_opt_energy_normalised=opt)
print('F2b', R['F2_expansion']['K_max_dimension'], opt)

# ---------------------------------------------------------------- F3 distance rule (G4) and reciprocity
cen = ann[(ann.super_class == 'central') & ann.soma_x.notna()][['root_id', 'soma_x', 'soma_y', 'soma_z']].copy()
cen['x'] = cen.soma_x * 4e-3; cen['y'] = cen.soma_y * 4e-3; cen['z'] = cen.soma_z * 40e-3   # voxels -> um
ids = cen.root_id.values; pos = cen[['x', 'y', 'z']].values
idx = {r: i for i, r in enumerate(ids)}
sc = strong[strong.Presynaptic_ID.isin(idx) & strong.Postsynaptic_ID.isin(idx)]
pre = sc.Presynaptic_ID.map(idx).values; post = sc.Postsynaptic_ID.map(idx).values
n = len(ids)
d_edges = np.linalg.norm(pos[pre] - pos[post], axis=1)
rng = np.random.default_rng(0)
a = rng.integers(0, n, 3_000_000); b = rng.integers(0, n, 3_000_000); keep = a != b; a, b = a[keep], b[keep]
d_pairs = np.linalg.norm(pos[a] - pos[b], axis=1)
bins = np.arange(0, 500, 20)
h_e, _ = np.histogram(d_edges, bins); h_p, _ = np.histogram(d_pairs, bins)
p_conn = h_e / (h_p / len(d_pairs) * n * (n - 1))
mid = (bins[:-1] + bins[1:]) / 2
ok = (p_conn > 0) & (h_p > 100) & (mid > 30)
ex = stats.linregress(mid[ok], np.log(p_conn[ok]))
pw = stats.linregress(np.log(mid[ok]), np.log(p_conn[ok]))
R['F3_distance_rule'] = dict(central_neurons=int(n), edges=int(len(sc)),
    exp_decay_length_um=float(-1 / ex.slope), exp_R2=float(ex.rvalue**2), powerlaw_R2=float(pw.rvalue**2),
    p_by_distance=dict(zip([float(x) for x in mid[ok]], [float(x) for x in p_conn[ok]])))
print('F3', {k: v for k, v in R['F3_distance_rule'].items() if k != 'p_by_distance'})

# reciprocity among central-brain neurons
E = set(zip(pre.tolist(), post.tolist()))
recip = sum((j, i) in E for (i, j) in E) // 2
p = len(E) / (n * (n - 1))
er_exp = p * p * n * (n - 1) / 2
R['F3_reciprocity'] = dict(reciprocal_pairs=int(recip), ER_expected=float(er_exp), ratio_vs_ER=float(recip / er_exp))
print('F3b', R['F3_reciprocity'])
json.dump(R, open('/home/claude/modelB/results/fly_structure.json', 'w'), indent=1)

# configuration-model (degree-preserving) expectation for reciprocity
kout = np.bincount(pre, minlength=n).astype(float); kin = np.bincount(post, minlength=n).astype(float)
Etot = len(E); s = (kout * kin)
cfg_exp = (s.sum()**2 - (s**2).sum()) / (2 * Etot**2)
R['F3_reciprocity']['config_expected'] = float(cfg_exp)
R['F3_reciprocity']['ratio_vs_config'] = float(recip / cfg_exp)
# KC in-degree at weaker thresholds (claw counting is threshold-dependent)
for thr in (1, 3):
    w = con[(con.Connectivity >= thr) & con.Presynaptic_ID.isin(pn_ids) & con.Postsynaptic_ID.isin(kc)]
    R['F2_KC_indegree'][f'mean_PN_inputs_thr{thr}'] = float(w.groupby('Postsynaptic_ID').Presynaptic_ID.nunique().mean())
print('F3c', R['F3_reciprocity'], {k: v for k, v in R['F2_KC_indegree'].items() if 'thr' in k})
json.dump(R, open('/home/claude/modelB/results/fly_structure.json', 'w'), indent=1)
