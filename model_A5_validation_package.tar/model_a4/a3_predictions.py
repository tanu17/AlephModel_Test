"""Model A.3: species-resolved predictions.

L1  energy-per-neuron law and sustainable firing band (rat, macaque)
L2  expansion-layer in-degree K* (fly, zebrafish, rat, macaque)
L3  sleep law t_sleep / t_wake = kappa * B (mass-specific brain glucose use), mammals
L4  zebrafish single-neuron synapse dynamics across wake / sleep / deprivation (Suppermpool et al. 2024 data)
L5  temperature (Q10) law: fly energy per synapse vs mammal
L6  forgetting as escape from bistable capture states (condensate model): power-law exponent = D / mean barrier
L7  optogenetic actuators in the energy ledger (ChR2 vs light-driven pumps)
L8  lateralisation by autocatalytic symmetry breaking (Frank-type model)
"""
import json, os, numpy as np, pandas as pd
from scipy import stats
from modela.species import SPECIES, SLEEP_EXTRA
from modela.core import ModelA2

os.makedirs('results', exist_ok=True)
R = {}

# ------------------------------------------------------------------ L1 energy-per-neuron law
# c_n = P_rest + rho * (c_AP + k * c_glu),  Attwell & Laughlin 2001 rodent values
P_rest, c_AP, c_glu_8000 = 4.44e8, 3.84e8, 3.28e8
c_glu = c_glu_8000 / 8000                       # ATP per spike per synapse
ATP_per_glc, NA = 31.0, 6.022e23
def glc(atp): return atp / ATP_per_glc / NA * 60 * 1e6     # umol glucose / min
def atp(g): return g / 1e6 / 60 * ATP_per_glc * NA
def cost(k, rho=4.0): return P_rest + rho * (c_AP + k * c_glu)
L1 = {}
for sp in ('rat', 'macaque'):
    k = SPECIES[sp]['synapses_per_cortical_neuron']
    L1[sp] = dict(k=k, per_spike_ATP=c_AP + k * c_glu, cortical_neuron_glucose_at_4Hz=glc(cost(k)))
L1['predicted_ratio_macaque_over_rat'] = cost(6000) / cost(8000)
hh_rat, hh_mac = 6.10e-9, 4.93e-9
L1['measured_ratio_whole_brain_per_neuron'] = hh_mac / hh_rat
b = 1.50e-8
L1['sustainable_band_Hz'] = {sp: [(atp(b - 0.49e-8) - P_rest) / (c_AP + L1[sp]['k'] * c_glu),
                                  (atp(b + 0.49e-8) - P_rest) / (c_AP + L1[sp]['k'] * c_glu)] for sp in ('rat', 'macaque')}
R['L1_energy'] = L1
print('L1', json.dumps(L1, default=float, indent=0)[:600])

# ------------------------------------------------------------------ L2 expansion in-degree
def expansion_dim(K, n_in, M=2000, P=500, f=0.1, seed=0):
    rng = np.random.default_rng(seed)
    X = np.maximum(rng.standard_normal((P, n_in)), 0)
    J = np.zeros((M, n_in))
    for i in range(M):
        J[i, rng.choice(n_in, K, replace=False)] = 1.0
    H = X @ J.T; H = H - H.mean(0)
    Y = np.maximum(H - np.quantile(H, 1 - f, axis=0), 0)
    ev = np.linalg.eigvalsh(np.cov(Y.T))
    return ev.sum()**2 / (ev**2).sum()
Ks = list(range(1, 16))
L2 = {}
for label, n_in in (('fly KC (69 glomeruli)', 69), ('cerebellum, 200 mossy fibres', 200), ('cerebellum, 1000 mossy fibres', 1000)):
    dims = np.array([np.mean([expansion_dim(k, n_in, seed=s) for s in range(2)]) for k in Ks])
    ratio = 20.0                               # fixed per-cell cost / per-input cost (whole neuron vs one claw)
    eff = dims / (ratio + np.array(Ks))
    # K giving >= 95% of max dimension (plateau start)
    k95 = Ks[int(np.argmax(dims >= 0.95 * dims.max()))]
    L2[label] = dict(K_max_dimension=Ks[int(np.argmax(dims))], K_95pct_dimension=k95,
                     K_energy_optimum=Ks[int(np.argmax(eff))], dims=dims.round(1).tolist())
R['L2_expansion'] = dict(results=L2, measured={sp: SPECIES[sp]['expansion']['measured_K'] for sp in SPECIES})
print('L2', {k: (v['K_max_dimension'], v['K_95pct_dimension'], v['K_energy_optimum']) for k, v in L2.items()})

# ------------------------------------------------------------------ L3 sleep law
rows = {'rat': (0.68, 12.6), 'macaque': (0.36, 11.45)}
rows.update({k: (v['glucose'], v['sleep']) for k, v in SLEEP_EXTRA.items()})
ratio = {k: s / (24 - s) for k, (g, s) in rows.items()}
kappa = ratio['rat'] / rows['rat'][0]                          # calibrate on rat only
pred = {k: 24 * kappa * g / (1 + kappa * g) for k, (g, s) in rows.items()}
lg = np.log([rows[k][0] for k in rows]); lr = np.log([ratio[k] for k in rows])
fit = stats.linregress(lg, lr)
R['L3_sleep'] = dict(kappa=kappa, predicted_h=pred, measured_h={k: v[1] for k, v in rows.items()},
                     error_pct={k: 100 * (pred[k] / rows[k][1] - 1) for k in rows},
                     loglog_slope=fit.slope, loglog_slope_se=fit.stderr, loglog_r=fit.rvalue,
                     note='model predicts slope 1 if SWS restoration per unit capacity is species-invariant')
print('L3', {k: round(v, 1) for k, v in R['L3_sleep']['error_pct'].items()}, 'slope', round(fit.slope, 2), '+/-', round(fit.stderr, 2))

# ------------------------------------------------------------------ L4 zebrafish synapse dynamics
d = pd.read_excel('/tmp/data/zfsyn/Ext Figure8.xlsx', sheet_name='8c')
d = d[~d.Fish_ID.isin(['F8_1_210929_ON', 'F3R_20210922_ON', 'F1_20210811'])]   # as excluded by the authors' script
w = d.pivot_table(index=['Fish_ID', 'Condition'], columns='Time', values='Puncta').dropna().reset_index()
w['d1'] = w['dpf7_18'] - w['dpf7_13']; w['d2'] = w['dpf8_0'] - w['dpf7_18']
L4 = {}
for cond, g in w.groupby('Condition'):
    lr_ = stats.linregress(g.d1, g.d2)
    L4[cond] = dict(n=int(len(g)), mean_d1=float(g.d1.mean()), mean_d2=float(g.d2.mean()),
                    slope_d2_on_d1=float(lr_.slope), r=float(lr_.rvalue), p=float(lr_.pvalue))
# Model A.3 reduction of the barrier + SWS map to one neuron:
#   wake:  dS/dt = g                         (net potentiation-driven synapse gain)
#   sleep: dS/dt = -k * u(NE) * max(0, S - S_set)   (pressure = excess over set point)
# Calibrate k on control early night (ZT13-18, 5 h) assuming the day's gain D sets the excess.
day = pd.read_excel('/tmp/data/zfsyn/Figure1.xlsx', sheet_name='1gh')
day = day[day.Condition == 'LD'].pivot_table(index='Fish_ID', columns='time', values='Puncta')
D_rate = float(((day['ZT 10'] - day['ZT 0']) / 10).mean())        # synapses per hour during the day
D13 = D_rate * 13                                                 # excess at ZT13 relative to morning set point
loss_ctrl = -L4['Control']['mean_d1']                             # observed control loss ZT13-18
k5 = -np.log(1 - loss_ctrl / D13) / 5.0 if loss_ctrl < D13 else np.nan   # per hour
def sleep_loss(excess, hours): return excess * (1 - np.exp(-k5 * hours))
pred_ctrl_late = -sleep_loss(D13 - loss_ctrl, 6)
pred_sd_recovery = -sleep_loss(D13 + L4['SD']['mean_d1'], 6)
L4['model'] = dict(day_gain_per_h=D_rate, excess_at_ZT13=D13, k_per_h=float(k5),
                   predicted_control_late_night=float(pred_ctrl_late), observed_control_late_night=L4['Control']['mean_d2'],
                   predicted_SD_recovery=float(pred_sd_recovery), observed_SD_recovery=L4['SD']['mean_d2'],
                   predicted_individual_slope=float(-(1 - np.exp(-k5 * 6))))
R['L4_zebrafish'] = L4
print('L4', json.dumps(L4, indent=0, default=float)[:900])

# ------------------------------------------------------------------ L5 temperature law
Q10 = 2.3
f_fly = Q10 ** ((25 - 37) / 10)
mam = (20.0, 133.0)
R['L5_temperature'] = dict(Q10=Q10, factor_fly_vs_mammal=f_fly, predicted_fly_fW=[mam[0] * f_fly, mam[1] * f_fly],
                           measured_fly_fW=[1.1e-6 / 54.49e6 * 1e15, 6e-6 / 54.49e6 * 1e15],
                           zebrafish_factor=Q10 ** ((28.5 - 37) / 10))
print('L5', R['L5_temperature'])

# ------------------------------------------------------------------ L6 forgetting by escape from bistable capture
rng = np.random.default_rng(3)
D_noise = 1.0
out = {}
for mu in (2.0, 4.0):
    dU = rng.exponential(mu, 400_000)
    tau = np.exp(dU / D_noise)                                    # Kramers: tau = tau0 exp(dU/D), tau0 = 1
    t = np.logspace(1, 4, 25)
    surv = np.array([np.exp(-ti / tau).mean() for ti in t])
    out[f'mean_barrier={mu}'] = dict(predicted_exponent=D_noise / mu,
                                     fitted_exponent=float(-np.polyfit(np.log(t), np.log(surv), 1)[0]))
R['L6_forgetting_escape'] = out
print('L6', out)

# ------------------------------------------------------------------ L7 optogenetics in the energy ledger
def opto(mode, amp, T=120.0, dt=0.002, J=1.0):
    m = ModelA2(1, np.zeros(1, int), np.ones(1), np.zeros((1, 1)), params=dict(tau_th=1e9))
    m.p['J0'] *= J
    for t in range(int(20 / dt)): m.step(dt, 0.6)
    e0 = float(m.e[0]); rates = []
    for t in range(int(T / dt)):
        if mode == 'ChR2':      # cation channel: depolarising current that also loads Na+
            r = m.step(dt, 0.6, I_syn=np.array([amp]))
        else:                   # light-driven Cl- or H+ pump: hyperpolarising, no Na+ load, no ATP
            r = m.step(dt, 0.6 - amp)
        rates.append(r[0])
    return dict(rate_last10s=float(np.mean(rates[-int(10 / dt):])), rate_first1s=float(np.mean(rates[:int(1 / dt)])),
                ATP_before=e0, ATP_after=float(m.e[0]), Na_after=float(m.n[0]))
L7 = {f'ChR2 amp={a}': opto('ChR2', a) for a in (1.0, 2.0, 4.0)}
L7.update({f'ChR2 amp=4 supply 50%': opto('ChR2', 4.0, J=0.5)})
L7.update({f'pump-silencing amp={a}': opto('pump', a) for a in (1.0,)})
R['L7_optogenetics'] = L7
print('L7', json.dumps(L7, indent=0)[:800])

# ------------------------------------------------------------------ L8 lateralisation (Frank-type symmetry breaking)
def frank(a, c, bias=0.01, T=200, dt=0.01):
    xL, xR = 0.5 + bias, 0.5
    for _ in range(int(T / dt)):
        dL = xL * (a * (1 - xL) - c * xR); dR = xR * (a * (1 - xR) - c * xL)
        xL += dt * dL; xR += dt * dR
    return (xL - xR) / (xL + xR + 1e-12)
L8 = {f'cross-inhibition c={c}': float(frank(1.0, c)) for c in (0.5, 0.9, 1.1, 1.5)}
R['L8_lateralisation'] = dict(asymmetry_index=L8, threshold='symmetric state unstable when c > a (cross-inhibition exceeds self-limitation)')
print('L8', L8)

json.dump(R, open('results/a3_predictions.json', 'w'), indent=1, default=float)
