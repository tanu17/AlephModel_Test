"""Figures for the Model A.4 validation report (reads results/*.json)."""
import json, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False, 'figure.dpi': 150})
GREY, BLUE, RED, LIGHT = '#6b6b6b', '#1f5fa8', '#b5473a', '#bdbdbd'
J = lambda f: json.load(open(f'results/{f}'))

# ---------------------------------------------------------------- Fig 1 zebrafish
z = J('a4_zebrafish.json'); t = z['targets']; F = z['gate_fits']
order = ['control ZT13-18', 'control ZT18-24', 'SD recovery ZT18-24', 'DMSO', 'Melatonin', 'Clonidine',
         'Chloro_adenosine', 'Chloro2adenosine_melatonin', 'Chloroadenosine_Clonidine']
lab = ['Ctrl\nZT13-18', 'Ctrl\nZT18-24', 'SD rec.\nZT18-24', 'DMSO', 'Mel', 'Clon', '2ClAdo', '2ClAdo\n+Mel', '2ClAdo\n+Clon']
fig, axs = plt.subplots(1, 2, figsize=(11, 4.2), gridspec_kw=dict(width_ratios=[1.0, 2.2]))
for ax, sl, ttl in ((axs[0], slice(0, 3), 'Night protocol (synapses per period)'), (axs[1], slice(3, 9), 'Daytime drugs ZT3-10 (synapses per hour)')):
    ks = order[sl]; x = np.arange(len(ks))
    ax.errorbar(x, [t[k]['mean'] for k in ks], yerr=[t[k]['sem'] for k in ks], fmt='o', color='k', capsize=3, label='observed ± SEM', zorder=5)
    for dx, g, c, mk, nm in ((-0.22, 'A3', LIGHT, 's', 'A.3 (no gate)'), (0.0, 'Ado', GREY, 'D', 'Ado gate only'), (0.22, 'A4', BLUE, '^', 'A.4 Ado × NE gate')):
        ax.plot(x + dx, [F[g]['fitted'][k] for k in ks], mk, color=c, ms=7, label=f"{nm}  χ²={F[g]['chi2']:.1f}, LOO z-RMSE={F[g]['loo_rmse_z']:.2f}")
    ax.axhline(0, color=LIGHT, lw=0.8); ax.set_xticks(x); ax.set_xticklabels(lab[sl]); ax.set_title(ttl, fontsize=10)
axs[0].set_ylabel('change in synapse number')
axs[1].legend(fontsize=8, frameon=False, loc='lower left')
fig.suptitle('Zebrafish: the A.4 gate fits group means best (χ² 4.6 on 9 targets) but an adenosine-only gate predicts held-out conditions better', fontsize=10.5)
fig.tight_layout(); fig.savefig('results/fig1_zebrafish_groups.png'); plt.close()

# per-fish
D = '/tmp/data/zfsyn/'
a = pd.read_excel(D + 'Figure3.xlsx', sheet_name='3c_firstsleep'); b = pd.read_excel(D + 'Figure3.xlsx', sheet_name='3c_lattersleep')
pf = z['per_fish_sleep_vs_change']
fig, axs = plt.subplots(1, 3, figsize=(11, 3.6), sharey=False)
panels = [('Control', a[(a.Cluster != 0) & (a.Condition == 'Control')].dropna(subset=['punc_hr4h']), 'sleepph_adjusted_exp', 'punc_hr4h', 'Control first 4 h', 'Control early night (ZT14-18)'),
          ('SD', a[(a.Cluster != 0) & (a.Condition == 'SD')].dropna(subset=['punc_hr4h']), 'sleepph_adjusted_exp', 'punc_hr4h', 'SD first 4 h', 'Sleep-deprived, recovery (ZT18-22)'),
          ('late', b[b.Cluster != 0].dropna(subset=['late_sleepph_adjusted_exp', 'punc_ZT18_0']), 'late_sleepph_adjusted_exp', 'punc_ZT18_0', 'Control late night', 'Control late night (ZT18-24)')]
for ax, (c, g, xc, yc, key, ttl) in zip(axs, panels):
    ax.scatter(g[xc], g[yc], s=18, color='k', zorder=5)
    xs = np.linspace(g[xc].min(), g[xc].max(), 10); xm, ym = g[xc].mean(), g[yc].mean()
    obs_key = {'Control first 4 h': 'Control first 4 h of sleep', 'SD first 4 h': 'SD first 4 h of sleep', 'Control late night': 'Control late night ZT18-24'}[key]
    so = pf[obs_key]['slope_per_min_per_h']
    ax.plot(xs, ym + so * (xs - xm), color='k', lw=1.5, label=f"data slope {so:+.3f} (r={pf[obs_key]['r']:.2f})")
    for g_, col in (('A3', LIGHT), ('A4', BLUE)):
        s_ = pf[f'model_{g_}'][key]['predicted_slope']
        ax.plot(xs, ym + s_ * (xs - xm), color=col, lw=1.5, ls='--', label=f"{'A.3' if g_=='A3' else 'A.4'} slope {s_:+.3f}")
    ax.set_title(ttl, fontsize=9.5); ax.set_xlabel('sleep (min per h)'); ax.legend(fontsize=7.5, frameon=False)
axs[0].set_ylabel('synapse change per h')
fig.suptitle('Per fish: more sleep means more loss early and late in control fish; A.4 predicts no dependence in either window', fontsize=10.5)
fig.tight_layout(); fig.savefig('results/fig2_zebrafish_per_fish.png'); plt.close()

# ---------------------------------------------------------------- Fig 3 sleep law
s = J('a4_sleep_law.json'); mm = pd.read_csv('results/a4_sleep_law_mammals.csv')
fig, axs = plt.subplots(1, 2, figsize=(11, 4.2))
ax = axs[0]
sc = ax.scatter(mm.brain_wt, mm.total_sleep, c=mm.danger, cmap='Greys', vmin=0, vmax=5.5, edgecolor='k', lw=0.4, s=28, zorder=5)
xs = np.logspace(-2, 4, 100); kap = s['S1_six_species']['kappa']
for bb, ls in ((-0.127, '-'), (-0.15, '--')):
    B = 0.68 * (xs / 1.802)**bb; ax.plot(xs, 24 * kap * B / (1 + kap * B), color=BLUE, ls=ls, lw=1.6, label=f'A.3/A.4 law, κ from rat only, b={bb}')
r2 = s['S2_62_mammals']['b=-0.15 (Karbowski 2007)']['R2_vs_mean']; r2f = s['S2_62_mammals']['free_fit_upper_bound']['R2_vs_mean']
ax.set_xscale('log'); ax.set_xlabel('brain mass (g)'); ax.set_ylabel('total sleep (h/day)')
ax.set_title(f'58 mammals (Allison & Cicchetti): out-of-sample R² = {r2:.2f} (best free fit {r2f:.2f})', fontsize=9.5)
ax.legend(fontsize=8, frameon=False); plt.colorbar(sc, ax=ax, label='danger index (1-5)')
ax = axs[1]
kap = s['S1_six_species']['kappa']
B = 0.68 * (mm.brain_wt / 1.802)**-0.127
res = np.log(mm.total_sleep / (24 - mm.total_sleep)) - np.log(kap * B)
ax.scatter(mm.danger + np.random.default_rng(0).uniform(-0.12, 0.12, len(mm)), res, color=GREY, s=20)
d3 = s['S3_ecological_factor']; xs = np.linspace(1, 5, 10)
ax.plot(xs, res.mean() + d3['danger_slope_on_residual'] * (xs - mm.danger.mean()), color=BLUE, lw=2,
        label=f"slope {d3['danger_slope_on_residual']:.2f} ± {d3['se']:.2f} per level, p = {d3['p']:.1e}")
ax.axhline(0, color=LIGHT); ax.set_xlabel('danger index (predation × sleep exposure)'); ax.set_ylabel('ln(sleep/wake) residual from the law')
ax.set_title("A.4's ecological factor: residuals fall with danger (R² 0.30 → 0.57 with it)", fontsize=9.5); ax.legend(fontsize=8, frameon=False)
fig.tight_layout(); fig.savefig('results/fig3_sleep_law.png'); plt.close()

# ---------------------------------------------------------------- Fig 4 energy / avian
mth = J('a4_math.json')
P_rest, c_AP, c_glu = 4.44e8, 3.84e8, 3.28e8 / 8000
cost = lambda k, area=1.0, rho=4.0: area * (P_rest + rho * c_AP) + rho * k * c_glu
ks = np.linspace(0, 10000, 200)
fig, axs = plt.subplots(1, 2, figsize=(11, 3.9))
ax = axs[0]
ax.plot(ks, cost(ks) / cost(8000), color=GREY, lw=2, label='linear cost law, same cell size and rate')
ax.plot(ks, cost(ks, mth['M6_avian']['membrane_area_factor_needed_with_k1800']) / cost(8000), color=BLUE, lw=2,
        label=f"membrane-area cost × {mth['M6_avian']['membrane_area_factor_needed_with_k1800']:.2f}")
ax.axhline(0.32, color='k', ls=':', lw=1); ax.text(200, 0.34, 'pigeon / mammal measured 0.32 (von Eugen 2022)', fontsize=8)
ax.axvline(1800, color=RED, lw=1); ax.text(1900, 0.9, 'A.4 k = 1,800\n(no source found)', fontsize=8, color=RED)
ax.plot([1800], [mth['M6_avian']['ratio_k1800_same_rate']], 'o', color=GREY); ax.text(2000, mth['M6_avian']['ratio_k1800_same_rate'] - 0.06, f"{mth['M6_avian']['ratio_k1800_same_rate']:.2f}, not 0.32", fontsize=8)
ax.set_xlabel('synapses per neuron, k'); ax.set_ylabel('cost per neuron relative to rodent (k=8,000)'); ax.set_ylim(0, 1.1)
ax.set_title('Avian "1/3 glucose" claim: synapse number alone cannot reach 0.32', fontsize=9.5); ax.legend(fontsize=8, frameon=False, loc='lower right')
ax = axs[1]
t2 = mth['M7_table2_consistency']; sp = ['fly', 'zebrafish', 'rat', 'macaque', 'pigeon']
tv = [t2[k]['table_value'] for k in sp]
ov = [np.mean(t2[k]['from_table_inputs']) if isinstance(t2[k]['from_table_inputs'], list) else t2[k]['from_table_inputs'] for k in sp]
x = np.arange(len(sp))
ax.scatter(x, tv, color=RED, marker='x', s=50, label='A.4 Table 2 value', zorder=5)
ax.scatter(x, ov, color=BLUE, s=30, label="recomputed from Table 2's own totals", zorder=5)
for i, k in enumerate(sp): ax.text(i + 0.08, ov[i], f'{ov[i]/tv[i]:.1f}×', fontsize=8)
ax.set_yscale('log'); ax.set_xticks(x); ax.set_xticklabels(sp); ax.set_ylabel('glucose per neuron (µmol/min)')
ax.set_title('Table 2 per-neuron glucose does not follow from its own totals', fontsize=9.5); ax.legend(fontsize=8, frameon=False)
fig.tight_layout(); fig.savefig('results/fig4_energy.png'); plt.close()

# ---------------------------------------------------------------- Fig 5 mouse
mo = J('a4_mouse.json')
c = pd.read_csv('/tmp/data/neuropixels_platform_paper/data/change_modulation_data.csv')
ctx = c[c.Region.isin(['V1', 'LM', 'AL', 'RL', 'AM', 'PM'])]
rp = ctx['Baseline Rate Passive'].values; rp = rp[np.isfinite(rp) & (rp > 0.05)]
sim = np.load('results/a4_sim_rates_sd1.5.npy'); sim = sim[sim > 0.05]
fig, axs = plt.subplots(1, 3, figsize=(12, 3.8))
ax = axs[0]; bins = np.linspace(-1.5, 2.2, 30)
ax.hist(np.log10(rp), bins=bins, density=True, color=LIGHT, label=f'Allen V1+HVAs, n={len(rp)}')
ax.hist(np.log10(sim), bins=np.linspace(-1.5, 2.2, 16), density=True, histtype='step', color=BLUE, lw=2, label='A.4, σρ = 1.5 (network sim)')
m1 = mo['M1a_rate_distribution']
ax.set_xlabel('log10 baseline rate (Hz)'); ax.legend(fontsize=7.5, frameon=False)
ax.set_title(f"Spread fits (SD {m1['model']['sigma_rho=1.5']['log10_sd']:.2f} vs {m1['allen']['log10_sd']:.2f}); level is 2× low", fontsize=9.5)
ax = axs[1]
ok = ctx[['Baseline Rate Active', 'Baseline Rate Passive']].replace([np.inf, -np.inf], np.nan).dropna()
ok = ok[(ok['Baseline Rate Active'] > 0.05) & (ok['Baseline Rate Passive'] > 0.05)]
ax.scatter(np.log10(ok['Baseline Rate Passive']), np.log10(ok['Baseline Rate Active']), s=3, alpha=0.3, color=GREY)
ax.plot([-1.3, 2], [-1.3, 2], color='k', lw=0.8, ls=':', label='same rate')
m1b = mo['M1b_state_stability']
ax.set_xlabel('log10 rate, passive'); ax.set_ylabel('log10 rate, active (same unit)'); ax.legend(fontsize=8, frameon=False)
ax.set_title(f"Rank kept across states: Spearman {m1b['spearman']:.2f}", fontsize=9.5)
ax = axs[2]
mods = mo['M2_microns']['models']; obs = mo['M2_microns']['observed']
names = ['observed\n(MICrONS)', 'geometry\nonly (A.2)', 'symmetric\nHebbian', 'STDP\nbalanced', 'STDP\nLTP-dom.']
bi = [obs['bi_vs_CFG'], 1.07, mods['symmetric Hebbian']['bi_vs_CFG'], mods['pair STDP, balanced (A-=1.05 A+)']['bi_vs_CFG'], mods['pair STDP, LTP-dominated (A-=0.8 A+)']['bi_vs_CFG']]
cl = [obs['clust_vs_CFG'], 1.09, mods['symmetric Hebbian']['clust_vs_CFG'], mods['pair STDP, balanced (A-=1.05 A+)']['clust_vs_CFG'], mods['pair STDP, LTP-dominated (A-=0.8 A+)']['clust_vs_CFG']]
x = np.arange(len(names))
ax.bar(x - 0.18, bi, 0.36, color=['k', LIGHT, GREY, BLUE, GREY], label='reciprocity / config. null')
ax.bar(x + 0.18, cl, 0.36, color='white', edgecolor=['k', LIGHT, GREY, BLUE, GREY], hatch='//', label='clustering / config. null')
ax.axhline(1, color=LIGHT, lw=0.8); ax.axhline(obs['bi_vs_CFG'], color='k', ls=':', lw=0.8)
ax.set_xticks(x); ax.set_xticklabels(names, fontsize=8)
ax.set_ylim(0, 3.9); ax.legend(fontsize=7.5, frameon=False, loc='upper center', ncol=2)
ax.set_title('STDP: reciprocity 1.48× but clustering lost', fontsize=9.5)
fig.tight_layout(); fig.savefig('results/fig5_mouse.png'); plt.close()

# ---------------------------------------------------------------- Fig 6 fly + theta + ChR2
ft = J('a4_fly_theta.json')
fig, axs = plt.subplots(1, 3, figsize=(12, 3.8))
ax = axs[0]
for mode, col in (('global', GREY), ('local', BLUE)):
    rhos = [0.15, 0.3, 0.6]
    ctl = [ft['F1_kenyon_cells'][f'{mode}, rho={r}']['control']['frac_active'] * 100 for r in rhos]
    blk = [ft['F1_kenyon_cells'][f'{mode}, rho={r}']['APL_block']['frac_active'] * 100 for r in rhos]
    ax.plot(rhos, ctl, 'o-', color=col, label=f'{mode} APL, control')
    ax.plot(rhos, blk, 'o--', color=col, label=f'{mode} APL, APL blocked')
ax.axhspan(5, 10, color='#e8eef7', zorder=0); ax.text(0.16, 7, 'measured 5-10%', fontsize=8)
ax.set_xlabel('homeostatic KC target ρ (Hz)'); ax.set_ylabel('% KCs active per odour'); ax.legend(fontsize=7, frameon=False)
ax.set_title('Local claw inhibition lowers KC activity at fixed ρ', fontsize=9.5)
ax = axs[1]
T1 = ft['T1_theta_eq23']['results']
for v, col in ((10, LIGHT), (20, GREY), (40, BLUE)):
    rates = [7.5, 15, 30]
    ax.plot(rates, [T1[f'r_peak={r} Hz, v={v} cm/s']['total_precession_deg'] for r in rates], 'o-', color=col, label=f'Eq. 23, {v} cm/s')
ax.axhspan(270, 360, color='#e8eef7', zorder=0); ax.text(8, 300, 'data: ~1 cycle, independent of rate', fontsize=8)
ax.set_yscale('log'); ax.set_xlabel('peak firing rate (Hz)'); ax.set_ylabel('phase precession across field (deg)')
ax.legend(fontsize=7.5, frameon=False); ax.set_title('Eq. 23 makes precession scale with spikes (rate/speed)', fontsize=9.5)
ax = axs[2]
p1 = ft['P1_ChR2_fI']
ax.plot(p1['I'], p1['rate_before'], 'o-', color=GREY, label=f"before (ATP {p1['before']['ATP']:.2f})")
ax.plot(p1['I'], p1['rate_after'], 'o-', color=BLUE, label=f"after 120 s ChR2 (ATP {p1['after']['ATP']:.2f})")
ax.set_xlabel('injected current (model units)'); ax.set_ylabel('rate (Hz)'); ax.legend(fontsize=8, frameon=False)
ax.set_title('P1: f-I curve after ChR2 run-down', fontsize=9.5)
fig.tight_layout(); fig.savefig('results/fig6_fly_theta_chr2.png'); plt.close()
print('figures written')
