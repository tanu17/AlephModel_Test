"""Model A.4 checks on the fly mushroom body, theta phase precession (Eq. 23) and the ChR2 assay (P1).

F1  FlyWire PN->KC and KC<->APL wiring: global APL inhibition (A.2/A.3) vs A.4's local, claw-specific
    graded inhibition with log-normal thresholds. Sweep the homeostatic target to show what sets sparseness,
    then compare APL-block effects at matched sparseness.
T1  Eq. 23, d(phi)/dt = omega_0 + kappa r - omega_theta: precession range across firing rate and running
    speed, compared with the rate-independence of phase (Huxter et al. 2003) and its speed-invariance in space.
P1  ChR2 run-down in the A.2/A.4 cell: f-I curve before and after 120 s of ChR2 drive (A.4 predicts a
    divisive slope drop and a rightward threshold shift).
"""
import json, os, numpy as np, pandas as pd
from modela.core import softplus, ModelA2

os.makedirs('results', exist_ok=True)
R = {}
D = '/tmp/data/'
con = pd.read_parquet(D + 'fly/Connectivity_783.parquet')
ann = pd.read_csv(D + 'flyann/supplemental_files/Supplemental_file1_neuron_annotations.tsv', sep='\t', low_memory=False)
kc_ids = ann.loc[ann.cell_class == 'Kenyon_Cell', 'root_id'].values
pn = ann.loc[(ann.cell_class == 'ALPN') & (ann.cell_sub_class == 'uniglomerular'), ['root_id', 'cell_type']]
apl = ann.loc[ann.cell_type == 'APL', 'root_id'].values
glom = sorted(pn.cell_type.unique()); gidx = {g: i for i, g in enumerate(glom)}
pn_g = dict(zip(pn.root_id, pn.cell_type.map(gidx)))
kidx = {k: i for i, k in enumerate(kc_ids)}
e = con[(con.Connectivity >= 3) & con.Presynaptic_ID.isin(pn_g) & con.Postsynaptic_ID.isin(kidx)]
Wgk = np.zeros((len(kc_ids), len(glom)))
np.add.at(Wgk, (e.Postsynaptic_ID.map(kidx).values, e.Presynaptic_ID.map(pn_g).values), e.Connectivity.values)
has_in = Wgk.sum(1) > 0; Wgk = Wgk[has_in]; kc_ids = kc_ids[has_in]; kidx = {k: i for i, k in enumerate(kc_ids)}
a2k = con[con.Presynaptic_ID.isin(apl) & con.Postsynaptic_ID.isin(kidx)]
k2a = con[con.Presynaptic_ID.isin(kidx) & con.Postsynaptic_ID.isin(apl)]
w_ak = np.zeros(len(kc_ids)); np.add.at(w_ak, a2k.Postsynaptic_ID.map(kidx).values, a2k.Connectivity.values)
w_ka = np.zeros(len(kc_ids)); np.add.at(w_ka, k2a.Presynaptic_ID.map(kidx).values, k2a.Connectivity.values)
M = len(kc_ids)
Wgk /= Wgk.sum(1, keepdims=True).mean(); w_ak /= w_ak.mean(); w_ka /= w_ka.sum()
Bin = (Wgk > 0).astype(float); Bin_n = Bin / np.maximum(Bin.sum(0, keepdims=True), 1)   # KCs per glomerulus
r_max, r_on = 8.0, 2.0
rng0 = np.random.default_rng(7)
theta_ln = rng0.lognormal(0, 0.5, M) - np.exp(0.125)          # log-normal threshold offsets, mean 0

def odors(P, seed):
    rng = np.random.default_rng(seed)
    shared = (np.random.default_rng(12345).random(len(glom)) < 0.3) * 1.0
    own = (rng.random((P, len(glom))) < 0.25) * rng.lognormal(0, 0.5, (P, len(glom)))
    return 0.6 * shared[None, :] * rng.lognormal(0, 0.3, (P, len(glom))) + own

def kc_resp(X, theta, mode, g=6.0, iters=60):
    r = np.zeros((X.shape[0], M)); A = np.zeros((X.shape[0], 1)); Ag = np.zeros_like(X)
    for _ in range(iters):
        if mode == 'global':
            h = X @ Wgk.T - g * A * w_ak[None, :]
        else:   # claw-local: each glomerulus' boutons inhibited by the activity of the KCs they feed
            h = np.maximum(X - g * Ag, 0) @ Wgk.T
        sp = softplus(h - theta[None, :]); r_new = r_max * sp / (sp + 1)
        A_new = (r_new * w_ka[None, :]).sum(1, keepdims=True) / r_max
        Ag_new = (r_new / r_max) @ Bin_n
        r = 0.5 * r + 0.5 * r_new; A = 0.5 * A + 0.5 * A_new; Ag = 0.5 * Ag + 0.5 * Ag_new
    return r

def adapt(theta, mode, rho, rounds=50, eta=0.05, seed=0, g=6.0):
    for k in range(rounds):
        r = kc_resp(odors(150, seed + k), theta, mode, g)
        theta = theta + eta * (r.mean(0) - rho)
    return theta

def metrics(r):
    frac = (r > r_on).mean(1)
    Y = r - r.mean(1, keepdims=True); Y /= (np.linalg.norm(Y, axis=1, keepdims=True) + 1e-12)
    C = Y @ Y.T; iu = np.triu_indices(len(Y), 1)
    life = (r > r_on).mean(0)
    return dict(frac_active=float(frac.mean()), interodor_corr=float(C[iu].mean()),
                silent_KCs=float((life == 0).mean()), lifetime_resp_prob_mean=float(life.mean()))

Xt = odors(200, 999)
F1 = {}
for mode in ('global', 'local'):
    for rho in (0.15, 0.3, 0.6):
        th0 = theta_ln.copy() if mode == 'local' else np.zeros(M)
        th = adapt(th0, mode, rho)
        ctl = metrics(kc_resp(Xt, th, mode)); blk = metrics(kc_resp(Xt, th, mode, g=0.0))
        F1[f'{mode}, rho={rho}'] = dict(control=ctl, APL_block=blk, bound_rho_over_r_on=rho / r_on)
        print('F1', mode, rho, round(ctl['frac_active'], 4), round(blk['frac_active'], 4), round(ctl['interodor_corr'], 3), round(blk['interodor_corr'], 3))
R['F1_kenyon_cells'] = F1

# ------------------------------------------------------------------ T1 theta phase precession
def precession(r_peak, v, kappa, L=40.0, sig=None, dt=0.001):
    sig = L / 6 if sig is None else sig
    x = np.arange(-L / 2, L / 2, v * dt); t = x / v
    r = r_peak * np.exp(-x**2 / (2 * sig**2))
    phi = 2 * np.pi * kappa * np.cumsum(r) * dt              # phase advance relative to theta (cycles -> rad)
    return np.degrees(phi[-1]), np.degrees(np.interp(0, x, phi))
kappa = 1 / (15 * (40 / 6) * np.sqrt(2 * np.pi) / 20)           # 360 deg at r_peak 15 Hz, 20 cm/s
T1 = {f'r_peak={rp} Hz, v={v} cm/s': dict(zip(['total_precession_deg', 'phase_at_field_centre_deg'], precession(rp, v, kappa)))
      for rp in (7.5, 15, 30) for v in (10, 20, 40)}
R['T1_theta_eq23'] = dict(kappa_cycles_per_spike=kappa, results=T1,
                          analytic='total precession = kappa * r_peak * sigma_x * sqrt(2 pi) / v, i.e. proportional to spike count',
                          data='Huxter, Burgess & O\'Keefe 2003: phase codes position independently of rate; precession range ~ 1 cycle '
                               'per field regardless of speed (O\'Keefe & Recce 1993)',
                          fix='replace kappa_drive r_i by 2 pi v(t) / L_field (position-locked oscillator) or by an input-driven '
                              'phase that depends on distance travelled')
print('T1', {k: round(v['total_precession_deg']) for k, v in T1.items()})

# ------------------------------------------------------------------ P1 ChR2 f-I curve
def fI(m, Is=np.linspace(0.6, 2.4, 7), probe=0.5, dt=0.002):
    import copy
    out = []
    for I in Is:
        mm = copy.deepcopy(m)
        rr = [mm.step(dt, I)[0] for _ in range(int(probe / dt))]
        out.append(np.mean(rr[len(rr) // 2:]))
    return Is, np.array(out)
def fit_fI(Is, f):
    on = f > 0.5
    if on.sum() < 2: return dict(slope=np.nan, threshold=np.nan)
    p = np.polyfit(Is[on], f[on], 1)
    return dict(slope=float(p[0]), threshold_current=float(-p[1] / p[0]))
m = ModelA2(1, np.zeros(1, int), np.ones(1), np.zeros((1, 1)), params=dict(tau_th=1e9))
for _ in range(int(20 / 0.002)): m.step(0.002, 0.6)
Is, f0 = fI(m); before = dict(fit_fI(Is, f0), ATP=float(m.e[0]), Na=float(m.n[0]))
for _ in range(int(120 / 0.002)): m.step(0.002, 0.6, I_syn=np.array([4.0]))
Is, f1 = fI(m); after = dict(fit_fI(Is, f1), ATP=float(m.e[0]), Na=float(m.n[0]))
R['P1_ChR2_fI'] = dict(I=Is.tolist(), rate_before=f0.tolist(), rate_after=f1.tolist(), before=before, after=after)
print('P1', before, after)
json.dump(R, open('results/a4_fly_theta.json', 'w'), indent=1, default=float)
