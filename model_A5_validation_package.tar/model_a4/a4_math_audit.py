"""Model A.4: numerical checks of the stated equations and theorems (Colleagues 2, 3 and 5).

M1  Theorem 1, capture variable c (Eq. 18): deterministic bound and the effect of additive noise
M2  Theorem 1, Na+ load n: is [0, N_max] forward-invariant when ATP reaches 0?
M3  Theorem 3, headroom barrier: holds under the wake flow, but is it kept across the REM jump?
M4  Theorem 5 premise: does Eq. 18 produce exponentially distributed barrier heights?
M5  Sleep law: derivative of ln t_sleep and of ln(t_sleep/t_wake) w.r.t. ln B, and the data
M6  Avian glucose: can the linear cost law with k = 1,800 give 0.32x?
M7  Table 2 internal consistency: per-neuron glucose from the table's own whole-brain numbers
M8  Arithmetic in Table 1 (Kabanov capacity, participation ratio, sheaf Euler characteristic)
M9  Ephaptic term (Eq. 1, Eq. 24): magnitude and the uniform-field problem
"""
import json, os, numpy as np
from scipy import stats, optimize
from modela.core import ModelA2

os.makedirs('results', exist_ok=True)
R = {}

# ---------------------------------------------------------------- M1 capture variable bounds
def drift_c(c, beta, K=0.5, gam=1.0, Om=0.0, pi=1.0):
    return Om * pi * (1 - c) + beta * c**2 / (K**2 + c**2) - gam * c
K, gam = 0.5, 1.0
beta_bistable = 2 * K * gam                      # bistability needs beta/(2K) > gamma
beta_escape = gam * (1 + K**2)                   # drift at c = 1 positive when beta > gamma (1 + K^2)
m1 = dict(K_c=K, gamma_c=gam, beta_needed_for_bistability=beta_bistable,
          beta_above_which_c_leaves_1=beta_escape,
          note='Eq. 18 has no (1 - c) factor on the autocatalytic term, so [0,1] is invariant only if '
               'beta_c <= gamma_c (1 + K_c^2) - Omega*pi*0; Theorem 1 does not state this.')
# additive noise: Euler-Maruyama, fraction of paths that leave [0, 1] within T
rng = np.random.default_rng(0)
for beta in (1.1, 1.5):
    for D in (0.002, 0.01):
        c = np.full(20000, 0.9 if beta < beta_escape else 1.0); out = np.zeros(c.size, bool)
        for _ in range(4000):
            c = c + 0.01 * drift_c(c, beta) + np.sqrt(2 * D * 0.01) * rng.standard_normal(c.size)
            out |= (c < 0) | (c > 1)
        m1[f'beta={beta},D={D}: fraction leaving [0,1] in T=40'] = float(out.mean())
R['M1_capture_bounds'] = m1

# ---------------------------------------------------------------- M2 Na+ load at zero ATP
m = ModelA2(4, np.zeros(4, int), np.ones(4), np.zeros((4, 4)))
for _ in range(int(20 / 0.002)): m.step(0.002, 0.6)
n0 = m.n.copy(); m.J_scale[:] = 0.0
traj = []
for t in range(int(600 / 0.002)):
    m.step(0.002, 0.6)
    if t % 25000 == 0: traj.append((t * 0.002, float(m.e.mean()), float(m.n.mean())))
R['M2_sodium_bound'] = dict(n_before=float(n0.mean()), trajectory_t_e_n=traj,
                            slope_late=float((traj[-1][2] - traj[-3][2]) / (traj[-1][0] - traj[-3][0])),
                            lambda_n=m.p['lam_n'],
                            note='with e = 0 the pump is 0 and dn/dt = lambda_n + synaptic load > 0, '
                                 'so n grows without bound: [0, N_max] is not forward-invariant.')

# ---------------------------------------------------------------- M3 headroom across REM
N = 30; rng = np.random.default_rng(1)
m = ModelA2(N, np.zeros(N, int), np.ones(N), rng.uniform(0.2, 0.6, (N, N)))
m.plastic = np.ones((N, N), bool); np.fill_diagonal(m.plastic, False)
budget = m.p['beta_w'] * (m.W * m.plastic).sum() * 1.02        # 2 % headroom
m.p['C_max'] = np.array([budget])
m.Om = (rng.random((N, N)) < 0.5) * 0.9                         # half the synapses tagged
h_before = float(m.headroom()[0])
m.rem()
h_after = float(m.headroom()[0])
R['M3_headroom_REM'] = dict(h_before=h_before, h_after_REM=h_after, violated=bool(h_after < 0),
                            note='Theorem 3 covers the continuous wake flow only; the REM jump adds '
                                 'eta_R * P * (w_max - W) with no budget check.')

# ---------------------------------------------------------------- M4 barrier distribution from Eq. 18
def barrier(beta, K=0.5, gam=1.0):
    # potential U(c) = -int drift; barrier from upper well to saddle
    roots = np.roots([gam, -beta, gam * K**2])      # gam c^2 - beta c + gam K^2 = 0 for c > 0 fixed points
    roots = np.sort(roots[np.isreal(roots)].real)
    if len(roots) < 2: return np.nan
    cs, cu = roots                                  # saddle (inner), upper stable
    f = lambda c: -drift_c(c, beta, K, gam)
    from scipy.integrate import quad
    return quad(f, cu, cs)[0] * -1 if False else quad(lambda c: drift_c(c, beta, K, gam), cs, cu)[0]
betas = np.linspace(1.001, 1.25, 400)
dU = np.array([barrier(b) for b in betas])
# if beta is uniform on its bistable window, what does the dU distribution look like?
bs = np.random.default_rng(2).uniform(1.001, 1.25, 50000)
dUs = np.interp(bs, betas, dU)
ks_exp = stats.kstest(dUs / dUs.mean(), 'expon')
near = betas < 1.05
expo = float(np.polyfit(np.log(betas[near] - 1), np.log(dU[near]), 1)[0])
R['M4_barrier_distribution'] = dict(dU_scaling_exponent_near_saddle_node=expo,
                                    KS_vs_exponential_stat=float(ks_exp.statistic), KS_p=float(ks_exp.pvalue),
                                    note='Theorem 5 assumes dU ~ Exp(1/mu); Eq. 18 gives dU ~ (beta - beta_c)^{3/2} '
                                         'near onset, so exponential barriers need an extra assumption about the '
                                         'distribution of beta_c, K_c, gamma_c that A.4 does not state.')

# ---------------------------------------------------------------- M5 sleep law derivative
rows = {'rat': (0.68, 12.6), 'macaque': (0.36, 11.45), 'mouse': (0.89, 12.1), 'squirrel': (0.60, 14.9),
        'baboon': (0.44, 10.3), 'human': (0.31, 8.0)}
B = np.array([v[0] for v in rows.values()]); ts = np.array([v[1] for v in rows.values()])
fit_ts = stats.linregress(np.log(B), np.log(ts))
fit_ratio = stats.linregress(np.log(B), np.log(ts / (24 - ts)))
kappa = (12.6 / 11.4) / 0.68
pred_slope_ts = np.mean(1 / (1 + kappa * B))
R['M5_sleep_derivative'] = dict(
    analytic='d ln t_sleep / d ln B = 1/(1 + kappa B) = t_wake/24 (A.4 correct); d ln(t_sleep/t_wake) / d ln B = 1 exactly',
    A3_regressed='ln(t_sleep/t_wake) on ln B, whose predicted slope is 1, so A.3 was not in error',
    ratio_slope=fit_ratio.slope, ratio_slope_se=fit_ratio.stderr, ratio_t_vs_1=(fit_ratio.slope - 1) / fit_ratio.stderr,
    t_sleep_slope=fit_ts.slope, t_sleep_slope_se=fit_ts.stderr, predicted_t_sleep_slope_mean=float(pred_slope_ts),
    A4_claim='A.4 compares 0.66 +/- 0.36 (the ratio slope) with t_wake/24 (the t_sleep slope): mixed quantities')

# ---------------------------------------------------------------- M6 avian ratio
P_rest, c_AP, c_glu = 4.44e8, 3.84e8, 3.28e8 / 8000
def cost(k, rho=4.0, area=1.0): return area * (P_rest + rho * c_AP) + rho * k * c_glu
r_k = cost(1800) / cost(8000)
r_floor = cost(0) / cost(8000)
area_needed = optimize.brentq(lambda a: cost(1800, area=a) / cost(8000) - 0.32, 1e-3, 1)
# rate at which a k=1800 neuron would cost 0.32 of a rodent neuron at 4 Hz
rate_needed = optimize.brentq(lambda rho: cost(1800, rho) / cost(8000) - 0.32, 1e-4, 4)
R['M6_avian'] = dict(ratio_k1800_same_rate=r_k, ratio_k0_same_rate=r_floor,
                     claimed=0.32, measured_von_Eugen=1.86e-9 / 5.79e-9,
                     membrane_area_factor_needed_with_k1800=area_needed,
                     mean_rate_needed_Hz_with_k1800=rate_needed,
                     note='A.4 says the linear law with k = 1,800 "yields exactly 0.32x"; it yields 0.69x, '
                          'and no k can go below 0.60x at equal rate and cell size. The 1,800 figure has no source.')

# ---------------------------------------------------------------- M7 Table 2 per-neuron glucose
W_per_umol_min = 2.87e6 * 1e-6 / 60        # W per (umol glucose / min), complete oxidation
tab = {'fly': dict(power_W=(1.1e-6, 6e-6), neurons=139255, table=1.2e-11),
       'zebrafish': dict(power_W=(0.15e-6, 0.35e-6), neurons=1e5, table=1.8e-11),
       'rat': dict(glc=1.225, neurons=2.0e8, table=1.06e-8),
       'macaque': dict(glc=31.4, neurons=6.38e9, table=0.86e-8),
       'pigeon': dict(glc=0.65, neurons=3.1e8, table=0.34e-8)}
m7 = {}
for k_, v in tab.items():
    if 'glc' in v: own = v['glc'] / v['neurons']
    else: own = [p_ / W_per_umol_min / v['neurons'] for p_ in v['power_W']]
    m7[k_] = dict(table_value=v['table'], from_table_inputs=own)
m7['pigeon']['von_Eugen_2022'] = 1.86e-9
R['M7_table2_consistency'] = m7

# ---------------------------------------------------------------- M8 Table 1 arithmetic
r = np.exp(-2 / 3.8)
R['M8_table1'] = dict(kabanov_bits_per_s_at_100Hz=100 / (np.e * np.log(2)),
                      PR_if_sigma_are_singular_values=(1 + r) / (1 - r),
                      PR_if_sigma_are_eigenvalues=(1 + np.exp(-1 / 3.8)) / (1 - np.exp(-1 / 3.8)),
                      sheaf='dim H0 - dim H1 = d(|V|-|E|) = d(1-b1); flat => dim H0 = d => dim H1 = d b1 (correct)')

# ---------------------------------------------------------------- M9 ephaptic magnitude
sigma = 0.3                                      # S/m, cortical extracellular conductivity
V_1nA_50um = 1e-9 / (4 * np.pi * sigma * 50e-6)
R['M9_ephaptic'] = dict(V_e_from_1nA_at_50um_uV=V_1nA_50um * 1e6,
                        note='a spatially uniform V_e shifts inside and outside equally and changes no '
                             'transmembrane voltage of a point neuron; the effect comes from the field gradient '
                             'along the cell axis (activating function), so g_eph (v - V_e) is not the right '
                             'form; Eq. 24 is also singular at |x - x_j| = 0 (self term).')

json.dump(R, open('results/a4_math.json', 'w'), indent=1, default=float)
for k_, v in R.items(): print(k_, json.dumps(v, default=float)[:500])
