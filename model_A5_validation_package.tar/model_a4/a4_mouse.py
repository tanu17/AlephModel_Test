"""Model A.4 mouse tests.

M1  Allen Neuropixels (Visual Behavior, 6 visual cortical areas): A.4 assigns log-normal set points
    (sigma_rho = 1.5). (a) simulate the A.2/A.4 network with that spread and compare the whole rate
    distribution with the data (KS distance, quantiles); (b) cell-autonomous set points predict that
    each unit keeps its rank across behavioural states and that state changes act as a common gain:
    test with the same units' baseline rates in active vs passive sessions.
M2  MICrONS L2/3 reciprocity (observed 1.37x vs configuration null): A.4 says asymmetric STDP
    brings Hebbian over-linking (2.17x) down to 1.41x. Grow networks on the same distance-limited
    potential synapses with (i) symmetric Hebbian, (ii) pair STDP with sweeping stimuli, (iii) STDP with
    potentiation-dominated window, and measure reciprocity and clustering against the same nulls.
"""
import json, os, numpy as np, pandas as pd, networkx as nx
from scipy import stats
from modela.core import ModelA2

os.makedirs('results', exist_ok=True)
R = {}
c = pd.read_csv('/tmp/data/neuropixels_platform_paper/data/change_modulation_data.csv')
ctx = c[c.Region.isin(['V1', 'LM', 'AL', 'RL', 'AM', 'PM'])]
rp = ctx['Baseline Rate Passive'].values; rp = rp[np.isfinite(rp) & (rp > 0.05)]
lrp = np.log10(rp)

def net_rates(rho_sd, N=200, T=400, seed=4):
    rng = np.random.default_rng(seed)
    sign = np.where(rng.random(N) < 0.8, 1, -1)
    W = (rng.random((N, N)) < 0.1) * rng.uniform(0.5, 1.5, (N, N)) * np.where(sign[None, :] > 0, 0.03, 0.2)
    m = ModelA2(N, np.repeat(np.arange(5), N // 5), sign, W, params=dict(th_min=-6.0, th_max=8.0))
    m.p['rho'] = 4.0 * rng.lognormal(-rho_sd**2 / 2, rho_sd, N)
    I = 1.3 + 0.3 * rng.standard_normal(N)
    acc = np.zeros(N); k = 0
    for t in range(int(T / 0.002)):
        r = m.step(0.002, I)
        if t * 0.002 > T - 100: acc += r; k += 1
    return acc / k, m.p['rho']

sim = {}
for sd in (1.0, 1.5):
    r, rho = net_rates(sd)
    rr = r[r > 0.05]; lr_ = np.log10(rr)
    ks = stats.ks_2samp(lr_ - lr_.mean(), lrp - lrp.mean())
    sim[f'sigma_rho={sd}'] = dict(log10_sd=float(lr_.std()), mean_Hz=float(rr.mean()), median_Hz=float(np.median(rr)),
                                  frac_silent=float((r <= 0.05).mean()), corr_rate_setpoint=float(np.corrcoef(np.log(r + 1e-3), np.log(rho))[0, 1]),
                                  log10_skew=float(stats.skew(lr_)), KS_shape_vs_allen=float(ks.statistic), KS_p=float(ks.pvalue))
    np.save(f'results/a4_sim_rates_sd{sd}.npy', r)
R['M1a_rate_distribution'] = dict(allen=dict(n=int(len(rp)), log10_sd=float(lrp.std()), mean_Hz=float(rp.mean()),
                                             median_Hz=float(np.median(rp)), log10_skew=float(stats.skew(lrp)),
                                             mean_over_median=float(rp.mean() / np.median(rp)),
                                             lognormal_mean_over_median_expected=float(np.exp((lrp.std() * np.log(10))**2 / 2))),
                                  model=sim)
print('M1a', json.dumps(R['M1a_rate_distribution'], default=float)[:900])

# M1b state stability
ok = ctx[['Baseline Rate Active', 'Baseline Rate Passive']].replace([np.inf, -np.inf], np.nan).dropna()
ok = ok[(ok['Baseline Rate Active'] > 0.05) & (ok['Baseline Rate Passive'] > 0.05)]
la, lp = np.log10(ok['Baseline Rate Active']), np.log10(ok['Baseline Rate Passive'])
rho_s = stats.spearmanr(la, lp)
# orthogonal (total least squares) slope of log active on log passive
C = np.cov(lp, la); ev, evec = np.linalg.eigh(C); v = evec[:, -1]; tls = v[1] / v[0]
R['M1b_state_stability'] = dict(n=int(len(ok)), spearman=float(rho_s.correlation), pearson_log=float(np.corrcoef(la, lp)[0, 1]),
                                log10_ratio_mean=float((la - lp).mean()), log10_ratio_sd=float((la - lp).std()),
                                tls_slope_log_active_vs_log_passive=float(tls),
                                note='common multiplicative gain predicts slope 1 in log-log; slope < 1 means '
                                     'state change compresses rates toward a common value')
print('M1b', R['M1b_state_stability'])

# ------------------------------------------------------------------ M2 MICrONS reciprocity
OBS = dict(N=363, edges=1750, bi_obs=31, bi_ER=11.652816, bi_CFG=22.574,
           clust_obs=0.09511077158135982, clust_ER=0.02645765312905113, clust_CFG=0.08517955789223566)
obs = dict(bi_vs_ER=OBS['bi_obs'] / OBS['bi_ER'], bi_vs_CFG=OBS['bi_obs'] / OBS['bi_CFG'],
           clust_vs_ER=OBS['clust_obs'] / OBS['clust_ER'], clust_vs_CFG=OBS['clust_obs'] / OBS['clust_CFG'])

def motif_stats(A, n_cfg=20, seed=0):
    rng = np.random.default_rng(seed); n = A.shape[0]; E = A.sum(); p = E / (n * (n - 1))
    bi = int((A * A.T).sum() // 2); bi_er = p * p * n * (n - 1) / 2
    cl = nx.transitivity(nx.DiGraph(A).to_undirected())
    kin = A.sum(0).astype(int); kout = A.sum(1).astype(int); bis, cls = [], []
    for s in range(n_cfg):
        H = nx.DiGraph(nx.directed_configuration_model(kin.tolist(), kout.tolist(), seed=int(rng.integers(1e9))))
        H.remove_edges_from(nx.selfloop_edges(H)); Ah = nx.to_numpy_array(H, nodelist=range(n)) > 0
        bis.append((Ah & Ah.T).sum() / 2); cls.append(nx.transitivity(H.to_undirected()))
    return dict(bi_vs_ER=float(bi / bi_er), bi_vs_CFG=float(bi / np.mean(bis)),
                clust_vs_ER=float(cl / (1 - (1 - p)**2)), clust_vs_CFG=float(cl / np.mean(cls)))

def grow(rule, N=363, seed=1, lam=120.0, p0=0.12, trials=1500, Tsteps=60, dt=0.005, Aplus=1.0, Aminus=1.05):
    rng = np.random.default_rng(seed)
    pos = rng.uniform(0, 250, (N, 2)); d = np.linalg.norm(pos[:, None] - pos[None], axis=2)
    pot = (rng.random((N, N)) < p0 * np.exp(-d / lam)); np.fill_diagonal(pot, False)
    pref = rng.uniform(0, np.pi, N); rf = rng.uniform(0, 250, (N, 2))
    W = np.zeros((N, N)); tau = 0.02; a = np.exp(-dt / tau)
    for _ in range(trials):
        ori = rng.uniform(0, np.pi); direc = rng.uniform(0, 2 * np.pi); speed = 2000.0     # um/s sweep
        start = rng.uniform(0, 250, 2) - 0.5 * speed * Tsteps * dt * np.array([np.cos(direc), np.sin(direc)])
        tun = 12 * np.exp(2 * (np.cos(2 * (ori - pref)) - 1))
        Rt = np.empty((Tsteps, N))
        for t in range(Tsteps):
            loc = start + speed * t * dt * np.array([np.cos(direc), np.sin(direc)])
            Rt[t] = tun * np.exp(-np.linalg.norm(rf - loc, axis=1)**2 / (2 * 60**2)) + rng.exponential(0.3, N)
        if rule == 'hebbian':
            dW = Rt.T @ Rt
        else:
            X = np.zeros_like(Rt); acc = np.zeros(N)
            for t in range(Tsteps): acc = a * acc + Rt[t]; X[t] = acc     # low-pass traces
            # W[i, j]: j -> i.  LTP when pre j leads post i; LTD when post leads pre
            dW = Aplus * (Rt.T @ X) - Aminus * (X.T @ Rt)
        W = W + 1e-4 * dW * pot
    thr = np.sort(W[pot])[::-1][OBS['edges'] - 1]
    A = ((W >= thr) & pot).astype(int)
    st = motif_stats(A)
    # asymmetry of learned weights for reciprocal potential pairs
    both = pot & pot.T
    st['weight_asymmetry_corr_reciprocal_pairs'] = float(np.corrcoef(W[both], W.T[both])[0, 1])
    return st

models = {'geometry_only (A.2 run)': None}
R['M2_microns'] = dict(observed=obs, models={})
for label, kw in (('symmetric Hebbian', dict(rule='hebbian')),
                  ('pair STDP, balanced (A-=1.05 A+)', dict(rule='stdp')),
                  ('pair STDP, LTP-dominated (A-=0.8 A+)', dict(rule='stdp', Aminus=0.8))):
    R['M2_microns']['models'][label] = grow(**kw)
    print('M2', label, R['M2_microns']['models'][label])
json.dump(R, open('results/a4_mouse.json', 'w'), indent=1, default=float)
