"""Model A.4 sleep law, tested out of sample.

Law (A.3/A.4): t_sleep / t_wake = kappa * B, with B = mass-specific brain glucose use (umol/g/min).
kappa is calibrated on the rat only. Two tests:
 S1  the six species with measured B (Herculano-Houzel 2011 Table 1)
 S2  62 mammals of Allison & Cicchetti (1976) (openintro::mammals), with B from brain-mass allometry
     B = B_rat (M / M_rat)^b, b = -0.127 (fitted on the six species, Herculano-Houzel 2011) or -0.15
     (Karbowski 2007). No sleep data enter the allometry, so S2 is a genuine prediction.
 S3  A.4's ecological factor xi_eco: does Allison & Cicchetti's danger index explain the residuals?
"""
import json, os, numpy as np, pandas as pd
from scipy import stats

os.makedirs('results', exist_ok=True)
R = {}
HH = pd.DataFrame(dict(species=['mouse', 'rat', 'squirrel', 'macaque', 'baboon', 'human'],
                       mass=[0.416, 1.802, 5.548, 87.346, 148.80, 1508.91],
                       B=[0.89, 0.68, 0.60, 0.36, 0.44, 0.31],
                       sleep=[12.1, 12.6, 14.9, 11.45, 10.3, 8.0]))
kappa = (12.6 / 11.4) / 0.68
law = lambda B: 24 * kappa * B / (1 + kappa * B)
HH['pred'] = law(HH.B)
b_fit = stats.linregress(np.log(HH.mass), np.log(HH.B))
R['S1_six_species'] = dict(kappa=kappa, table=HH.round(3).to_dict('records'),
                           rmse_h=float(np.sqrt(((HH.pred - HH.sleep)**2).mean())),
                           allometry_b=b_fit.slope, allometry_b_se=b_fit.stderr)

m = pd.read_csv('/tmp/data/msleep/mammals.csv').dropna(subset=['brain_wt', 'total_sleep'])
m = m[m.total_sleep < 23.9]
out = {}
for label, b in (('b=-0.127 (HH 2011)', -0.127), ('b=-0.15 (Karbowski 2007)', -0.15)):
    B = 0.68 * (m.brain_wt / 1.802)**b
    pred = law(B)
    res = m.total_sleep - pred
    ss_res = (res**2).sum(); ss_tot = ((m.total_sleep - m.total_sleep.mean())**2).sum()
    lr_obs = stats.linregress(np.log(m.brain_wt), np.log(m.total_sleep / (24 - m.total_sleep)))
    out[label] = dict(n=int(len(m)), R2_vs_mean=float(1 - ss_res / ss_tot), rmse_h=float(np.sqrt((res**2).mean())),
                      bias_h=float(res.mean()), predicted_range_h=[float(pred.min()), float(pred.max())],
                      observed_range_h=[float(m.total_sleep.min()), float(m.total_sleep.max())],
                      predicted_slope_ln_ratio_vs_ln_mass=b, observed_slope=lr_obs.slope, observed_slope_se=lr_obs.stderr,
                      pearson_r_pred_obs=float(np.corrcoef(pred, m.total_sleep)[0, 1]))
    m[f'pred_{b}'] = pred
# best possible fit of the same functional form (free kappa and b) as an upper bound
lr_free = stats.linregress(np.log(m.brain_wt), np.log(m.total_sleep / (24 - m.total_sleep)))
pf = 24 * np.exp(lr_free.intercept) * m.brain_wt**lr_free.slope / (1 + np.exp(lr_free.intercept) * m.brain_wt**lr_free.slope)
out['free_fit_upper_bound'] = dict(slope=lr_free.slope, R2_vs_mean=float(1 - ((m.total_sleep - pf)**2).sum() / ((m.total_sleep - m.total_sleep.mean())**2).sum()))
R['S2_62_mammals'] = out

# S3 ecological factor: regress log-ratio residual on danger index
mm_ = m.dropna(subset=['danger']).copy()
B = 0.68 * (mm_.brain_wt / 1.802)**-0.127
resid = np.log(mm_.total_sleep / (24 - mm_.total_sleep)) - np.log(kappa * B)
lr_d = stats.linregress(mm_.danger, resid)
X = np.column_stack([np.ones(len(mm_)), np.log(mm_.brain_wt), mm_.danger])
beta, *_ = np.linalg.lstsq(X, np.log(mm_.total_sleep / (24 - mm_.total_sleep)), rcond=None)
pred3 = X @ beta; y3 = np.log(mm_.total_sleep / (24 - mm_.total_sleep))
R['S3_ecological_factor'] = dict(n=int(len(mm_)), danger_slope_on_residual=lr_d.slope, se=lr_d.stderr, p=lr_d.pvalue,
                                 r=lr_d.rvalue, multiple_regression_coef=dict(intercept=beta[0], ln_brain=beta[1], danger=beta[2]),
                                 R2_ln_ratio_brain_plus_danger=float(1 - ((y3 - pred3)**2).sum() / ((y3 - y3.mean())**2).sum()),
                                 note='danger = combined predation and sleep-exposure index (1 low - 5 high)')
json.dump(R, open('results/a4_sleep_law.json', 'w'), indent=1, default=float)
m[['species', 'brain_wt', 'total_sleep', 'danger', 'pred_-0.127', 'pred_-0.15']].to_csv('results/a4_sleep_law_mammals.csv', index=False)
print(json.dumps(R, indent=1, default=float)[:3000])
