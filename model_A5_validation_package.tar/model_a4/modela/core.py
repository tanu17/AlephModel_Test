"""
Model A.2 — reference implementation (core reused by Model A.3).

A compact rate model of metabolically bounded neural tissue that repairs the
errors found in Model A (E1–E9). Units are normalised:
  time in seconds (slow processes are time-compressed in benchmarks, stated there);
  membrane variables relative to rest (v_rest = 0, base threshold 1);
  energy e in units of a full cellular ATP pool (0..1);
  Na+ load n in units such that pumping 3 units consumes 1 unit of energy
  (Na+/K+-ATPase stoichiometry: 3 Na+ per ATP).

State per neuron  : v, a (adaptation), theta (homeostatic threshold), e (ATP), n (Na+ debt)
State per synapse : W, x (releasable vesicles), Om (fast tag), c (consolidated state)
State per domain  : eQ (supply reserve), f (relative blood flow), k (extracellular K+)

Key repairs (see docs):
  E2  every spike and every synaptic current loads Na+; Na+ can only leave by
      ATP-consuming pumping; firing fails when Na+ debt is high. Energy is
      therefore conserved exactly and nothing is "free".
  C4  K_ATP is a conductance in the voltage equation (divisive + subtractive),
      not a threshold offset.
  E3  homeostatic set point is energy-aware: rho * chi(e).
      Systemic scarcity is a separate input G (synaptic gain/cost), giving
      Padamsey-type "low-power mode".
  E6  supply follows activity through blood flow with oxygen-extraction
      limitation (Buxton): J = J0 * f*E(f)/E0.
  E7  CBF gate + salience-gated eviction with exactly matched budget.
  E5  bounded fast tag Om and energy-gated capture c (no unbounded cascade).
  E8  REM both strengthens tagged and prunes weak untagged synapses.
"""
import numpy as np

def softplus(x, b=4.0):
    return np.logaddexp(0.0, b * x) / b

def mm(x, K):
    """Michaelis-Menten saturation, zero at zero, positive-preserving."""
    x = np.maximum(x, 0.0)
    return x / (x + K)

def hill_up(x, K, n):
    x = np.maximum(x, 0.0)
    return x**n / (x**n + K**n)

DEFAULT = dict(
    # membrane
    tau_v=0.01, E_K=-1.0, gK_max=1.5, K_A=0.25, nK=4,
    r_max=60.0, theta0=1.0,
    tau_ad=0.1, m_ad=0.004,
    # Na+ debt and pump
    nu_spk=0.18,          # Na+ units per spike  (=0.06 energy per spike)
    nu_syn=0.012,         # Na+ units per unit synaptic drive W*x*r
    lam_n=0.06,           # resting Na+ leak (part of housekeeping)
    Pi_max=3.6, K_n=1.0, K_e=0.15,
    n_crit=4.0, n_hill=6,
    # housekeeping + weight maintenance + plasticity cost (energy/s)
    P0=0.06, beta_w=0.0004, kappa_w=0.02,
    # energy exchange
    g_x=2.0, E_Q=4.0,
    # supply and flow (Buxton oxygen limitation)
    J0=None, E0=0.4, tau_f=2.0, kap_N=1.4, kap_K=0.3, f_max=3.0, tau_ubar=600.0,
    # potassium
    tau_K=0.5, k_rest=3.0, k_ceil=12.0, gam_K=0.06,
    # homeostasis
    tau_th=60.0, rho=4.0, e_h=0.30, q_h=4, th_min=-1.5, th_max=3.0,
    # vesicles
    tau_rec=0.8, U=0.25,
    # plasticity
    tau_w=20.0, w_max=1.0, r0=5.0, c_dep=0.4, gam_dec=0.02,
    gam_h=0.05, C_max=None, eps=1e-6, f0=0.05, kappa_c=2.0,
    # tag and capture
    tau_Om=30.0, kap_Om=4.0, tau_c=300.0, e_pi=0.45, q_pi=4, gam_c=0.002,
    # sleep jump maps
    delta_sws=0.2, eta_rem=0.15, pi_rem=0.5, w_p=0.15,
)


class ModelA2:
    """Dense-network implementation for networks up to ~1000 neurons.

    neurons are assigned to supply domains by `domain` (int array).
    sign: +1 excitatory, -1 inhibitory (Dale).
    """

    def __init__(self, N, domain=None, sign=None, W=None, params=None, seed=0,
                 plastic_mask=None):
        self.p = dict(DEFAULT)
        if params:
            self.p.update(params)
        p = self.p
        self.rng = np.random.default_rng(seed)
        self.N = N
        self.domain = np.zeros(N, int) if domain is None else np.asarray(domain)
        self.nQ = int(self.domain.max()) + 1
        self.sign = np.ones(N) if sign is None else np.asarray(sign, float)
        self.W = np.zeros((N, N)) if W is None else W.astype(float).copy()
        np.fill_diagonal(self.W, 0.0)
        self.conn = self.W > 0 if plastic_mask is None else plastic_mask
        self.plastic = self.conn & (self.sign[None, :] > 0)  # E->* synapses plastic
        # state
        self.v = np.zeros(N); self.a = np.zeros(N)
        self.th = np.zeros(N); self.e = np.full(N, 0.9); self.n = np.full(N, 0.3)
        self.x = np.ones((N, N)); self.Om = np.zeros((N, N)); self.c = np.zeros((N, N))
        self.eQ = np.full(self.nQ, 0.9)   # concentration; domain volume = E_Q
        self.f = np.ones(self.nQ)
        self.k = np.full(self.nQ, p['k_rest'])
        self.u_bar = None   # slow reference for feedforward (glutamatergic) vascular drive
        self.r = np.zeros(N)
        # inputs
        self.G = 1.0       # systemic synaptic gain (leptin / feeding status)
        self.ACh = 0.0; self.NE = 1.0; self.DAp = 0.0; self.DAm = 0.0
        self.b_m = 0.0     # developmental brake
        self.psi = 0.0     # salience gate for eviction
        self.J_scale = np.ones(self.nQ)   # local supply impairment (ischemia)
        if p['J0'] is None:
            # set supply so each domain can sustain ~1.3x its neurons' demand at rho
            nq = np.bincount(self.domain, minlength=self.nQ)
            p_ref = p['P0'] + p['lam_n'] / 3 + p['rho'] * p['nu_spk'] / 3 * 2.5
            p['J0'] = 1.3 * p_ref * nq.max()
        if p['C_max'] is None:
            p['C_max'] = np.full(self.nQ, 1e9)
        # ledgers
        self.ledger = dict(supply=0.0, consumed=0.0, pumped_Na=0.0, Na_in=0.0)
        self.syn_cost_acc = 0.0
        self.cap_cost = np.zeros(N)   # protein-synthesis cost of capture, set by update_tags

    # ---------- helpers ----------
    def domain_sum(self, vec):
        return np.bincount(self.domain, weights=vec, minlength=self.nQ)

    def gK(self, e):
        p = self.p
        return p['gK_max'] / (1.0 + (np.maximum(e, 0) / p['K_A'])**p['nK'])

    def chi(self, e):
        p = self.p
        return hill_up(e, p['e_h'], p['q_h'])

    def rate(self):
        p = self.p
        drive = (self.v - self.th - self.a - p['theta0']) * self.NE
        sigNa = 1.0 / (1.0 + (np.maximum(self.n, 0) / p['n_crit'])**p['n_hill'])
        kq = self.k[self.domain]
        hK = 1.0 / (1.0 + np.exp((kq - p['k_ceil'] + 1.0) / 0.4))
        sp = softplus(drive)
        return p['r_max'] * sp / (sp + 1.0) * sigNa * hK

    # ---------- one Euler step ----------
    def step(self, dt, I_ext, learn=False, I_syn=None):
        """I_ext: non-synaptic current (e.g. optogenetic); I_syn: feedforward synaptic drive
        (scaled by systemic gain G and charged as Na+ load like any synaptic current)."""
        p = self.p
        N = self.N
        r = self.rate(); self.r = r
        # synaptic drive (signed) and Na load from synaptic currents (unsigned)
        Wx = self.W * self.x
        syn_in = self.G * (1 - 0.5 * self.ACh) * (Wx @ (self.sign * r))
        syn_load = self.G * (Wx @ r)                      # receptor current magnitude
        if I_syn is not None:
            syn_in = syn_in + self.G * I_syn
            syn_load = syn_load + self.G * np.abs(I_syn) * 10.0   # ff drive in rate-equivalent units
        # membrane: K_ATP conductance pulls toward E_K
        dv = (-(self.v) - self.gK(self.e) * (self.v - p['E_K']) + syn_in
              + (1 + 0.5 * self.ACh) * I_ext) / p['tau_v']
        da = (-self.a + p['m_ad'] * r) / p['tau_ad']
        # Na+ debt and pump
        Na_in = p['nu_spk'] * r + p['nu_syn'] * syn_load + p['lam_n']
        pump = p['Pi_max'] * mm(self.e, p['K_e']) * mm(self.n, p['K_n'])
        dn = Na_in - pump
        # plasticity (computed before energy so its cost is charged)
        dW = np.zeros_like(self.W)
        if learn:
            dW = self.plasticity_rate(r)
        absdW = np.abs(dW).sum(1)
        # energy consumption: pump (3 Na per ATP) + housekeeping + weight upkeep + plasticity
        Wsum = (self.W * self.plastic).sum(1)
        cons = pump / 3.0 + mm(self.e, p['K_e']) * (p['P0'] + p['beta_w'] * Wsum
                                                     + p['kappa_w'] * absdW + self.cap_cost)
        ex = p['g_x'] * (self.eQ[self.domain] - self.e)   # neuron volume = 1
        de = ex - cons
        # domain supply with activity-driven flow (feedforward glutamate + K+)
        u = self.domain_sum(syn_load) / np.maximum(np.bincount(self.domain, minlength=self.nQ), 1)
        E = 1 - (1 - p['E0'])**(1.0 / self.f)
        J = p['J0'] * self.J_scale * self.f * E / p['E0']
        dQ = (J * (1 - self.eQ) - self.domain_sum(ex)) / p['E_Q']
        if self.u_bar is None:
            self.u_bar = u.copy()
        self.u_bar += dt * (u - self.u_bar) / p['tau_ubar']
        df = (-(self.f - 1) + p['kap_N'] * (u / np.maximum(self.u_bar, 1e-9) - 1)
              + p['kap_K'] * (self.k - p['k_rest'])) / p['tau_f']
        rbar = self.domain_sum(r) / np.maximum(np.bincount(self.domain, minlength=self.nQ), 1)
        dk = (-(self.k - p['k_rest']) * mm(self.eQ, 0.1) * 1.1 + p['gam_K'] * rbar) / p['tau_K']
        # homeostasis with energy-aware set point; soft projection at bounds
        dth = (r - p['rho'] * self.chi(self.e)) / p['tau_th']
        dth = np.where((self.th <= p['th_min']) & (dth < 0), 0, dth)
        dth = np.where((self.th >= p['th_max']) & (dth > 0), 0, dth)
        # vesicles
        dx = (1 - self.x) / p['tau_rec'] - p['U'] * self.x * r[None, :]
        # integrate
        self.v += dt * dv; self.a += dt * da; self.n = np.maximum(self.n + dt * dn, 0)
        self.e = np.maximum(self.e + dt * de, 0); self.eQ = np.maximum(self.eQ + dt * dQ, 0)
        self.f = np.clip(self.f + dt * df, 0.3, p['f_max']); self.k += dt * dk
        self.th += dt * dth; self.x = np.clip(self.x + dt * dx, 0, 1)
        if learn:
            self.W = np.clip(self.W + dt * dW, 0, p['w_max'])
            self.update_tags(dt, r)
        # ledgers
        self.ledger['supply'] += dt * (J * (1 - self.eQ)).sum()
        self.ledger['consumed'] += dt * cons.sum()
        self.ledger['pumped_Na'] += dt * pump.sum()
        self.ledger['Na_in'] += dt * Na_in.sum()
        self.syn_cost_acc += dt * (p['nu_syn'] * syn_load).sum() / 3.0
        return r

    # ---------- plasticity with exact CBF gate and matched eviction ----------
    def fplus(self, r):
        p = self.p
        return np.outer(r, r) / p['r0']**2

    def fminus(self, r):
        p = self.p
        return p['c_dep'] * (r[:, None] + r[None, :]) / (2 * p['r0'])

    def plasticity_rate(self, r):
        p = self.p
        M = self.plastic
        fp = self.fplus(r) * M; fm = self.fminus(r) * M
        P = np.maximum(self.Om, self.c)
        pot = (1 - self.b_m) * self.DAp * fp * (p['w_max'] - self.W)
        dep = (1 - self.b_m) * (1 + self.DAm) * fm * self.W + p['gam_dec'] * (1 - P) * self.W * M
        dW = np.zeros_like(self.W)
        self.s_Q = np.ones(self.nQ)
        for q in range(self.nQ):
            rows = self.domain == q
            Pi = pot[rows].sum(); D = dep[rows].sum()
            h = p['C_max'][q] - p['beta_w'] * (self.W[rows] * M[rows]).sum()
            s = np.clip((D + p['gam_h'] * h * p['tau_w'] / p['beta_w']) / (Pi + p['eps']), 0, 1)
            self.s_Q[q] = s
            s_eff = s + self.psi * (1 - s)
            U = self.psi * (1 - s) * Pi
            omega = (1 - P[rows]) * self.W[rows] * np.exp(-fp[rows] / p['f0']) * M[rows]
            Ev = U * omega / (omega.sum() + p['eps'])
            dW[rows] = (s_eff * pot[rows] - dep[rows] - Ev) / p['tau_w']
        return dW

    def update_tags(self, dt, r):
        p = self.p
        fp = self.fplus(r) * self.plastic * self.DAp
        self.Om += dt * (p['kap_Om'] * fp * (1 - self.Om) - self.Om) / p['tau_Om']
        piQ = hill_up(self.eQ, p['e_pi'], p['q_pi'])[self.domain][:, None]
        gc = p['gam_c'] if np.isscalar(p['gam_c']) else p['gam_c']
        dc = (self.Om * piQ * (1 - self.c) - gc * self.c) / p['tau_c']
        self.cap_cost = p['kappa_c'] * np.maximum(dc, 0).sum(1)
        self.c += dt * dc
        self.Om = np.clip(self.Om, 0, 1); self.c = np.clip(self.c, 0, 1)

    # ---------- sleep: hybrid jump maps ----------
    def sws(self):
        p = self.p
        P = np.maximum(self.Om, self.c)
        self.W = self.W * (1 - p['delta_sws'] * (1 - P) * self.plastic)

    def rem(self):
        p = self.p
        P = np.maximum(self.Om, self.c)
        weak = 1.0 / (1.0 + np.exp((self.W - p['w_p']) / 0.02))   # smooth indicator
        self.W = (self.W + p['eta_rem'] * P * (p['w_max'] - self.W) * self.plastic
                  - p['pi_rem'] * (1 - P) * weak * self.W * self.plastic)
        self.W = np.clip(self.W, 0, p['w_max'])

    # ---------- diagnostics ----------
    def energy_content(self):
        return self.e.sum() + self.p['E_Q'] * self.eQ.sum()

    def headroom(self):
        p = self.p
        out = np.zeros(self.nQ)
        for q in range(self.nQ):
            rows = self.domain == q
            out[q] = p['C_max'][q] - p['beta_w'] * (self.W[rows] * self.plastic[rows]).sum()
        return out

ModelB = ModelA2   # backward-compatible alias
