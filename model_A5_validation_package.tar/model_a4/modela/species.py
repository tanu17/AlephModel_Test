"""Model A.3 species parameter vectors Theta_s.

Each entry carries the value used and its source. Values marked 'proxy' come from a related
species; values marked None are not available and the corresponding prediction is skipped.
"""

SPECIES = {
    'fly': dict(
        name='Fruit fly (Drosophila melanogaster), adult',
        neurons=139_255, neurons_src='FlyWire v783 (Dorkenwald et al. 2024)',
        synapses=54.49e6, synapses_src='FlyWire v783 synapse table, all connections (this analysis)',
        super_classes=10, cell_classes=49, cell_types=8_846,
        types_src='FlyWire annotations (Schlegel et al. 2024), current release; paper reported 8,453',
        nt_neurons={'acetylcholine': 86_193, 'glutamate': 24_875, 'GABA': 19_171, 'dopamine': 5_909,
                     'serotonin': 2_282, 'octopamine': 216, 'unassigned': 602},
        nt_synapse_share={'acetylcholine': 0.559, 'GABA': 0.231, 'glutamate': 0.174, 'dopamine': 0.025,
                          'serotonin': 0.008, 'octopamine': 0.0025},
        nt_src='FlyWire predicted transmitter (top_nt), counted here',
        inhib_input_fraction=0.44, inhib_src='GABA + glutamate (GluCl) inputs per neuron, mean, this analysis',
        T_body=25.0, supply='tracheal-glial units',
        brain_power_W=(1.1e-6, 6e-6), power_src='Neville et al. 2018 ex vivo OCR (1.1 uW); in vivo upper estimate',
        brain_glucose_umol_g_min=None,
        sleep_h=(12.5, 16.5), sleep_src='sex-dependent; mated females ~150-200 min day sleep, males ~300-400 min, plus night sleep',
        expansion=dict(layer='mushroom-body Kenyon cells', n_in=69, measured_K=(4.4, 5.4),
                       K_src='FlyWire: uniglomerular PN inputs per KC, >=5 to >=1 synapse thresholds'),
    ),
    'zebrafish': dict(
        name='Zebrafish (Danio rerio), larva 6-7 dpf',
        neurons=100_000, neurons_src='~100,000 neurons in the larval brain (whole-brain imaging literature)',
        synapses=None,
        super_classes=None, cell_classes=None, cell_types=None,
        types_src='2025 CNS morphology atlas (>20,000 traced neurons) and 2025 CLEM connectomic resource; no full census yet',
        nt_neurons=None,
        nt_list=['glutamate', 'GABA', 'glycine', 'acetylcholine', 'dopamine', 'noradrenaline', 'serotonin',
                 'histamine', 'hypocretin and other peptides', 'melatonin (pineal)'],
        nt_src='glycine is a major fast inhibitory transmitter in hindbrain and spinal cord, unlike mammalian forebrain',
        T_body=28.5, supply='capillary neurovascular units (vertebrate)',
        brain_power_W=None, brain_glucose_umol_g_min=None,
        sleep_h=None, sleep_src='larval sleep present; synapse dynamics measured (Suppermpool et al. 2024)',
        expansion=dict(layer='cerebellar granule cells', n_in=None, measured_K=(3, 7),
                       K_src='3-7 dendrites, one mossy-fibre bouton each (Knogler et al. 2017, larval zebrafish)'),
    ),
    'rat': dict(
        name='Rat (Rattus norvegicus)',
        neurons=200.13e6, neurons_src='Herculano-Houzel 2011 Table 1',
        cortex_neurons=31e6,
        brain_mass_g=1.802, brain_glucose_umol_min=1.225, brain_glucose_umol_g_min=0.68,
        interneuron_fraction=(0.15, 0.25), interneuron_src='rodent cortex 15-25% GABAergic (Povysheva et al. 2008 review)',
        synapses_per_cortical_neuron=8000, syn_src='Attwell & Laughlin 2001 rodent assumption; mouse V1 ~9,700 (Wildenberg et al. 2021)',
        cell_types_proxy=dict(classes=34, subclasses=338, supertypes=1201, clusters=5322,
                              src='mouse whole-brain atlas (Yao et al. 2023) as rodent proxy'),
        nt_list=['glutamate', 'GABA', 'glycine', 'acetylcholine', 'dopamine', 'noradrenaline', 'serotonin', 'histamine'],
        T_body=37.0, supply='capillary neurovascular units',
        sleep_h=12.6, sleep_src='Siegel compilation',
        expansion=dict(layer='cerebellar granule cells', measured_K=(3, 7), K_typical=4,
                       K_src='~4 mossy-fibre inputs per granule cell across mammals'),
    ),
    'macaque': dict(
        name='Rhesus macaque (Macaca mulatta)',
        neurons=6.38e9, neurons_src='Herculano-Houzel 2011 Table 1 (monkey)',
        brain_mass_g=87.346, brain_glucose_umol_min=31.444, brain_glucose_umol_g_min=0.36,
        interneuron_fraction=(0.25, 0.34), interneuron_src='primate cortex 25-34% GABAergic (Povysheva et al. 2008 review)',
        synapses_per_cortical_neuron=6000, syn_src='macaque V1 ~6,000 vs mouse ~9,700 synapses per neuron (Wildenberg et al. 2021)',
        cell_types_src='rhesus multi-omic atlas, 4.2 M cells (Chiou et al. 2023); claustrum 48 types (Cell 2025)',
        nt_list=['glutamate', 'GABA', 'glycine', 'acetylcholine', 'dopamine', 'noradrenaline', 'serotonin', 'histamine'],
        T_body=37.0, supply='capillary neurovascular units',
        sleep_h=(11.1, 11.8), sleep_src='46.4% of 24 h by telemetry (Hsieh et al. 2008); 11.8 h (Siegel compilation)',
        expansion=dict(layer='cerebellar granule cells', measured_K=(3, 7), K_typical=4,
                       K_src='~4 mossy-fibre inputs per granule cell across mammals'),
    ),
}

# extra mammals used only to test the sleep law (Herculano-Houzel 2011 glucose; Siegel sleep compilation)
SLEEP_EXTRA = {
    'mouse': dict(glucose=0.89, sleep=12.1),
    'squirrel': dict(glucose=0.60, sleep=14.9),
    'baboon': dict(glucose=0.44, sleep=10.3),
    'human': dict(glucose=0.31, sleep=8.0),
}
