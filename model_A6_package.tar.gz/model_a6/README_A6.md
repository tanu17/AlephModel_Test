# Model A.6 code package

Run from this folder with `PYTHONPATH=.` after `bash get_data.sh` (public GitHub data: FlyWire, Allen, MICrONS,
Suppermpool zebrafish, Rdatasets mammals).

| Script | Purpose | Output |
|---|---|---|
| a5_review.py | numerical checks of the A.5 report | results/a5_review.json |
| a6_mesh.py | capillary mesh: Longden 2017, Blinder 2013 occlusion, Kir2.1 KO, Hall 2014, point-spread, domain edges | results/a6_mesh.json |
| a6_metabolism.py | six-pool metabolism: rest calibration, activation predictions, glycogen tests, ledgers, Jacobian | results/a6_metabolism.json |
| a6_ais.py | AIS plasticity: excitability law, Evans/Jamann/Kuba/Grubb, controller uniqueness | results/a6_ais.json |
| a6_hfo.py | spiking layer: ripples, channel noise, PV block, sprouting, fast ripples | results/a6_hfo.json |
| a6_tissue.py | mesh + metabolism coupled: activation and occlusion | results/a6_tissue.json |
| a6_math.py | invariance, REM barrier, Kirchhoff, ledgers, theta, ephaptic | results/a6_math.json |
| a6_zebrafish.py, a6b_zebrafish.py | sleep-gate variants (slow adenosine, circadian gain, dawn offset) | results/a6*_zebrafish.json (~30 min each) |
| a6_figures.py | report figures | results/fig_a*.png |

New modules: modela/mesh.py, modela/metabolism.py, modela/ais.py, modela/hfo.py.
Core changes (modela/core.py): Na+ driving-force factor (n_eq), projected REM step.
Earlier A.2-A.4 scripts remain for reference.
