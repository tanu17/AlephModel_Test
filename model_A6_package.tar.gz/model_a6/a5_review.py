"""Numerical checks of the claims that are new in the Model A.5 report (junior colleague's revision).

R1  human energetics (Section 4.3)
R2  theta-gamma slot capacity (Section 4.4)
R3  D1 -> HCN shunt (Eq. 4): can a monotonic Hill shunt produce an inverted-U?
R4  dCaAP term (Eq. 3) is undefined: what a Gidon-type dCaAP must do (XOR) and whether a monotone I(v) can
R5  glymphatic flow (Eq. 14) vs zolpidem (Hauglund et al. 2025)
R6  zebrafish 'type 4 immune' (delta_Type4 = 0) vs Suppermpool et al. 2024 morphology-type data
R7  fly reciprocity 1.38x vs FlyWire 19.7x
"""
import json, os, numpy as np, pandas as pd
os.makedirs('results', exist_ok=True)
R = {}
W_per = 2.87e6 * 1e-6 / 60                       # W per (umol glucose / min), complete oxidation

# R1
R['R1_human_energy'] = dict(
    A5=dict(glucose_umol_min=280, cmr_umol_g_min=0.31, power_W=20.0, per_neuron=3.25e-9),
    implied_brain_mass_g=280 / 0.31, power_from_280_W=280 * W_per,
    HH2011=dict(glucose_umol_min=467.762, mass_g=1508.91, per_neuron=467.762 / 86.06e9, power_W=467.762 * W_per),
    verdict='3.25e-9 = 280 / 86.1e9 is circular; HH 2011 gives 5.44e-9; 280 umol/min is ~13.4 W and implies a 903 g brain')

# R2
cap = lambda ft, fg: fg / ft
R['R2_theta_gamma'] = dict(A5_bands=[cap(5, 35), cap(3, 45)], A5_periods=[0.210 / 0.035, 0.210 / 0.025],
                           rodent_7Hz_40Hz=cap(7, 40),
                           verdict='3-5 Hz theta with 35-45 Hz gamma gives 7-15 slots, not 4-7; the 4-7 range needs theta ~6-8 Hz')

# R3 inverted-U: delay-cell selectivity d' vs dopamine
DA = np.linspace(0, 3, 301)
hill = lambda x, K, n: x**n / (K**n + x**n)
def dprime(DA, with_rising_limb):
    shunt = 1 / (1 + 4.0 * hill(DA, 1.2, 3))          # A.5 Eq. 4: g_HCN Hill in DA, divisive shunt of dendritic gain
    pref = 20 * shunt
    nonpref = 10 * shunt * ((1 - 0.8 * hill(DA, 0.4, 2)) if with_rising_limb else 1)
    return (pref - nonpref) / np.sqrt(pref + nonpref + 1)
dA5 = dprime(DA, False); dA6 = dprime(DA, True)
R['R3_HCN_inverted_U'] = dict(A5_monotone_decreasing=bool(np.all(np.diff(dA5) <= 1e-12)),
                              A5_argmax_DA=float(DA[np.argmax(dA5)]),
                              A6_argmax_DA=float(DA[np.argmax(dA6)]), A6_peak_over_DA0=float(dA6.max() / dA6[0]),
                              A6_high_DA_over_peak=float(dA6[-1] / dA6.max()),
                              note='a single monotonic Hill shunt can only lower selectivity; the rising limb needs a second D1 effect '
                                   '(suppression of non-preferred firing: Arnsten 2011; NMDA/GABA mechanisms; Gamo 2015 for HCN)')
np.save('results/r3_DA.npy', np.vstack([DA, dA5, dA6]))

# R4 dCaAP XOR: output for inputs (A, B) under monotone vs Gidon-type activation
def dcaap(I, kind, Ith=1.0, w=0.6):
    if kind == 'monotone': return 1 / (1 + np.exp(-(I - Ith) / 0.1))
    return np.where(I >= Ith, np.exp(-(I - Ith) / w), 0.0)          # largest at threshold, damped above
xor = {}
for kind in ('monotone', 'gidon'):
    out = {f'{a}{b}': float(dcaap(1.1 * a + 1.1 * b, kind) > 0.5) for a in (0, 1) for b in (0, 1)}
    xor[kind] = dict(truth_table=out, is_XOR=out == {'00': 0.0, '01': 1.0, '10': 1.0, '11': 0.0})
R['R4_dCaAP'] = dict(results=xor, note='A.5 writes I_dCaAP(v_d) but never defines it; XOR needs amplitude that falls for stronger input')

# R5 glymphatic Eq. 14 vs zolpidem (Hauglund et al. 2025: zolpidem lowers mean NE ~50%, suppresses NE oscillations and inflow)
sig = lambda z: 1 / (1 + np.exp(-z))
def v_A5(NE_mean): return 0.1 + 1.0 * (1 - sig((NE_mean - 0.5) / 0.1))
def v_A6(NE_mean, NE_osc_amp): return 0.1 + 1.0 * NE_osc_amp / (NE_osc_amp + 0.1) * (1 - sig((NE_mean - 0.8) / 0.1))
nrem = dict(NE_mean=0.5, osc=0.3); zolp = dict(NE_mean=0.25, osc=0.05)
R['R5_glymph_zolpidem'] = dict(A5_ratio_zolpidem_over_NREM=v_A5(zolp['NE_mean']) / v_A5(nrem['NE_mean']),
                               A6_ratio=v_A6(zolp['NE_mean'], zolp['osc']) / v_A6(nrem['NE_mean'], nrem['osc']),
                               observed='inflow reduced under zolpidem (Hauglund et al. 2025, Cell 188:606)',
                               note='Eq. 14 makes flow rise as mean NE falls, so it predicts zolpidem raises clearance')

# R6 zebrafish morphology types
d = pd.read_excel('/tmp/data/zfsyn/Figure2.xlsx', sheet_name='2f_g')
t = d.groupby(['type', 'time']).av_Puncta_diff.agg(['mean', 'sem', 'count']).round(2)
R['R6_zebrafish_types'] = dict(table={f'type{int(k[0]) + 1}_{k[1]}': v for k, v in t.to_dict('index').items()},
                               note='evening = day change (ZT0-10), morning = night change; paper type n = index + 1')

# R7
R['R7_fly_reciprocity'] = dict(A5_claim=1.38, FlyWire_observed_vs_config=19.7, MICrONS_mouse_vs_config=1.37,
                               note='1.38x is the mouse L2/3 benchmark; FlyWire is 19.7x; asymmetric STDP lowers reciprocity')
json.dump(R, open('results/a5_review.json', 'w'), indent=1, default=float)
print(json.dumps(R, indent=1, default=float)[:4000])
