"""Model A.6 validation, caveat 3: axon initial segment plasticity.

E1 excitability law vs Gulledge & Bravo 2016 (rheobase change for +/-50 % AIS length)
E2 Kuba et al. 2010: length x1.7 after deprivation, threshold -4 mV
E3 Jamann et al. 2021: deprivation lengthens AIS by ~5 um (+17-21 %), rheobase -50 pA, voltage threshold unchanged
E4 Grubb & Burrone 2010: 17 um distal shift, length unchanged, current threshold +100 pA, R_in 301 -> 175 MOhm
E5 kinetics: Evans et al. 2015 (15 mM K+, 3 h: 19.6 -> 14.8 um, recovery from 6 h, complete by 24 h) calibrates
   tau_L and G_L; predicted: Jamann enriched-environment shortening (1-3 h) and reversal by 6 h
E6 controller structure: pure-integral AIS + homeostatic threshold (line of equilibria) vs leaky AIS
"""
import json, os, numpy as np
from scipy import optimize
from modela import ais

os.makedirs('results', exist_ok=True)
R = {}
p = dict(ais.DEFAULT)
gap = 20.0                        # mV between rest and threshold, so rheobase change = d(theta)/gap at fixed R_in

# E1
for frac in (1.5, 0.5):
    R[f'E1_length_x{frac}'] = dict(theta_shift_mV=float(-p['k_B'] * np.log(frac)),
                                   rheobase_change_pct=float(100 * -p['k_B'] * np.log(frac) / gap))
R['E1_observed'] = {'x1.5': [-10.2, -5.2], 'x0.5': [14.3, 21.3], 'source': 'Gulledge & Bravo 2016 (morphology-dependent range)'}
# E2
R['E2_kuba'] = dict(theta_shift_mV=float(-p['k_B'] * np.log(1.7)), observed=-4.0,
                    Goethals_Brette_prediction=-5.2)
# E3
for lab, L0_, L1_ in (('P15', 30.8, 35.8), ('P21', 25.6, 31.0)):
    d = -p['k_B'] * np.log(L1_ / L0_)
    R[f'E3_jamann_{lab}'] = dict(length_change_pct=100 * (L1_ / L0_ - 1), theta_shift_mV=float(d),
                                 rheobase_change_pct=float(100 * d / gap))
R['E3_observed'] = dict(rheobase_pA=-50, voltage_threshold='unchanged',
                        note='for a 150-250 pA rheobase, -50 pA is -20 to -33 %')
# E4
dI_Rin = gap * 1e-3 * (1 / 175e6 - 1 / 301e6) * 1e12          # pA
R['E4_grubb'] = dict(theta_shift_position_mV=float(-p['k_x'] * np.log((p['x0'] + 17) / p['x0'])),
                     rheobase_change_from_Rin_pA=float(dI_Rin), observed_current_threshold_pA=100,
                     note='distal shift lowers voltage threshold in resistive-coupling theory; the measured rise in '
                          'current threshold is carried mostly by the fall in input resistance')
# E5 kinetics: calibrate tau_L, G_L on Evans 2015 (15 mM K+ for 3 h, then washout)
c_K = 3.0                                           # depolarisation drive of 15 mM K+ relative to normal (assumed)
def evans(tauL, GL):
    pp = {**p, 'tau_L': tauL, 'G_L': GL, 'L0': 19.6}
    t, L, x = ais.simulate(lambda t: c_K if t < 3 else 1.0, 30, p=pp)
    return t, L
def loss(z):
    t, L = evans(*z)
    i3 = np.argmin(np.abs(t - 3)); i6 = np.argmin(np.abs(t - 6)); i24 = np.argmin(np.abs(t - 24))
    return [(L[i3] - 14.8) / 0.5, (L[i24] - 19.6) / 0.5, (L[i6] - (L[i3] + 0.25 * (19.6 - L[i3]))) / 1.0]
sol = optimize.least_squares(loss, [5.0, 0.2], bounds=([0.5, 0.01], [24, 2]))
tauL, GL = sol.x
t, L = evans(tauL, GL)
R['E5_evans_fit'] = dict(tau_L_h=tauL, G_L=GL, L_at_3h=float(L[np.argmin(np.abs(t - 3))]), L_at_6h=float(L[np.argmin(np.abs(t - 6))]),
                         L_at_24h=float(L[np.argmin(np.abs(t - 24))]), observed=dict(L3h=14.8, recovery='begins by 6 h, complete by 24 h'),
                         assumed_drive_15mM_K=c_K)
np.save('results/ais_evans.npy', np.c_[t, L])
# prediction: enriched environment, 3 h exposure. Drive needed to give -3 um on L0 = 22 um, and reversal time
def ee(c_EE):
    pp = {**p, 'tau_L': tauL, 'G_L': GL, 'L0': 22.0}
    return ais.simulate(lambda t: c_EE if t < 3 else 1.0, 30, p=pp)
c_EE = optimize.brentq(lambda c: ee(c)[1].min() - 19.0, 1.0, 5.0)
t2, L2, _ = ee(c_EE)
rev = t2[np.where((t2 > 3) & (L2 > 22 - 0.5))[0][0]] if np.any((t2 > 3) & (L2 > 21.5)) else np.nan
R['E5_jamann_EE_prediction'] = dict(drive_needed=c_EE, time_back_within_0p5um_h=float(rev),
                                    observed='-3 um after 1-3 h, reversed by 6 h')
print(json.dumps(R, indent=1, default=float)[:2500])

# E6 controller structure (rate neuron, noise in input)
def run(leaky, T=4000.0, dt=0.05, seed=0):
    rng = np.random.default_rng(seed)
    th, L = 0.0, 22.0; rho = 4.0; out = []
    for k in range(int(T / dt)):
        I = 5.0 + 1.5 * rng.standard_normal()
        drive = I - th - (-5 * np.log(L / 22.0))
        r = 10 * np.log1p(np.exp(drive - 3)) / 2
        th += dt * (r - rho) / 20.0
        if leaky: L += dt * (-(L - 22.0) / 50.0 - 0.05 * (r - rho))
        else:     L += dt * (-0.05 * (r - rho))
        L = min(max(L, 8.0), 45.0)
        if k % 200 == 0: out.append((k * dt, th, L, r))
    return np.array(out)
offs = {lk: [abs(run(lk, seed=s_)[-1, 2] - 22.0) for s_ in range(6)] for lk in (False, True)}
pure = run(False); leak = run(True)
def drift(a): n = len(a) // 2; return float(np.var(a[n:, 2])), float(np.abs(a[-1, 2] - 22.0))
R['E6_controllers'] = dict(final_offset_um_6_seeds=dict(pure=offs[False], leaky=offs[True]),
                           mean_offset_pure=float(np.mean(offs[False])), mean_offset_leaky=float(np.mean(offs[True])),pure_integral_L_variance_late=drift(pure)[0], pure_integral_L_final_offset=drift(pure)[1],
                           leaky_L_variance_late=drift(leak)[0], leaky_L_final_offset=drift(leak)[1],
                           pure_hits_bound=bool(np.any(pure[:, 2] <= 8.0) or np.any(pure[:, 2] >= 45.0)),
                           note='two integrators on one error leave theta + k ln L fixed and let the split between them '
                                'random-walk; the leaky AIS term restores a unique equilibrium (theta*, L0)')
np.save('results/ais_controllers.npy', np.stack([pure, leak]))
print(R['E6_controllers'])
json.dump(R, open('results/a6_ais.json', 'w'), indent=1, default=float)
