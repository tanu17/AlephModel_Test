"""Figures for the Model A.6 report."""
import json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from modela.mesh import CapillaryMesh
from modela import metabolism as M

plt.rcParams.update({'font.size': 9.5, 'axes.spines.top': False, 'axes.spines.right': False, 'figure.dpi': 150})
GREY, BLUE, RED, LIGHT = '#6b6b6b', '#1f5fa8', '#b5473a', '#bdbdbd'
J = lambda f: json.load(open(f'results/{f}'))

# ---------------------------------------------------------------- F1 mesh
mj = J('a6_mesh.json'); mesh = CapillaryMesh(seed=0)
act = np.load('results/mesh_rel_flow.npy')
fig, axs = plt.subplots(1, 4, figsize=(14, 3.6))
ax = axs[0]
for a, b in mesh.E: ax.plot(*mesh.xy[[a, b]].T, color=LIGHT, lw=0.5)
sc = ax.scatter(act[:, 0], act[:, 1], c=act[:, 2], cmap='Blues', s=6, vmin=0, vmax=0.4)
ax.scatter(*mesh.xy[mesh.art].T, color=RED, s=18, marker='^', label='arteriole'); ax.scatter(*mesh.xy[mesh.ven].T, color=GREY, s=8, marker='s', label='venule')
ax.set_aspect('equal'); ax.set_xticks([]); ax.set_yticks([]); ax.legend(fontsize=7, loc='lower left', frameon=True)
ax.set_title('Mesh: flow rise after activation', fontsize=9); plt.colorbar(sc, ax=ax, fraction=0.04, label='flow change')
ax = axs[1]
prof = mj['V2_blinder_occlusion']['median_flow_ratio_by_branch_order']
ax.plot([int(k) for k in prof], list(prof.values()), 'o-', color=BLUE, label='A.6 mesh')
ax.axvline(6, color='k', ls=':', lw=1); ax.axvline(10, color='k', ls='--', lw=1)
ax.text(6.2, 0.15, 'Blinder 2013:\nhalf by 6,\nfull by ~10', fontsize=7.5)
ax.set_xlabel('branches from occluded arteriole'); ax.set_ylabel('flow, occluded / baseline'); ax.set_title('Occlusion: recovery too fast (half by 3-4)', fontsize=9)
ax = axs[2]
dose = mj['V1_dose_response_dilation_pct']; ks = [float(k) for k in dose]
ax.plot(ks, list(dose.values()), 'o-', color=BLUE, label='A.6')
ax.axvspan(6, 7, color='#e8eef7'); ax.text(6.1, 40, 'threshold\n6-7 mM', fontsize=7.5)
ax.scatter([25, 60], [0, 0], color='k', marker='x', label='Longden: no sustained\ndilation at 25, 60 mM')
ax.set_xlabel('K+ puff (mM)'); ax.set_ylabel('arteriole dilation (%)'); ax.legend(fontsize=7, frameon=False)
ax.set_title('K+ dose-response (graded 7-10 mM)', fontsize=9)
ax = axs[3]
v5 = mj['V5_domain_vs_mesh']
ax.bar([0, 1, 2], [v5['mean_abs_jump_domain'], v5['mean_abs_jump_mesh'], v5['mean_abs_diff_same_domain_mesh']], color=[RED, BLUE, LIGHT])
ax.set_xticks([0, 1, 2]); ax.set_xticklabels(['domains (A.5)\nacross edge', 'mesh (A.6)\nacross edge', 'mesh\nwithin domain'], fontsize=8)
ax.set_ylabel('supply difference, neurons < 25 um apart'); ax.set_title('Domain edges create 4.6x jumps; mesh is smooth', fontsize=9)
fig.tight_layout(); fig.savefig('results/fig_a6_mesh.png'); plt.close()

# ---------------------------------------------------------------- F2 metabolism
met = J('a6_metabolism.json'); pr = met['activation']['phi=0.5']['predictions']
fig, axs = plt.subplots(1, 3, figsize=(13, 3.8))
ax = axs[0]
labs = ['Lin 4 Hz', 'Lin 8 Hz', 'Lin 16 Hz', 'Fox 1988', 'Leontiev\n(calibr.)']
obs = [0.170, 0.134, 0.122, 0.05, 0.272]; pred = [pr[k]['CMRO2'] for k in ('Lin2010_4Hz', 'Lin2010_8Hz', 'Lin2010_16Hz', 'Fox1988', 'Leontiev2007')]
x = np.arange(5); ax.bar(x - 0.2, obs, 0.4, color=GREY, label='observed'); ax.bar(x + 0.2, pred, 0.4, color=BLUE, label='A.6 predicted')
ax.set_xticks(x); ax.set_xticklabels(labs, fontsize=8); ax.set_ylabel('CMRO2 rise'); ax.legend(fontsize=8, frameon=False)
ax.set_title('CMRO2 at the measured CBF: right at 4 Hz, 2x high at 8-16 Hz', fontsize=9)
ax = axs[1]
names = ['lactate rise\n(Mangia, Lin)', 'CMRglc rise\n(Fox +51%)', 'OGI change\n(Madsen -9%)', 'aglycaemia\nratio (Wender)', 'hypoglycaemic\nglycogen (Oz)']
o = [0.265, 0.51, -0.09, 1.44, 0.50]; lo = [0.23, 0.51, -0.09, 1.44, 0.40]; hi = [0.30, 0.51, -0.09, 1.44, 0.60]
gm = met['hypoglycaemia_Oz2009']['glycogen_mobilised_umol_g_2h']; ag = met['aglycaemia_Wender2000']['predicted_ratio_high_over_control']
p_ = [pr['Leontiev2007']['lactate_pct'], pr['Fox1988']['CMRglc'], pr['Leontiev2007']['OGI'] / 5.3 - 1, ag, gm]
for i in range(5):
    ax.plot([i, i], [lo[i], hi[i]], color=GREY, lw=6, alpha=0.5); ax.plot(i, o[i], '_', color='k', ms=18, mew=2)
    ax.plot(i, p_[i], 'o', color=BLUE, ms=8)
ax.set_xticks(range(5)); ax.set_xticklabels(names, fontsize=7.5); ax.axhline(0, color=LIGHT, lw=0.8)
ax.set_title('Predictions (blue) vs data (black, grey range)', fontsize=9)
ax = axs[2]
P, x0 = M.calibrate(phi=0.5, chi_g=met['calibrated_activation']['chi_g'], L_b=met['calibrated_activation']['L_b'])
A = met['activation']['phi=0.5']['A_leontiev']; kf = met['activation']['phi=0.5']['kappa_f']
drive = lambda t: dict(f=1 + kf * A, u=1 + A, D=P['D0'] * (1 + A)) if 60 <= t < 660 else {}
t, X, F = M.simulate(P, x0, 1200, dt=0.05, drive=drive, record_every=5)
ax.plot(t / 60, X[:, 1] / x0[1] - 1, color=BLUE, label='lactate'); ax.plot(t / 60, X[:, 5] / x0[5] - 1, color=GREY, label='ATP')
ax.plot(t / 60, X[:, 2] / x0[2] - 1, color=RED, label='glycogen')
ax.axvspan(1, 11, color='#e8eef7'); ax.set_xlabel('min'); ax.set_ylabel('relative change'); ax.legend(fontsize=8, frameon=False)
ax.set_title('Activation: lactate rises to a plateau, ATP dips 15%', fontsize=9)
fig.tight_layout(); fig.savefig('results/fig_a6_metabolism.png'); plt.close()

# ---------------------------------------------------------------- F3 AIS
aj = J('a6_ais.json'); ev = np.load('results/ais_evans.npy'); ctl = np.load('results/ais_controllers.npy')
fig, axs = plt.subplots(1, 3, figsize=(13, 3.6))
ax = axs[0]; ax.plot(ev[:, 0], ev[:, 1], color=BLUE, label='A.6 (tau_L fitted)')
ax.errorbar([3], [14.8], yerr=[0.2], fmt='o', color='k', label='Evans 2015, 3 h')
ax.axvspan(0, 3, color='#e8eef7'); ax.axhline(19.6, color=LIGHT, ls=':'); ax.text(14, 19.8, 'recovered by 24 h (data)', fontsize=7.5)
ax.set_xlabel('h'); ax.set_ylabel('AIS length (um)'); ax.legend(fontsize=8, frameon=False); ax.set_title('15 mM K+ for 3 h, then washout', fontsize=9)
ax = axs[1]
cases = ['+50% length', '-50% length', 'Jamann P15', 'Jamann P21']
pv = [aj['E1_length_x1.5']['rheobase_change_pct'], aj['E1_length_x0.5']['rheobase_change_pct'],
      aj['E3_jamann_P15']['rheobase_change_pct'], aj['E3_jamann_P21']['rheobase_change_pct']]
rng_ = [(-10.2, -5.2), (14.3, 21.3), (-33, -20), (-33, -20)]
for i, (a, b) in enumerate(rng_): ax.plot([i, i], [a, b], color=GREY, lw=7, alpha=0.5)
ax.plot(range(4), pv, 'o', color=BLUE, ms=8); ax.axhline(0, color=LIGHT)
ax.set_xticks(range(4)); ax.set_xticklabels(cases, fontsize=8); ax.set_ylabel('rheobase change (%)')
ax.set_title('Length law fits Gulledge & Bravo; under-predicts Jamann', fontsize=9)
ax = axs[2]
ax.plot(ctl[0][:, 0], ctl[0][:, 2], color=RED, label='pure integral AIS (drifts)')
ax.plot(ctl[1][:, 0], ctl[1][:, 2], color=BLUE, label='leaky AIS (A.6)')
ax.axhline(22, color=LIGHT, ls=':'); ax.set_xlabel('time (model units)'); ax.set_ylabel('AIS length (um)'); ax.legend(fontsize=8, frameon=False)
ax.set_title('Two integrators on one error: no unique equilibrium', fontsize=9)
fig.tight_layout(); fig.savefig('results/fig_a6_ais.png'); plt.close()

# ---------------------------------------------------------------- F4 HFO
hj = J('a6_hfo.json')
fig, axs = plt.subplots(1, 3, figsize=(13, 3.8), gridspec_kw=dict(width_ratios=[1, 1, 1.4]))
for ax, fn, ttl in ((axs[0], 'normal', 'Normal: 148 Hz ripple'), (axs[1], 'PV', 'PV block + sprouting: fast ripple')):
    sp = np.load(f'results/hfo_{fn}.npy'); s = sp[(sp[:, 0] > 60) & (sp[:, 0] < 90)]
    ax.scatter(s[:, 0], s[:, 1], s=1.5, c=np.where(s[:, 1] < 400, GREY, RED)); ax.set_xlabel('ms'); ax.set_ylabel('cell (red = PV)')
    ax.set_title(ttl, fontsize=9)
ax = axs[2]
order = ['normal', 'channel noise 1 mV', 'channel noise 3 mV', 'channel noise 6 mV', 'PV block only', 'sprouting only, normal drive',
         'PV block + weaker sprouting', 'PV block + sprouting']
lab = ['normal', 'noise 1 mV', 'noise 3 mV', 'noise 6 mV', 'PV block', 'sprouting', 'PV block +\nweak sprout', 'PV block +\nsprouting']
pk = [hj[k]['peak_E_Hz']['mean'] for k in order]; sd = [hj[k]['peak_E_Hz']['sd'] for k in order]
cols = [BLUE if p < 250 else RED for p in pk]
ax.bar(range(len(order)), pk, yerr=sd, color=cols)
ax.axhspan(140, 220, color='#e8eef7', zorder=0); ax.axhspan(250, 600, color='#f6e6e3', zorder=0)
ax.text(7.6, 160, 'ripple', fontsize=7.5); ax.text(7.6, 520, 'fast ripple', fontsize=7.5)
ax.set_xticks(range(len(order))); ax.set_xticklabels(lab, fontsize=7, rotation=35, ha='right'); ax.set_ylabel('spectral peak (Hz)')
ax.set_title('Channel noise never yields fast ripples; PV block + sprouting does', fontsize=9)
fig.tight_layout(); fig.savefig('results/fig_a6_hfo.png'); plt.close()

# ---------------------------------------------------------------- F5 A.5 review checks
rv = J('a5_review.json'); DA = np.load('results/r3_DA.npy')
fig, axs = plt.subplots(1, 3, figsize=(13, 3.6))
ax = axs[0]; ax.plot(DA[0], DA[1] / DA[1].max(), color=RED, label='A.5: HCN Hill shunt only'); ax.plot(DA[0], DA[2] / DA[2].max(), color=BLUE, label='A.6: + D1 non-preferred suppression')
ax.set_xlabel('dopamine (rel.)'); ax.set_ylabel("delay-cell selectivity d' (norm.)"); ax.legend(fontsize=8, frameon=False)
ax.set_title('Inverted-U needs a rising limb', fontsize=9)
ax = axs[1]
t = rv['R6_zebrafish_types']['table']
for i, ty in enumerate(['type1', 'type2', 'type3', 'type4']):
    ax.bar(i - 0.2, t[f'{ty}_evening']['mean'], 0.4, yerr=t[f'{ty}_evening']['sem'], color=GREY, label='day' if i == 0 else None)
    ax.bar(i + 0.2, t[f'{ty}_morning']['mean'], 0.4, yerr=t[f'{ty}_morning']['sem'], color=BLUE, label='night' if i == 0 else None)
ax.axhline(0, color=LIGHT); ax.set_xticks(range(4)); ax.set_xticklabels(['type 1', 'type 2', 'type 3', 'type 4\n(A.5: delta=0)'], fontsize=8)
ax.set_ylabel('synapse change'); ax.legend(fontsize=8, frameon=False); ax.set_title('Type 4 loses 8 synapses at night', fontsize=9)
ax = axs[2]
vals = [rv['R5_glymph_zolpidem']['A5_ratio_zolpidem_over_NREM'], rv['R5_glymph_zolpidem']['A6_ratio']]
ax.bar([0, 1], vals, color=[RED, BLUE]); ax.axhline(1, color='k', lw=0.8, ls=':')
ax.set_xticks([0, 1]); ax.set_xticklabels(['A.5 Eq. 14\n(mean NE)', 'A.6\n(NE oscillation)'])
ax.set_ylabel('glymphatic flow, zolpidem / NREM'); ax.text(0.6, 1.05, 'Hauglund 2025: zolpidem lowers inflow', fontsize=7.5)
ax.set_title('Zolpidem test of the glymphatic term', fontsize=9)
fig.tight_layout(); fig.savefig('results/fig_a5_review.png'); plt.close()

# ---------------------------------------------------------------- F6 integrated tissue
ta = np.load('results/tissue_activation.npy'); to = np.load('results/tissue_occlusion.npy')
fig, axs = plt.subplots(1, 3, figsize=(13, 3.8))
for ax, v, ttl, cm, lim in ((axs[0], ta[2] - 1, 'Flow change (activation)', 'Blues', (0, 0.5)),
                            (axs[1], ta[3] - 1, 'CMRO2 change (activation)', 'Oranges', (0, 0.3)),
                            (axs[2], to[3], 'ATP after arteriole occlusion', 'Greys_r', (0, 1))):
    sc = ax.scatter(ta[0], ta[1], c=v, cmap=cm, s=8, vmin=lim[0], vmax=lim[1]); ax.set_aspect('equal'); ax.set_xticks([]); ax.set_yticks([])
    ax.set_title(ttl, fontsize=9); plt.colorbar(sc, ax=ax, fraction=0.04)
fig.suptitle('Coupled mesh + metabolism: oxygen use rises in the active disc, but extra flow spreads beyond it', fontsize=10)
fig.tight_layout(); fig.savefig('results/fig_a6_tissue.png'); plt.close()
print('ok')
