"""Model A.6 validation, caveat 4: physiological ripples and pathological fast ripples.

Conditions (5 seeds each):
  normal                      PING ripple (target 140-220 Hz rodent; induced ripples median 148 Hz, Stark 2014)
  channel noise 1/3/6 mV      the A.5 hypothesis: does stochastic channel noise create >250 Hz fast ripples?
  PV collapse only            perisomatic inhibition at 10 % (Schlingloff et al. 2025)
  sprouting only              two recurrent E clusters (pathologically interconnected clusters), PV intact
  PV collapse + sprouting     hippocampal-sclerosis configuration (target FR 250-600 Hz; out-of-phase clusters
                              2.2-3.4 ms apart, Ibarz et al. 2010)
Energy: spikes per pyramidal cell per event (each spike loads Na+, A.2 ledger) for ripple vs fast ripple.
"""
import json, os, numpy as np
from modela import hfo

os.makedirs('results', exist_ok=True)
CLU = dict(clusters=2, cluster_size=150, pEE_in=0.3, wEE_in=0.15, pEE_out=0.0)
conds = {'normal': {}, 'channel noise 1 mV': dict(sigma_ch=1.0), 'channel noise 3 mV': dict(sigma_ch=3.0),
         'channel noise 6 mV': dict(sigma_ch=6.0), 'PV block only': dict(I_silent=True, gdrive_E=0.35),
         'sprouting only': dict(CLU, gdrive_E=0.35), 'sprouting only, normal drive': dict(CLU),
         'PV block + sprouting': dict(CLU, I_silent=True, gdrive_E=0.35),
         'PV block + weaker sprouting': dict(CLU, I_silent=True, gdrive_E=0.35, wEE_in=0.08)}
R = {}
for name, cfg in conds.items():
    rs = [hfo.analyse(*hfo.run_event(cfg, seed=s)) for s in range(5)]
    keys = rs[0].keys()
    R[name] = {k: dict(mean=float(np.nanmean([r.get(k, np.nan) for r in rs])), sd=float(np.nanstd([r.get(k, np.nan) for r in rs])))
               for k in keys}
    R[name]['per_seed_peak_Hz'] = [r['peak_Hz'] for r in rs]
    print(name, {k: round(v['mean'], 2) for k, v in R[name].items() if isinstance(v, dict)})
# raster + rate examples for the figure
for name in ('normal', 'PV block + sprouting'):
    sp, info = hfo.run_event(conds[name], seed=0)
    np.save(f"results/hfo_{name.split()[0]}.npy", sp)
R['targets'] = dict(ripple_rodent_Hz=[140, 220], ripple_induced_median_Hz=148, ripple_human_Hz=[96, 14],
                    FR_Hz=[250, 600], FR_human_Hz=[262, 59], cluster_lag_ms=[2.2, 3.4])
json.dump(R, open('results/a6_hfo.json', 'w'), indent=1, default=float)
