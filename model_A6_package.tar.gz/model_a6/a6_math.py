"""Model A.6 mathematical verification.

T1  forward invariance after the A.6 repairs: (a) Na+ load bounded by n_eq at zero ATP; (b) capture variable with
    the (1-c) factor and multiplicative noise stays in [0,1] (vs A.5's additive noise)
T3  headroom barrier across the projected REM jump
K   Kirchhoff flow conservation on the capillary mesh
M   metabolism ledgers and local stability (from a6_metabolism.json)
A   AIS controller uniqueness (from a6_ais.json)
TH  theta phase law d(phi)/dt = omega_theta + 2 pi v / L: precession independent of rate and speed
EP  two-compartment ephaptic coupling: uniform field gives zero; gradient calibrated on Bikson et al. 2004
"""
import json, os, numpy as np
from modela.core import ModelA2
from modela.mesh import CapillaryMesh

os.makedirs('results', exist_ok=True)
R = {}
# T1a
m = ModelA2(4, np.zeros(4, int), np.ones(4), np.zeros((4, 4)))
for _ in range(int(20 / 0.002)): m.step(0.002, 0.6)
m.J_scale[:] = 0.0; nmax = 0
for _ in range(int(600 / 0.002)):
    m.step(0.002, 0.6); nmax = max(nmax, float(m.n.max()))
R['T1a_sodium'] = dict(n_max_after_600s_at_zero_supply=nmax, n_eq=m.p['n_eq'], bounded=bool(nmax <= m.p['n_eq'] + 1e-9),
                       A4_A5_value='grew without bound (~0.06 per s; 23 after 400 s)')
# T1b
rng = np.random.default_rng(0)
def drift(c, beta=3.0, K=0.5, gam=1.0): return beta * c**2 * (1 - c) / (K**2 + c**2) - gam * c
out = {}
for noise in ('additive (A.5)', 'multiplicative c(1-c) (A.6)'):
    c = np.full(20000, 0.9); left = np.zeros(c.size, bool)
    for _ in range(4000):
        dW = np.sqrt(0.01) * rng.standard_normal(c.size)
        g = np.sqrt(2 * 0.01) if noise.startswith('add') else np.sqrt(2 * 0.05) * c * (1 - c)
        if noise.startswith('add'):
            c = c + 0.01 * (1.1 * c**2 / (0.25 + c**2) - c) + g * dW
        else:
            c = c + 0.01 * drift(c) + g * dW
        left |= (c < 0) | (c > 1)
    out[noise] = float(left.mean())
R['T1b_capture'] = dict(fraction_leaving_unit_interval=out,
                        note='with beta c^2 (1-c)/(K^2+c^2) the drift vanishes at c = 1 and is negative just below 0; the '
                             'diffusion sigma c(1-c) vanishes at both ends, so [0,1] is invariant for the SDE (boundary '
                             'classification: both ends are entrance/natural, not exit)')
# T3
N = 30; rng = np.random.default_rng(1)
m = ModelA2(N, np.zeros(N, int), np.ones(N), rng.uniform(0.2, 0.6, (N, N)))
m.plastic = np.ones((N, N), bool); np.fill_diagonal(m.plastic, False)
m.p['C_max'] = np.array([m.p['beta_w'] * (m.W * m.plastic).sum() * 1.02])
m.Om = (rng.random((N, N)) < 0.5) * 0.9
h0 = float(m.headroom()[0]); m.rem(); h1 = float(m.headroom()[0])
R['T3_REM_projection'] = dict(h_before=h0, h_after=h1, nonnegative=bool(h1 >= -1e-12), A4_A5_after=-0.011)
# K
mesh = CapillaryMesh(seed=0)
pr, q, nf, af = mesh.flows()
div = np.bincount(mesh.E[:, 0], weights=q, minlength=mesh.n) - np.bincount(mesh.E[:, 1], weights=q, minlength=mesh.n)
inner = np.setdiff1d(np.arange(mesh.n), np.r_[mesh.art, mesh.ven])
R['K_kirchhoff'] = dict(max_abs_divergence_interior=float(np.abs(div[inner]).max()), typical_flow=float(np.abs(q).mean()),
                        inflow_minus_outflow=float(af.sum() - (pr[mesh.ven] * 50.0 * mesh.p['r0']**4 / 50.0).sum()))
# M, A
met = json.load(open('results/a6_metabolism.json')); ais = json.load(open('results/a6_ais.json'))
R['M_metabolism'] = dict(carbon_ledger_rel_residual=met['ledger']['carbon_residual_rel'],
                         jacobian_max_real=met['jacobian_rest']['max_real'], timescales_s=met['jacobian_rest']['timescales_s'])
R['A_ais'] = dict(mean_offset_pure_integral_um=ais['E6_controllers']['mean_offset_pure'],
                  mean_offset_leaky_um=ais['E6_controllers']['mean_offset_leaky'])
# TH
def prec(r_peak, v, L=40.0, dt=0.001):
    x = np.arange(-L / 2, L / 2, v * dt)
    return 360 * (v * dt * len(x)) / L                     # integral of 2 pi v / L over the field, in degrees
R['TH_theta'] = {f'r={r} Hz, v={v} cm/s': prec(r, v) for r in (7.5, 15, 30) for v in (10, 20, 40)}
# EP two-compartment polarisation per field (mV per V/m) and uniform field
def polar(E_Vm, ell_mm=0.30, gs=1.0, gd=0.67, ga=20.0, uniform=False):
    dVe = 0.0 if uniform else -E_Vm * ell_mm                # mV (1 V/m = 1 mV/mm)
    D = dVe / (1 + ga / gd + ga / gs)                       # phi_d - phi_s
    return ga * D / gs * -1, -ga * D / gd * -1              # soma, dendrite transmembrane change (mV)
vs, vd = polar(1.0)
R['EP_ephaptic'] = dict(soma_mV_per_Vm=abs(vs), dendrite_mV_per_Vm=abs(vd), opposite_sign=bool(np.sign(vs) != np.sign(vd)),
                        uniform_field_soma_mV=polar(10.0, uniform=True)[0], Bikson2004=0.12,
                        parameters='soma-dendrite separation 0.30 mm, g_d/g_s = 0.67, strong axial coupling')
json.dump(R, open('results/a6_math.json', 'w'), indent=1, default=float)
print(json.dumps(R, indent=1, default=float)[:3000])
