"""Model A.6 validation, caveat 1: continuous capillary mesh with conducted signalling.

V1 Longden et al. 2017: 10 mM K+ puff (0.3 s) on a capillary ~130 um downstream of its arteriole.
   Calibrated: beta_a so that peak arteriole dilation = 33 %. Predicted: conduction velocity (2 mm/s), latency of
   the upstream signal at ~500 um (0.24 s), RBC-flux rise in the stimulated capillary (+73 +/- 23 %), K+ dose-response.
V2 Blinder et al. 2013: occluding one penetrating arteriole; flow recovers to half within ~6 branches, fully by ~10.
V3 Activation of a 100 um disc: Kir2.1 knockout leaves 51 % of the flow response (Longden; calibrates beta_c);
   predicted share of the response due to capillary dilation (Hall et al. 2014 report 84 %) and capillary-vs-arteriole
   onset lead (Hall: 1.38 s).
V4 Point-spread of the flow response; comparison with arteriole territory (~400 um, O'Herron et al. 2016).
V5 Discrete supply domains (A.5) vs the mesh: supply jump across a domain boundary.
"""
import json, os, numpy as np
from scipy import optimize
from scipy.spatial import cKDTree
from modela.mesh import CapillaryMesh

os.makedirs('results', exist_ok=True)
R = {}
mesh = CapillaryMesh(seed=0)
R['geometry'] = dict(nodes=mesh.n, segments=len(mesh.E), median_segment_um=float(np.median(mesh.l)),
                     interior_degree3=float((mesh.deg[mesh.deg >= 3] == 3).mean()), arterioles=len(mesh.art),
                     venules=len(mesh.ven), targets='Ji 2021: median 46 um, degree 3.02; Blinder 2013: 50 um, 93 % three-way')
c_art = mesh.art[np.argmin(np.linalg.norm(mesh.xy[mesh.art] - mesh.xy.mean(0), axis=1))]   # central arteriole
ai = int(np.where(mesh.art == c_art)[0][0])
d_from_art = np.linalg.norm(mesh.xy - mesh.xy[c_art], axis=1)
# the stimulated capillary must be fed by this arteriole (Longden picked capillaries downstream of the
# recorded arteriole): choose, among nodes ~130 um away, the one whose flow depends most on that arteriole
_, _, nf_b, _ = mesh._solve(); mesh.blocked[ai] = True; _, _, nf_o, _ = mesh._solve(); mesh.blocked[ai] = False
dep = 1 - nf_o / np.maximum(nf_b, 1e-12)
cand = np.where(np.abs(d_from_art - 130) < 30)[0]
cap = int(cand[np.argmax(dep[cand])])
d_from_cap = np.linalg.norm(mesh.xy - mesh.xy[cap], axis=1)
pr0, q0, nf0, af0 = mesh.flows()

def puff(kval, beta_a=None, T=15.0, dt=0.02, dur=0.3):
    if beta_a is not None: mesh.p['beta_a'] = beta_a
    mesh.reset(); ts, phis, ras, flux, artf = [], [], [], [], []
    for k in range(int(T / dt)):
        t = k * dt
        kk = np.full(mesh.n, mesh.p['k_rest'])
        # puff raises K+ for dur, then K+ is cleared with tau 2 s (uptake and diffusion)
        kk[cap] = kval if t < dur else mesh.p['k_rest'] + (kval - mesh.p['k_rest']) * np.exp(-(t - dur) / 2.0)
        mesh.step(dt, k=kk)
        if k % 2 == 0:
            ts.append(t); phis.append(mesh.phi.copy()); ras.append(mesh.ra[ai])
            fl_ = mesh.flows() if k % 10 == 0 else None
            flux.append(fl_[2][cap] if fl_ else np.nan); artf.append(fl_[3][ai] if fl_ else np.nan)
    puff.artf = np.array(artf)
    return np.array(ts), np.array(phis), np.array(ras), np.array(flux)

def upstream_node(dist, tol=40):
    cand = np.where(np.abs(mesh.Dpath[cap] - dist) < tol)[0]; return int(cand[np.argmax(mesh.G[cand, cap])])
far0 = upstream_node(500)
def phi500(AK):
    mesh.p['A_K'] = AK; return puff(10.0, T=1.5)[1][:, far0].max()
AK = optimize.brentq(lambda a: phi500(a) - 23.2, 1.0, 500.0, xtol=1e-2)
R['A_K_calibrated_mV'] = AK
beta = optimize.brentq(lambda b: puff(10.0, b, T=8)[2].max() / mesh.p['ra0'] - 1.33, 0.05, 20, xtol=1e-3)
ts, phis, ras, flux = puff(10.0, beta)
def onset(sig_, frac=0.1):
    pk = sig_.max(); i = np.where(sig_ >= frac * pk)[0]; return ts[i[0]] if len(i) else np.nan
far = [upstream_node(d) for d in (226, 500)]
t_half = [ts[np.where(phis[:, j] >= 0.5 * phis[:, j].max())[0][0]] for j in far]
vel = (mesh.Dpath[cap, far[1]] - mesh.Dpath[cap, far[0]]) / 1000 / max(t_half[1] - t_half[0], 1e-9)
fl = flux[np.isfinite(flux)]; tf = ts[np.isfinite(flux)]
R['V1_longden'] = dict(beta_a_calibrated=beta, arteriole_dilation_pct=float(100 * (ras.max() / mesh.p['ra0'] - 1)),
                       capillary_dist_from_arteriole_um=float(d_from_art[cap]),
                       conduction_velocity_mm_s_input=mesh.p['v_c'] / 1000, path_length_cap_to_arteriole_um=float(mesh.Dpath[cap, c_art]),
                       onset_latency_500um_s=float(onset(phis[:, far[1]])),
                       hyperpol_at_500um_mV=float(phis[:, far[1]].max()),
                       capillary_flux_rise_pct=float(100 * (fl.max() / fl[0] - 1)),
                       capillary_flux_time_to_peak_s=float(tf[np.argmax(fl)]),
                       arteriole_inflow_rise_pct=float(100 * (np.nanmax(puff.artf) / puff.artf[0] - 1)),
                       observed=dict(dilation=32.9, velocity=2.0, latency_500um=0.24, flux_rise=[73, 23], flux_latency=3.8))
dose = {}
for kv in (5.0, 6.0, 7.0, 8.0, 10.0, 25.0, 60.0):
    dose[kv] = float(100 * (puff(kv, T=8)[2].max() / mesh.p['ra0'] - 1))
R['V1_dose_response_dilation_pct'] = dose
print('V1', R['V1_longden'], dose)

# V2 occlusion
mesh.reset(); pr, q, nf, af = mesh.flows()
mesh.blocked[ai] = True; pr2, q2, nf2, af2 = mesh.flows(); mesh.blocked[ai] = False
depth = mesh.bfs_depth(c_art)
ed = np.minimum(depth[mesh.E[:, 0]], depth[mesh.E[:, 1]])
ratio = np.abs(q2) / np.maximum(np.abs(q), 1e-12)
prof = {int(d): float(np.median(ratio[ed == d])) for d in range(0, 16) if (ed == d).sum() >= 3}
half = next((d for d, v in prof.items() if v >= 0.5), None); full = next((d for d, v in prof.items() if v >= 0.9), None)
R['V2_blinder_occlusion'] = dict(median_flow_ratio_by_branch_order=prof, half_recovery_branch=half, ninety_pct_branch=full,
                                 observed=dict(half=6, full=10))
print('V2', half, full, prof)

# V3 activation disc, Kir KO, capillary share, timing
centre = mesh.xy[cap]; dc = np.linalg.norm(mesh.xy - centre, axis=1); disc = dc < 100
K_ACT = [8.5]
def activate(kir=True, pericyte=True, beta_c=None, T=25.0, dt=0.05, k_act=None):
    k_act = K_ACT[0] if k_act is None else k_act
    if beta_c is not None: mesh.p['beta_c'] = beta_c
    mesh.reset(); kk = np.where(disc, k_act, mesh.p['k_rest']); act = disc * 1.0
    tr_r_cap, tr_ra = [], []
    e_disc = np.where(disc[mesh.E[:, 0]] & disc[mesh.E[:, 1]])[0]
    for k in range(int(T / dt)):
        mesh.step(dt, k=kk, activity=act, kir=kir, pericyte=pericyte)
        tr_r_cap.append(mesh.capillary_radii()[e_disc].mean()); tr_ra.append(mesh.ra[ai])
    pr_, q_, nf_, af_ = mesh.flows()
    return nf_, np.array(tr_r_cap), np.array(tr_ra)
base_nf = nf0
def resp(nf_): return float(nf_[disc].mean() / base_nf[disc].mean() - 1)
def ko_fraction(bd):
    mesh.p['beta_d'] = bd
    full_ = resp(activate()[0]); ko = resp(activate(kir=False)[0]); return ko / full_
# two calibrations: perivascular K+ during the stimulus so that the flow response is +25 % (typical whisker CBF
# response), and beta_d so that the Kir2.1 knockout keeps 51 % of it (Longden 2017)
for _ in range(3):
    K_ACT[0] = optimize.brentq(lambda kk: resp(activate(k_act=kk)[0]) - 0.25, 3.05, 12.0, xtol=1e-3)
    bc = optimize.brentq(lambda b: ko_fraction(b) - 0.51, 0.0, 20.0, xtol=1e-3)
nf_full, rcap, rart = activate()
r_full = resp(nf_full); r_ko = resp(activate(kir=False)[0]); bcap = mesh.p['beta_c']; mesh.p['beta_c'] = 0.0; r_noperi = resp(activate()[0]); mesh.p['beta_c'] = bcap
def t10(x, dt=0.05):
    d_ = x - x[0]; return float(np.where(d_ >= 0.1 * d_.max())[0][0] * dt)
R['V3_activation'] = dict(beta_d_calibrated=bc, perivascular_K_mM_calibrated=K_ACT[0], beta_c=mesh.p['beta_c'], flow_rise_pct=100 * r_full, kir_KO_remaining=r_ko / r_full,
                          capillary_dilation_share=1 - r_noperi / r_full,
                          t10_capillary_s=t10(rcap), t10_arteriole_s=t10(rart), capillary_lead_s=t10(rart) - t10(rcap),
                          capillary_dilation_pct=float(100 * (rcap.max() / rcap[0] - 1)),
                          arteriole_dilation_pct=float(100 * (rart.max() / rart[0] - 1)),
                          observed=dict(kir_KO_remaining=0.51, Hall_capillary_share=0.84, Hall_lead=1.38,
                                        Hall_t10_cap=2.7, Hall_t10_art=3.7))
print('V3', R['V3_activation'])

# V4 point-spread
rel = nf_full / base_nf - 1
bins = np.arange(0, 800, 50); prof4 = []
for a, b in zip(bins[:-1], bins[1:]):
    s = (dc >= a) & (dc < b); prof4.append(float(np.median(rel[s])) if s.sum() > 3 else np.nan)
prof4 = np.array(prof4); ref = np.nanmax(prof4[:3]); below = np.where(prof4 < 0.5 * ref)[0]
half_r = bins[:-1][below[0]] + 25 if len(below) else np.nan
R['V4_psf'] = dict(radial_profile=dict(zip((bins[:-1] + 25).tolist(), prof4.tolist())), FWHM_um=float(2 * half_r),
                   activated_disc_diameter_um=200, observed='single arteriole territory ~400 um (O\'Herron 2016); '
                   'human 7T GE-BOLD PSF 0.83-2.4 mm (includes venous spread)')
np.save('results/mesh_rel_flow.npy', np.c_[mesh.xy, rel])
print('V4', R['V4_psf']['FWHM_um'])

# V5 discrete domains vs mesh
tree = cKDTree(mesh.xy[mesh.art]); dom = tree.query(mesh.xy)[1]           # A.5 domain = nearest-arteriole territory
art_rel = activate()[0]
pr_, q_, nf_, af_ = mesh.flows()
dom_supply = (af_ / af0 - 1)[dom]                                          # A.5: one supply value per domain
mesh_supply = rel
rng = np.random.default_rng(3); X = rng.uniform(100, 1400, (3000, 2))
K = mesh.supply_kernel(X, ell=20.0)
neur_mesh = K @ mesh_supply; neur_dom = dom_supply[cKDTree(mesh.xy).query(X)[1]]
nb = cKDTree(X).query_pairs(25.0, output_type='ndarray')
cross = dom[cKDTree(mesh.xy).query(X[nb[:, 0]])[1]] != dom[cKDTree(mesh.xy).query(X[nb[:, 1]])[1]]
R['V5_domain_vs_mesh'] = dict(pairs_within_25um=int(len(nb)), cross_boundary_pairs=int(cross.sum()),
                              mean_abs_jump_domain=float(np.mean(np.abs(neur_dom[nb[cross, 0]] - neur_dom[nb[cross, 1]]))),
                              mean_abs_jump_mesh=float(np.mean(np.abs(neur_mesh[nb[cross, 0]] - neur_mesh[nb[cross, 1]]))),
                              mean_abs_diff_same_domain_mesh=float(np.mean(np.abs(neur_mesh[nb[~cross, 0]] - neur_mesh[nb[~cross, 1]]))))
print('V5', R['V5_domain_vs_mesh'])
json.dump(R, open('results/a6_mesh.json', 'w'), indent=1, default=float)
