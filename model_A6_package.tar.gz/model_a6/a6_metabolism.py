"""Model A.6 validation, caveat 2: multi-substrate metabolism against human and rodent data.

Calibration (rest, exact): CMRglc 0.30 umol/g/min, OGI 5.3 (Vaishnavi 2010 whole brain), aerobic glycolysis 11.7%,
lactate 0.8 mM (Lin 2012: 0.79), glycogen 7 umol/g turnover 0.35 umol/g/h (Oz 2015), ATP 2.5 mM.
Activation: neural activity A raises glutamate cycling u = 1 + A, neuronal ATP demand D = D0 (1 + A) and flow
f = 1 + kappa_f A. kappa_f is calibrated once on Leontiev & Buxton 2007 (CBF +72.9 %, CMRO2 +27.2 %).
Predictions (not fitted): Lin 2010 CMRO2 at its three CBF levels, Fox 1988 CMRglc/CMRO2, lactate rise
(Mangia 2007 +23 %, Lin 2012 +30 %), oxidative share of ATP (Lin 2010 97.6 %), increment ratios (Dienel 2025),
hypoglycaemic glycogenolysis (Oz 2009), aglycaemic survival vs glycogen (Wender 2000), ANLS share constraint.
"""
import json, os, numpy as np
from scipy import optimize
from modela import metabolism as M

os.makedirs('results', exist_ok=True)
R = {}

def steady(P, x0, **kw):
    t, X, F = M.simulate(P, x0, 1800, dt=0.05, drive=lambda t: kw, record_every=30)
    return X[-1], F[-1]

def activation(P, x0, A, kappa_f, T=600):
    drive = lambda t: dict(f=1 + kappa_f * A, u=1 + A, D=P['D0'] * (1 + A))
    t, X, F = M.simulate(P, x0, T, dt=0.05, drive=drive, record_every=5)
    Fe = F[-1]; xe = X[-1]; F0 = M.fluxes(x0, P)            # true rest fluxes (no drive applied)
    F = [F0] + list(F[1:])
    i1 = int(60 / 5)                                           # 1 min in
    return dict(CBF=kappa_f * A, CMRO2=Fe['J_O'] / P['J_O0'] - 1, CMRglc=Fe['J_G'] / F0['J_G'] - 1,
                OGI=Fe['J_O'] / Fe['J_G'], lactate_pct=xe[1] / x0[1] - 1, lactate_mM=xe[1] - x0[1],
                lactate_at_1min_pct=X[i1][1] / x0[1] - 1, ATP_drop_pct=xe[5] / x0[5] - 1,
                oxidative_ATP_share=P['Y_ox'] * Fe['v_ox'] / (P['Y_ox'] * Fe['v_ox'] + 2 * Fe['v_gn'] + 2 * (Fe['v_ga'] + Fe['v_gly'])),
                d_glc_blood=Fe['J_G'] - F[0]['J_G'], d_glc_ox=(Fe['v_ox'] - F[0]['v_ox']) / 2,
                d_glycogenolysis=Fe['v_gly'] - F[0]['v_gly'], neuronal_glycolysis_change=Fe['v_gn'] / F[0]['v_gn'] - 1,
                neuronal_glycolysis_change_1min=F[i1]['v_gn'] / F[0]['v_gn'] - 1, tissue_glucose_change=xe[0] / x0[0] - 1)

def calib_A(P, x0):
    f = lambda A: activation(P, x0, A, 0.729 / A, T=400)['CMRO2'] - 0.272
    A = optimize.brentq(f, 0.05, 1.5, xtol=1e-3); return A, 0.729 / A
def act_pair(chi, Lb, phi=0.5):
    P, x0 = M.calibrate(phi=phi, chi_g=chi, L_b=Lb); A, kf = calib_A(P, x0)
    r = activation(P, x0, A, kf, T=400); return r['d_glc_blood'] / r['d_glc_ox'], r['lactate_pct']
# two activation parameters calibrated on two targets: Dienel 2025 increment ratio 2:1 and lactate +26 %
# (mean of Mangia 2007 +23 % and Lin 2012 +30 %); every other activation number is then a prediction
sol = optimize.least_squares(lambda z: [act_pair(z[0], z[1])[0] - 2.0, (act_pair(z[0], z[1])[1] - 0.26) / 0.1],
                             x0=[8.5, 0.735], bounds=([0.0, 0.3], [30.0, 0.79]), diff_step=1e-2)
CHI, LB = sol.x
R['calibrated_activation'] = dict(chi_g=CHI, L_b=LB, residuals=sol.fun.tolist())
print('chi_g', CHI, 'L_b', LB, sol.fun)
res_phi = {}
for phi in (0.0, 0.5, 1.0):
    P, x0 = M.calibrate(phi=phi, chi_g=CHI, L_b=LB)
    xs, Fs = steady(P, x0)
    drift = float(np.max(np.abs(xs - x0)))
    # calibrate A and kappa_f on Leontiev & Buxton 2007 (CBF +72.9 %, CMRO2 +27.2 %)
    A_L, kappa_f = calib_A(P, x0)
    out = dict(rest_drift_max=drift, A_leontiev=A_L, kappa_f=kappa_f)
    preds = {}
    for name, dcbf in (('Lin2010_4Hz', 0.517), ('Lin2010_8Hz', 0.651), ('Lin2010_16Hz', 0.572), ('Fox1988', 0.50),
                       ('Leontiev2007', 0.729)):
        r = activation(P, x0, dcbf / kappa_f, kappa_f)
        r['n'] = r['CBF'] / r['CMRO2'] if r['CMRO2'] > 0 else np.nan
        r['ratio_total_to_oxidised_increment'] = r['d_glc_blood'] / r['d_glc_ox']
        r['ratio_incl_glycogen'] = (r['d_glc_blood'] + r['d_glycogenolysis']) / r['d_glc_ox']
        preds[name] = r
    out['predictions'] = preds
    res_phi[f'phi={phi}'] = out
    print(phi, 'A', round(A_L, 3), 'kappa_f', round(kappa_f, 2), {k: (round(v['CMRO2'], 3), round(v['CMRglc'], 3), round(v['lactate_pct'], 3), round(v['OGI'], 2)) for k, v in preds.items()})
R['activation'] = res_phi
R['targets'] = dict(Lin2010=dict(CBF=[0.517, 0.651, 0.572], CMRO2=[0.170, 0.134, 0.122], oxidative_ATP=0.976),
                    Fox1988=dict(CBF=0.50, CMRglc=0.51, CMRO2=0.05), Leontiev2007=dict(n=[2.45, 2.63]),
                    lactate=dict(Mangia2007=0.23, Mangia_sem=0.05, Lin2012_first_10min=0.30, Lin2012_mM=0.21),
                    Dienel2025=dict(total_to_oxidised=2.0, incl_glycogen=3.0))

# ---------------------------------------------------------------- glycogen tests (phi = 0.5)
P, x0 = M.calibrate(phi=0.5, chi_g=CHI, L_b=LB)
# Oz 2009: blood glucose clamped at ~3 mM (55 mg/dL) for 2 h
t, X, F = M.simulate(P, x0, 7200, dt=0.05, drive=lambda t: dict(G_b=3.05), record_every=60)
mob = x0[2] - X[-1][2]
R['hypoglycaemia_Oz2009'] = dict(glycogen_mobilised_umol_g_2h=float(mob), rate_umol_g_h=float(mob / 2),
                                 tissue_glucose_end=float(X[-1][0]), observed_mobilised=[0.4, 0.6], observed_rate=[0.22, 0.30])
# Wender 2000: aglycaemia; failure when ATP < 50 % of rest; glycogen 4.85 vs 7.90 (pmol/ug) -> scale rest glycogen
def fail_time(Gam0, a_crit=0.5):
    x = x0.copy(); x[2] = Gam0
    # aglycaemia: supply glucose removed, lactate exchange left as at rest (the optic-nerve bath differs; see report)
    t, X, F = M.simulate(P, x, 6000, dt=0.05, drive=lambda t: dict(G_b=0.0), record_every=5)
    below = np.where(X[:, 5] < a_crit * x0[5])[0]
    return float(t[below[0]] / 60) if len(below) else np.nan
ctrl = fail_time(x0[2]); high = fail_time(x0[2] * 7.90 / 4.85); none = fail_time(0.0)
R['aglycaemia_Wender2000'] = dict(failure_min_control=ctrl, failure_min_high_glycogen=high, failure_min_no_glycogen=none,
                                  predicted_ratio_high_over_control=high / ctrl, observed_ratio=41.5 / 28.8,
                                  observed_min=dict(control=28.8, high=41.5, low_NE=23.2))
print('glycogen', R['hypoglycaemia_Oz2009'], R['aglycaemia_Wender2000'])

# ---------------------------------------------------------------- ischaemia: lumped (A.2) vs multi-substrate (A.6)
t, X, F = M.simulate(P, x0, 900, dt=0.05, drive=lambda t: dict(f=0.4), record_every=10)
R['ischaemia_f0.4'] = dict(ATP_rel=float(X[-1][5] / x0[5]), lactate_mM=float(X[-1][1]), CMRO2_rel=float(F[-1]['J_O'] / P['J_O0']),
                           glycolysis_rel=float((F[-1]['v_gn'] + F[-1]['v_ga']) / (F[0]['v_gn'] + F[0]['v_ga'])))

# ---------------------------------------------------------------- maths: ledgers, Jacobian timescales
t, X, F = M.simulate(P, x0, 1200, dt=0.01, drive=lambda t: dict(f=1.5, u=1.4, D=P['D0'] * 1.4), record_every=1)
dt_ = 1.0
carbon = np.array([M.carbon(x) for x in X])
flux_c = np.array([f['J_G'] - f['J_L'] / 2 - f['v_ox'] / 2 for f in F])
pred_c = carbon[0] + np.concatenate([[0], np.cumsum(flux_c[:-1]) * dt_])
R['ledger'] = dict(carbon_residual_rel=float(np.max(np.abs(carbon - pred_c)) / carbon[0]),
                   note='record step 1 s with 0.01 s integration; residual is quadrature error of the check, not of the model')
def jac(x, P, eps=1e-7):
    J = np.zeros((6, 6)); f0, _ = M.rhs(x, P)
    for j in range(6):
        y = x.copy(); y[j] += eps; J[:, j] = (M.rhs(y, P)[0] - f0) / eps
    return J
ev = np.linalg.eigvals(jac(x0, P))
R['jacobian_rest'] = dict(eigenvalues=sorted(ev.real.tolist()), max_real=float(ev.real.max()),
                          timescales_s=sorted((-1 / ev.real).tolist()))
print('ledger', R['ledger'], 'jac', R['jacobian_rest'])
json.dump(R, open('results/a6_metabolism.json', 'w'), indent=1, default=float)
