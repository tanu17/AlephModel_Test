"""Model A.6 integrated tissue run: capillary mesh + multi-substrate metabolism at every capillary node.

I1 focal activation (100 um disc): flow from the mesh, metabolism per node; CBF/CMRO2 coupling ratio n, lactate,
   ATP, and their spatial profiles. Parameters are those calibrated in a6_mesh.py and a6_metabolism.py; nothing is
   refitted here, so n is a prediction of the coupled model (targets 2.45-2.63, Leontiev & Buxton 2007).
I2 occlusion of one penetrating arteriole: ATP and lactate maps; graded penumbra on the mesh vs a step in the
   discrete-domain model.
"""
import json, os, numpy as np
from scipy.spatial import cKDTree
from modela.mesh import CapillaryMesh
from modela import metabolism as M

os.makedirs('results', exist_ok=True)
R = {}
mj = json.load(open('results/a6_mesh.json')); met = json.load(open('results/a6_metabolism.json'))
mesh = CapillaryMesh(seed=0)
mesh.p['A_K'] = mj.get('A_K_calibrated_mV', 30.0); mesh.p['beta_a'] = mj['V1_longden']['beta_a_calibrated']
mesh.p['beta_d'] = mj['V3_activation']['beta_d_calibrated']
P, x0 = M.calibrate(phi=0.5, chi_g=met['calibrated_activation']['chi_g'], L_b=met['calibrated_activation']['L_b'])
n = mesh.n
X0 = np.repeat(x0[:, None], n, axis=1)
pr0, q0, nf0, af0 = mesh.flows()
ai = int(np.argmin(np.linalg.norm(mesh.xy[mesh.art] - mesh.xy.mean(0), axis=1))); c_art = mesh.art[ai]
centre = mesh.xy[c_art] + np.array([100.0, 60.0])
dc = np.linalg.norm(mesh.xy - centre, axis=1); disc = dc < 100

def run_metab(f, u, Dset, T=600.0, dt=0.05):
    X = X0.copy()
    for _ in range(int(T / dt)):
        d, F = M.rhs(X, P, f=f, u=u, D=Dset)
        X = np.maximum(X + dt * d, 0)
    return X, F

# I1 activation: activity A in the disc drives perivascular K+, pericyte/vasodilator signals, glutamate cycling and demand
A = 0.30
kk = np.where(disc, 3.0 + (mj['V3_activation']['perivascular_K_mM_calibrated'] - 3.0), 3.0)
mesh.reset()
for _ in range(int(25 / 0.05)): mesh.step(0.05, k=kk, activity=disc * 1.0)
pr, q, nf, af = mesh.flows(); f = nf / nf0
u = 1 + A * disc; Dset = P['D0'] * (1 + A * disc)
X, F = run_metab(f, u, Dset)
Xr, Fr = run_metab(np.ones(n), np.ones(n), np.full(n, P['D0']), T=60)
dCBF = f[disc].mean() - 1; dO2 = F['J_O'][disc].mean() / Fr['J_O'][disc].mean() - 1
dGlc = F['J_G'][disc].mean() / Fr['J_G'][disc].mean() - 1
R['I1_activation'] = dict(activity_A=A, CBF_rise=float(dCBF), CMRO2_rise=float(dO2), CMRglc_rise=float(dGlc), n=float(dCBF / dO2),
                          OGI=float(F['J_O'][disc].mean() / F['J_G'][disc].mean()),
                          lactate_rise_pct=float(X[1][disc].mean() / x0[1] - 1), ATP_change_pct=float(X[5][disc].mean() / x0[5] - 1),
                          surround_200_400um_CBF=float(f[(dc > 200) & (dc < 400)].mean() - 1),
                          surround_200_400um_CMRO2=float(F['J_O'][(dc > 200) & (dc < 400)].mean() / Fr['J_O'][(dc > 200) & (dc < 400)].mean() - 1),
                          targets=dict(n=[2.45, 2.63], lactate=[0.23, 0.30]))
print('I1', R['I1_activation'])
np.save('results/tissue_activation.npy', np.vstack([mesh.xy.T, f, F['J_O'] / Fr['J_O'], X[1], X[5]]))

# I2 occlusion of the central arteriole
mesh.reset(); mesh.blocked[ai] = True
pr2, q2, nf2, af2 = mesh.flows(); f2 = nf2 / nf0; mesh.blocked[ai] = False
X2, F2 = run_metab(np.maximum(f2, 1e-3), np.ones(n), np.full(n, P['D0']), T=900)
atp = X2[5] / x0[5]; d_art = np.linalg.norm(mesh.xy - mesh.xy[c_art], axis=1)
core = atp < 0.5
dom = cKDTree(mesh.xy[mesh.art]).query(mesh.xy)[1]
R['I2_occlusion'] = dict(core_ATP_below_half_nodes=int(core.sum()),
                         core_radius_um=float(np.sqrt(core.sum() / n * (1500**2) / np.pi)) if core.sum() else 0.0,
                         ATP_by_distance={int(b): float(np.median(atp[(d_art >= b) & (d_art < b + 50)])) for b in range(0, 500, 50)},
                         lactate_core_mM=float(X2[1][core].mean()) if core.sum() else float('nan'),
                         domain_model_note='A.5 assigns the occluded domain zero supply and neighbours full supply: a step at the territory edge',
                         occluded_domain_nodes=int((dom == ai).sum()))
print('I2', R['I2_occlusion'])
np.save('results/tissue_occlusion.npy', np.vstack([mesh.xy.T, f2, atp, X2[1], dom == ai]))
json.dump(R, open('results/a6_tissue.json', 'w'), indent=1, default=float)
