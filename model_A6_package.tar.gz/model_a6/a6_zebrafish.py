"""Model A.4 zebrafish test: the two-process sleep gate u(Ado, NE) (Eqs. 20-22) against
Suppermpool et al. 2024 single-neuron synapse data (tectal neurons, 7-8 dpf).

Targets (group means with SEM):
  night protocol  control ZT13-18, control ZT18-24, sleep-deprived ZT18-24 recovery
  day drugs       ZT3-10 synapse change per hour under DMSO, melatonin, clonidine, 2-chloroadenosine,
                  2-Cl-Ado + melatonin, 2-Cl-Ado + clonidine (with each group's measured sleep per hour)
Models compared (same wake-gain terms, different gates):
  A.3     u = 1 whenever asleep
  NE      u = 1 - NE           (noradrenergic gate only)
  Ado     u = sigma(Ado)       (adenosine gate only)
  A.4     u = sigma(Ado) * (1 - NE)
Each is fitted by weighted least squares; we report chi^2, AIC and leave-one-target-out prediction error.
Further checks: per-fish sleep vs synapse change in early and late night; regression to the mean in
d2-on-d1 slopes; constant-light (LL) and free-running (FR) days.
"""
import json, os, numpy as np, pandas as pd
from scipy import stats, optimize

D = '/tmp/data/zfsyn/'
os.makedirs('results', exist_ok=True)
R = {}

# ------------------------------------------------------------------ data
d = pd.read_excel(D + 'Ext Figure8.xlsx', sheet_name='8c')
d = d[~d.Fish_ID.isin(['F8_1_210929_ON', 'F3R_20210922_ON', 'F1_20210811'])]
w = d.pivot_table(index=['Fish_ID', 'Condition'], columns='Time', values='Puncta').dropna().reset_index()
w['d1'] = w['dpf7_18'] - w['dpf7_13']; w['d2'] = w['dpf8_0'] - w['dpf7_18']
night = {c: dict(d1=g.d1.mean(), d1_sem=g.d1.sem(), d2=g.d2.mean(), d2_sem=g.d2.sem(), n=len(g))
         for c, g in w.groupby('Condition')}
day = pd.read_excel(D + 'Figure1.xlsx', sheet_name='1gh')
pv = day.pivot_table(index=['Fish_ID', 'Condition'], columns='time', values='Puncta').reset_index()
light = {c: dict(gain_ZT0_10=float((g['ZT 10'] - g['ZT 0']).mean()), sem=float((g['ZT 10'] - g['ZT 0']).sem()),
                 night_ZT10_24=float((g['ZT 0_8'] - g['ZT 10']).mean()), n=int(g['ZT 10'].notna().sum()))
         for c, g in pv.groupby('Condition')}
g_day = light['LD']['gain_ZT0_10'] / 10.0                        # synapses per hour in a normal day
drug = pd.read_excel(D + 'Figure4.xlsx'); drug = drug[drug.Fish_ID != 'F7L_20230106']
dg = drug.groupby('Condition').agg(rate=('puncta_perhour', 'mean'), sem=('puncta_perhour', 'sem'),
                                   sleep=('sleep_perhour', 'mean'), n=('puncta_perhour', 'count'))
# sleep fractions at night (per-fish tracking, Figure 3c)
f3a = pd.read_excel(D + 'Figure3.xlsx', sheet_name='3c_firstsleep')
f3b = pd.read_excel(D + 'Figure3.xlsx', sheet_name='3c_lattersleep')
s_early_ctrl = f3a[f3a.Condition == 'Control'].Total_4hsleep.mean() / 240
s_early_sd = f3a[f3a.Condition == 'SD'].Total_4hsleep.mean() / 240
s_late_ctrl = (f3b.Total_sleep_later / (60 * f3b.hours_track_latter_sleep)).mean()
R['data'] = dict(night=night, light_conditions=light, g_day=g_day, drugs=dg.round(3).to_dict('index'),
                 sleep_fraction=dict(control_early=s_early_ctrl, control_late=s_late_ctrl, SD_recovery_first4h=s_early_sd))

# ------------------------------------------------------------------ model
X13 = g_day * 13 * 0.98                       # excess over the morning set point at ZT13
sig = lambda z: 1 / (1 + np.exp(-z))

from functools import lru_cache
@lru_cache(maxsize=4096)
def ado_cycle(tau_s, tau_w=18.0, s_day=0.03, s_night=None, days=5, dt=0.05):
    """periodic Ado (process-S-like) trajectory for a control fish; returns A at ZT0."""
    s_night = s_early_ctrl if s_night is None else s_night
    A = 0.3
    for _ in range(days):
        for t in np.arange(0, 24, dt):
            s = s_day if t < 14 else s_night
            A += dt * ((1 - s) * (1 - A) / tau_w - s * A / tau_s)
    return A

def run(segments, A0, X0, prm, gate, dt=0.02):
    """segments: list of (hours, sleep_frac, NE, gain, ado_extra). Returns change in S."""
    k, theta, tau_s, g_dark = prm[:4]
    g_late = prm[4] if len(prm) > 4 else g_dark
    A, X, S0 = A0, X0, X0
    for hrs, s, NE, gain, extra in segments:
        for _ in range(int(round(hrs / dt))):
            Ae = min(A + extra, 2.0)
            if gate in ('A3', 'A3c'): u = 1.0
            elif gate == 'NE': u = 1 - NE
            elif gate == 'Ado': u = sig((Ae - theta) / 0.03)
            else: u = sig((Ae - theta) / 0.03) * (1 - NE)
            gw = {'dark': g_dark, 'late': g_late, 'day': g_day}.get(gain, gain) if isinstance(gain, str) else gain
            X += dt * ((1 - s) * gw - s * k * u * max(X, 0))
            A += dt * ((1 - s) * (1 - A) / 18.0 - s * A / tau_s)
    return X - S0, A

def predict(prm, gate):
    k, theta, tau_s = prm[:3]
    A0 = ado_cycle(float(tau_s))
    # A at ZT13 after a normal day
    _, A13 = run([(13, 0.03, 1, 'day', 0)], A0, 0, prm, gate)
    out = {}
    c1, A18 = run([(1, 0.03, 1, 'day', 0), (4, s_early_ctrl, 0, 'dark', 0)], A13, X13, prm, gate)
    c2, _ = run([(6, s_late_ctrl, 0, 'late', 0)], A18, X13 + c1, prm, gate)
    out['control ZT13-18'] = c1; out['control ZT18-24'] = c2
    # sleep deprivation ZT14-18: awake, observed gain used as input; Ado accumulates
    g_sd = (night['SD']['d1'] - g_day) / 4
    _, A18sd = run([(1, 0.03, 1, 'day', 0), (4, 0.0, 0, g_sd, 0)], A13, X13, prm, gate)
    sd2, _ = run([(4, s_early_sd, 0, 'late', 0), (2, s_late_ctrl, 0, 'late', 0)], A18sd, X13 + night['SD']['d1'], prm, gate)
    out['SD recovery ZT18-24'] = sd2
    # day drugs ZT3-10 (7 h), each with its measured sleep fraction
    _, A3 = run([(3, 0.03, 1, 'day', 0)], A0, 0, prm, gate)
    spec = {'DMSO': (0, 1), 'Melatonin': (0, 1), 'Clonidine': (0, 0), 'Chloro_adenosine': (1, 1),
            'Chloro2adenosine_melatonin': (1, 1), 'Chloroadenosine_Clonidine': (1, 0)}
    for cond, (ado, ne) in spec.items():
        s = dg.loc[cond, 'sleep'] / 60
        ch, _ = run([(7, s, ne, 'day', ado)], A3, g_day * 3 * 0.97, prm, gate)
        out[cond] = ch / 7
    return out

targets = {'control ZT13-18': (night['Control']['d1'], night['Control']['d1_sem']),
           'control ZT18-24': (night['Control']['d2'], night['Control']['d2_sem']),
           'SD recovery ZT18-24': (night['SD']['d2'], night['SD']['d2_sem'])}
targets.update({c: (dg.loc[c, 'rate'], dg.loc[c, 'sem']) for c in dg.index})
names = list(targets)

def resid(prm, gate, keys=None):
    p = predict(prm, gate)
    keys = names if keys is None else keys
    return np.array([(p[k] - targets[k][0]) / targets[k][1] for k in keys])

bounds = {'A3': ([0.001, 0.5, 0.5, 0.0], [2.0, 0.51, 0.51, 3.0]),
          'NE': ([0.001, 0.5, 0.5, 0.0], [2.0, 0.51, 0.51, 3.0]),
          'Ado': ([0.001, 0.05, 0.5, 0.0], [2.0, 1.2, 20.0, 3.0]),
          'A4': ([0.001, 0.05, 0.5, 0.0], [2.0, 1.2, 20.0, 3.0]),
          # variants with a separate late-night (ZT18-24) wake gain, i.e. circadian growth before dawn;
          # A4c also forces physiological adenosine clearance (tau >= 2 h of sleep)
          'A3c': ([0.001, 0.5, 0.5, 0.0, 0.0], [2.0, 0.51, 0.51, 3.0, 6.0]),
          'A4c': ([0.001, 0.05, 2.0, 0.0, 0.0], [2.0, 1.2, 20.0, 3.0, 6.0]),
          # A.6: product gate, physiological adenosine clearance (>= 4 h of sleep), circadian late-night wake gain
          'A6': ([0.001, 0.05, 4.0, 0.0, 0.0], [2.0, 1.2, 40.0, 3.0, 6.0])}
nfree = {'A3': 2, 'NE': 2, 'Ado': 4, 'A4': 4, 'A3c': 3, 'A4c': 5, 'A6': 5}

def fit(gate, keys=None, starts=6, seed=0):
    rng = np.random.default_rng(seed); best = None
    lo, hi = map(np.array, bounds[gate])
    for _ in range(starts):
        x0 = lo + rng.random(len(lo)) * (hi - lo)
        try:
            r = optimize.least_squares(resid, x0, args=(gate, keys), bounds=(lo, hi), diff_step=1e-3)
        except Exception:
            continue
        if best is None or r.cost < best.cost: best = r
    return best

fits = {}
for gate in ('A3', 'Ado', 'A4', 'A3c', 'A6'):
    r = fit(gate)
    chi2 = float(2 * r.cost); p = nfree[gate]
    pred = predict(r.x, gate)
    # leave-one-target-out cross-validation
    loo = {}
    for k in names:
        keys = [n for n in names if n != k]
        rk = fit(gate, keys, starts=3, seed=1)
        loo[k] = float(predict(rk.x, gate)[k])
    loo_z = np.array([(loo[k] - targets[k][0]) / targets[k][1] for k in names])
    fits[gate] = dict(params=dict(zip(['k_per_h', 'theta_Ado', 'tau_sleep_h', 'g_dark_per_h', 'g_late_per_h'], r.x.tolist())),
                      chi2=chi2, n_targets=len(names), n_free=p, AIC=chi2 + 2 * p,
                      fitted={k: float(v) for k, v in pred.items()},
                      loo_prediction=loo, loo_rmse_z=float(np.sqrt(np.mean(loo_z**2))),
                      loo_rmse_synapses=float(np.sqrt(np.mean([(loo[k] - targets[k][0])**2 for k in names]))))
    print(gate, 'chi2', round(chi2, 2), 'AIC', round(chi2 + 2 * p, 2), 'LOO rmse z', round(fits[gate]['loo_rmse_z'], 2), np.round(r.x, 3))
R['gate_fits'] = fits
R['targets'] = {k: dict(mean=float(v[0]), sem=float(v[1])) for k, v in targets.items()}

# ------------------------------------------------------------------ per-fish sleep vs synapse change
pf = {}
fa = f3a[f3a.Cluster != 0].dropna(subset=['punc_hr4h'])           # authors exclude cluster 0
for cond, g in fa.groupby('Condition'):
    lr = stats.linregress(g.sleepph_adjusted_exp, g.punc_hr4h)
    pf[f'{cond} first 4 h of sleep'] = dict(n=len(g), slope_per_min_per_h=lr.slope, r=lr.rvalue, p=lr.pvalue)
g = f3b[f3b.Cluster != 0].dropna(subset=['late_sleepph_adjusted_exp', 'punc_ZT18_0'])
lr = stats.linregress(g.late_sleepph_adjusted_exp, g.punc_ZT18_0)
pf['Control late night ZT18-24'] = dict(n=len(g), slope_per_min_per_h=lr.slope, r=lr.rvalue, p=lr.pvalue)
def per_fish(prm, gate, cond, s1, s2=None):
    tau_s = prm[2]
    A0 = ado_cycle(float(tau_s))
    _, A13 = run([(13, 0.03, 1, 'day', 0)], A0, 0, prm, gate)
    if cond == 'Control':
        c1, A18 = run([(1, 0.03, 1, 'day', 0), (4, s1, 0, 'dark', 0)], A13, X13, prm, gate)
        if s2 is None: return (c1 - g_day) / 4          # per hour over ZT14-18, as in the data
        c2, _ = run([(6, s2, 0, 'late', 0)], A18, X13 + c1, prm, gate)
        return c2 / 6
    g_sd = (night['SD']['d1'] - g_day) / 4
    _, A18 = run([(1, 0.03, 1, 'day', 0), (4, 0.0, 0, g_sd, 0)], A13, X13, prm, gate)
    c, _ = run([(4, s1, 0, 'late', 0)], A18, X13 + night['SD']['d1'], prm, gate)
    return c / 4

fb = f3a.dropna(subset=['punc_ZT18_0', 'late_sleepph_adjusted_exp']) if 'late_sleepph_adjusted_exp' in f3a else None
late_tab = f3b[f3b.Cluster != 0].dropna(subset=['late_sleepph_adjusted_exp', 'punc_ZT18_0']).merge(
    f3a[['Fish_ID', 'sleepph_adjusted_exp']], on='Fish_ID', how='left')
for gate in ('A3', 'Ado', 'A4', 'A3c', 'A6'):
    prm = np.array(list(fits[gate]['params'].values()))
    res = {}
    for cond, g in fa.groupby('Condition'):
        pred = np.array([per_fish(prm, gate, cond, s_ / 60) for s_ in g.sleepph_adjusted_exp])
        lp = stats.linregress(g.sleepph_adjusted_exp, pred)
        res[f'{cond} first 4 h'] = dict(predicted_slope=lp.slope, observed_slope=pf[f'{cond} first 4 h of sleep']['slope_per_min_per_h'],
                                       r_pred_obs=float(np.corrcoef(pred, g.punc_hr4h)[0, 1]))
    g = late_tab.dropna(subset=['sleepph_adjusted_exp'])
    pred = np.array([per_fish(prm, gate, 'Control', a / 60, b / 60) for a, b in zip(g.sleepph_adjusted_exp, g.late_sleepph_adjusted_exp)])
    lp = stats.linregress(g.late_sleepph_adjusted_exp, pred)
    res['Control late night'] = dict(n=len(g), predicted_slope=lp.slope, observed_slope=pf['Control late night ZT18-24']['slope_per_min_per_h'],
                                     r_pred_obs=float(np.corrcoef(pred, g.punc_ZT18_0)[0, 1]))
    pf[f'model_{gate}'] = res
    print(gate, json.dumps(res, default=float))
R['per_fish_sleep_vs_change'] = pf

# ------------------------------------------------------------------ regression to the mean in d2 vs d1
rtm = {}
for cond, g in w.groupby('Condition'):
    v1, v2 = g.d1.var(), g.d2.var(); c12 = np.cov(g.d1, g.d2)[0, 1]
    sig2_max = v2 / 2            # if all late-night variance were measurement noise at ZT18 and ZT24
    rtm[cond] = dict(observed_slope=c12 / v1, observed_r=c12 / np.sqrt(v1 * v2),
                     slope_from_noise_only_upper=-sig2_max / v1, r_from_noise_only_upper=-sig2_max / np.sqrt(v1 * v2))
R['regression_to_mean'] = rtm

# ------------------------------------------------------------------ lighting conditions
R['lighting'] = dict(LD=light['LD'], LL=light['LL'], FR=light['FR'],
                     A4_prediction_LL_day='(1 - s) g_w > 0 because LL larvae are awake in light; observed ~0 or negative')

json.dump(R, open('results/a6_zebrafish.json', 'w'), indent=1, default=float)
print(json.dumps({k: R[k] for k in ('per_fish_sleep_vs_change', 'regression_to_mean', 'lighting')}, indent=1, default=float))
