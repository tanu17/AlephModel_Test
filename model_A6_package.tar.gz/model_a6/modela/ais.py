"""Model A.6 axon initial segment (AIS) plasticity.

Two slow states per neuron: AIS length L_i (um) and AIS midpoint distance x_i from the soma (um).
  calcium/depolarisation proxy:  tau_c dcbar/dt = -cbar + c(t)          (c = 1 at the cell's normal activity)
  length:    tau_L dL/dt = -(L - L0) - G_L L0 (cbar - 1)               (fast: hours; Evans 2015, Jamann 2021)
  position:  tau_x dx/dt = -(x - x0) + G_x (cbar - 1)                  (slow: days; Grubb & Burrone 2010)
  bounds:    L in [L_min, L_max], x in [x_min, x_max] (projection)
Excitability (resistive-coupling theory, Goethals & Brette 2020, k ~ 5 mV):
  theta_AIS = -k_B ln(L / L0) - k_x ln(x / x0)
  added to the threshold in the rate function: r = phi(v - theta_i - a_i - theta_0 - theta_AIS).
Both AIS equations are leaky (they relax to L0, x0). Pure integral AIS control on the same error as the
homeostatic threshold theta_i would create a line of equilibria (see a6_ais.py, test E6).
"""
import numpy as np

DEFAULT = dict(L0=22.0, x0=25.0, tau_c=0.5, tau_L=5.0, G_L=0.17, tau_x=24.0, G_x=6.0, k_B=5.0, k_x=5.0,
               L_min=8.0, L_max=45.0, x_min=5.0, x_max=60.0)   # times in hours

def simulate(c_of_t, T, dt=0.05, p=None, L=None, x=None):
    p = {**DEFAULT, **(p or {})}
    L = p['L0'] if L is None else L; x = p['x0'] if x is None else x; cb = 1.0
    ts, Ls, xs = [], [], []
    for k in range(int(T / dt)):
        t = k * dt; c = c_of_t(t)
        cb += dt * (-cb + c) / p['tau_c']
        L += dt * (-(L - p['L0']) - p['G_L'] * p['L0'] * (cb - 1)) / p['tau_L']
        x += dt * (-(x - p['x0']) + p['G_x'] * (cb - 1)) / p['tau_x']
        L = min(max(L, p['L_min']), p['L_max']); x = min(max(x, p['x_min']), p['x_max'])
        ts.append(t); Ls.append(L); xs.append(x)
    return np.array(ts), np.array(Ls), np.array(xs)

def theta_shift(L, x, p=None):
    p = {**DEFAULT, **(p or {})}
    return -p['k_B'] * np.log(L / p['L0']) - p['k_x'] * np.log(x / p['x0'])
