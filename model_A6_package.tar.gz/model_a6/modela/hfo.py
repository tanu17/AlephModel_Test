"""Model A.6 spiking hippocampal layer for ripples and fast ripples (caveat 4).

Rate equations cannot carry 150-500 Hz structure, so A.6 adds a conductance-based integrate-and-fire layer
for CA1-like tissue, used only where sub-millisecond timing matters. Each spike still charges the Na+ ledger.
  tau_m dV/dt = -(V - E_L) - g_e (V - E_e) - g_i (V - E_i) + sigma_ch sqrt(2 tau_m) xi(t)  (SD sigma_ch)
  g_x jumps by w at each presynaptic spike after delay d, decays with tau_x
Pyramidal (E) and PV basket (I) cells; ripples by pyramidal-interneuron (PING) cycles (Stark et al. 2014).
Pathology (hippocampal sclerosis): PV perisomatic inhibition collapses (Schlingloff et al. 2025), recurrent
E-E collaterals sprout into clusters (pathologically interconnected neuron clusters, Bragin 2000), producing
out-of-phase cluster firing (Ibarz et al. 2010). The A.5 hypothesis, stochastic channel noise, is the
sigma_ch term.
"""
import numpy as np

BASE = dict(NE=400, NI=80, tauE=15.0, tauI=5.0, EL=-65.0, Vth=-52.0, Vr=-60.0, refE=2.0, refI=1.0,
            Ee=0.0, Ei=-75.0, tau_ampa=1.0, tau_gaba=1.5, delay=0.6,
            pEI=0.25, pIE=0.4, pII=0.3, pEE=0.02,
            wEI=0.30, wIE=0.20, wII=0.15, wEE=0.04,
            gdrive_E=0.60, gdrive_I=0.35, drive_sd=0.10, sigma_ch=0.0,
            clusters=1, pEE_in=0.02, wEE_in=0.04, pEE_out=0.02, cluster_size=None, I_silent=False)

def run_event(cfg=None, T=150.0, t_on=20.0, t_off=120.0, dt=0.02, seed=0):
    c = {**BASE, **(cfg or {})}
    rng = np.random.default_rng(seed)
    NE, NI = c['NE'], c['NI']; N = NE + NI
    isE = np.r_[np.ones(NE, bool), np.zeros(NI, bool)]
    tau = np.where(isE, c['tauE'], c['tauI']); ref = np.where(isE, c['refE'], c['refI'])
    # connectivity W[post, pre]
    W = np.zeros((N, N))
    E, I = slice(0, NE), slice(NE, N)
    W[I, E] = (rng.random((NI, NE)) < c['pEI']) * c['wEI']
    W[E, I] = (rng.random((NE, NI)) < c['pIE']) * c['wIE']
    W[I, I] = (rng.random((NI, NI)) < c['pII']) * c['wII']
    lab = np.zeros(NE, int)
    if c['clusters'] > 1:
        cs = c['cluster_size'] or NE // c['clusters']
        lab = np.full(NE, -1)
        for k in range(c['clusters']): lab[k * cs:(k + 1) * cs] = k
        same = (lab[:, None] == lab[None, :]) & (lab[:, None] >= 0)
        pmat = np.where(same, c['pEE_in'], c['pEE_out']); wmat = np.where(same, c['wEE_in'], c['wEE'])
        W[E, E] = (rng.random((NE, NE)) < pmat) * wmat
    else:
        W[E, E] = (rng.random((NE, NE)) < c['pEE']) * c['wEE']
    np.fill_diagonal(W, 0)
    gdrive = np.where(isE, c['gdrive_E'], c['gdrive_I']) * (1 + c['drive_sd'] * rng.standard_normal(N))
    V = c['EL'] + rng.uniform(0, 5, N); ge = np.zeros(N); gi = np.zeros(N); last = np.full(N, -1e9)
    nd = max(1, int(round(c['delay'] / dt))); buf = np.zeros((nd, N), bool); ptr = 0
    steps = int(T / dt); spikes = []
    ae = np.exp(-dt / c['tau_ampa']); ai = np.exp(-dt / c['tau_gaba'])
    for k in range(steps):
        t = k * dt
        arrived = buf[ptr]
        if arrived.any():
            ge += W[:, arrived & isE].sum(1); gi += W[:, arrived & ~isE].sum(1)
        drv = gdrive if t_on <= t < t_off else 0.0
        dV = (-(V - c['EL']) - (ge + drv) * (V - c['Ee']) - gi * (V - c['Ei'])) / tau
        V = V + dt * dV
        if c['sigma_ch'] > 0:                       # OU membrane noise with stationary SD sigma_ch (mV)
            V = V + c['sigma_ch'] * np.sqrt(2 * dt / tau) * rng.standard_normal(N)
        refr = (t - last) < ref
        V[refr] = c['Vr']
        sp = (V >= c['Vth']) & ~refr
        if c['I_silent']: sp &= isE                 # PV basket cells in depolarisation block (Schlingloff 2025)
        if sp.any():
            V[sp] = c['Vr']; last[sp] = t
            for j in np.where(sp)[0]: spikes.append((t, j))
        buf[ptr] = sp; ptr = (ptr + 1) % nd
        ge *= ae; gi *= ai
    sp = np.array(spikes) if spikes else np.zeros((0, 2))
    return sp, dict(NE=NE, NI=NI, lab=lab, t_on=t_on, t_off=t_off, T=T)

def analyse(sp, info, bin_ms=0.25, fmin=80.0, fmax=700.0):
    NE = info['NE']; t0, t1 = info['t_on'] + 10, info['t_off']
    e = sp[(sp[:, 1] < NE) & (sp[:, 0] >= t0) & (sp[:, 0] < t1)] if len(sp) else sp
    edges = np.arange(t0, t1 + bin_ms, bin_ms)
    allsp = sp[(sp[:, 0] >= t0) & (sp[:, 0] < t1)] if len(sp) else sp
    rate = np.histogram(allsp[:, 0], edges)[0].astype(float) if len(allsp) else np.zeros(len(edges) - 1)
    rateE = np.histogram(e[:, 0], edges)[0].astype(float) if len(e) else np.zeros(len(edges) - 1)
    x = rate - rate.mean(); x = x * np.hanning(len(x))
    P = np.abs(np.fft.rfft(x, n=4 * len(x)))**2; f = np.fft.rfftfreq(4 * len(x), d=bin_ms / 1000)
    band = (f >= fmin) & (f <= fmax)
    fpk = float(f[band][np.argmax(P[band])]) if P[band].sum() > 0 else np.nan
    rip = P[(f >= 120) & (f < 250)].sum(); fr = P[(f >= 250) & (f <= 600)].sum()
    xe = (rateE - rateE.mean()) * np.hanning(len(rateE)); PE = np.abs(np.fft.rfft(xe, n=4 * len(xe)))**2
    fpkE = float(f[band][np.argmax(PE[band])]) if PE[band].sum() > 0 else np.nan
    out = dict(peak_Hz=fpk, peak_E_Hz=fpkE,
               FR_over_ripple_power_E=float(PE[(f >= 250) & (f <= 600)].sum() / max(PE[(f >= 120) & (f < 250)].sum(), 1e-12)),
               FR_over_ripple_power=float(fr / max(rip, 1e-12)),
               spikes_per_E_cell=float(len(e) / NE), frac_E_active=float(len(np.unique(e[:, 1])) / NE) if len(e) else 0.0,
               I_rate_Hz=float(((sp[:, 1] >= NE) & (sp[:, 0] >= t0) & (sp[:, 0] < t1)).sum() / info['NI'] / ((t1 - t0) / 1000)) if len(sp) else 0.0)
    lab = info['lab']
    if lab.max() >= 1:
        r = [np.histogram(e[lab[e[:, 1].astype(int)] == k, 0], edges)[0].astype(float) for k in range(2)]
        a, b = r[0] - r[0].mean(), r[1] - r[1].mean()
        cc = np.correlate(a, b, 'full'); lags = (np.arange(len(cc)) - (len(a) - 1)) * bin_ms
        win = np.abs(lags) <= 4.0
        out['cluster_lag_ms'] = float(abs(lags[win][np.argmax(cc[win])]))
        out['cluster_zero_lag_corr'] = float(np.corrcoef(a, b)[0, 1])
    # spike timing precision: SD of spike times around population-rate peaks (ms)
    if len(e) > 20 and np.isfinite(fpk):
        period = 1000 / fpk; ph = ((e[:, 0] - t0) % period) / period * 2 * np.pi
        R = np.abs(np.mean(np.exp(1j * ph)))
        out['phase_locking_R'] = float(R)
        out['timing_jitter_ms'] = float(np.sqrt(-2 * np.log(max(R, 1e-6))) / (2 * np.pi) * period)
    return out
