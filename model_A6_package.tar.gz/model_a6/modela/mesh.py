"""Model A.6 continuous capillary mesh (replaces the discrete supply domains Q of A.2-A.5).

Geometry: a planar capillary network from a Poisson-Voronoi tessellation (vertices of degree 3, as in cortex),
with mean segment length set to the measured ~50 um. Penetrating arterioles and venules (ratio 1:3) attach to
nodes; arterioles are spaced ~300 um apart.

Flow: Poiseuille conductance G_e = r_e^4 / l_e on each segment; arteriole inlets at pressure P_a through a
conductance c_a r_a^4; venule outlets to 0. Kirchhoff's law gives node pressures (sparse linear solve).

Signals (all on nodes):
  conducted endothelial hyperpolarisation phi (mV). Kir2.1 makes conduction regenerative (Longden 2017;
  Moshkforoush 2020), so it is modelled by its Green's function on the graph rather than a passive cable:
      phi_m(t) = Phi_max tanh( sum_n G_mn s_n(t - d_mn/v_c) / Phi_max ),   G_mn = exp(-c_nm)
  with d_mn the shortest path length along capillaries, v_c the conduction velocity, and c_nm the least
  conduction cost from n to m on the directed capillary graph: an upstream step (towards higher pressure, i.e.
  towards the feeding arteriole, where branches converge) costs l_e/lambda_c; a downstream or lateral step costs
  l_e/lambda_c + ln b, because the current divides at each junction (b = 2 for degree-3 nodes).
  The K+-sensing source is
      s_n(k) = A_K sigma((k - k_th)/s_k) sigma((k_off - k)/s_off)   (Kir2.1: threshold 6-7 mM, lost at >20 mM)
  local pericyte/capillary signal psi:  tau_psi dpsi/dt = -psi + q(local activity)
  diffusible vasodilator reaching arteriole a (NO, prostanoids, EETs; ~100 um range):
      d_a = sum_n exp(-|x_a - x_n|/ell_d) psi_n / sum_n exp(-|x_a - x_n|/ell_d)
  arteriole radius:  tau_a dr_a/dt = r_a0 (1 + beta_a phi_root/A_K + beta_d d_a) - r_a
  capillary radius:  r_e = r_0 (1 + beta_c mean(psi at the two ends))
Supply to a neuron at x: kernel K(x, node) = exp(-|x - y|/ell) normalised over nodes (O2 diffusion length ell);
discrete domains Q of A.5 are the limit ell -> 0 with nodes grouped by arteriole territory.
"""
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla
import scipy.sparse.csgraph
from scipy.spatial import Voronoi, cKDTree

sig = lambda z: 1 / (1 + np.exp(-z))

class CapillaryMesh:
    def __init__(self, W=1500.0, seg=50.0, art_spacing=300.0, ven_ratio=3, r0=2.2, ra0=6.0, seed=0,
                 lam_c=2000.0, v_c=2000.0, Phi_max=60.0, A_K=30.0, b_div=2.0, k_th=6.8, s_k=0.5, k_off=20.0, s_off=2.0,
                 tau_a=2.0, beta_a=0.40, tau_psi=1.2, beta_c=0.07, beta_d=0.2, ell_d=100.0, c_a=None, k_rest=3.0):
        rng = np.random.default_rng(seed)
        lam_pts = (0.667 / seg)**2
        n_pts = rng.poisson(lam_pts * (W + 200)**2)
        pts = rng.uniform(-100, W + 100, (n_pts, 2))
        vor = Voronoi(pts)
        V = vor.vertices
        keep = (V[:, 0] >= 0) & (V[:, 0] <= W) & (V[:, 1] >= 0) & (V[:, 1] <= W)
        edges = [(a, b) for a, b in vor.ridge_vertices if a >= 0 and b >= 0 and keep[a] and keep[b]]
        idx = -np.ones(len(V), int); used = np.unique(np.array(edges).ravel()); idx[used] = np.arange(len(used))
        self.xy = V[used]; E = np.array([(idx[a], idx[b]) for a, b in edges])
        # keep the largest connected component
        n = len(self.xy)
        A = sp.coo_matrix((np.ones(len(E)), (E[:, 0], E[:, 1])), shape=(n, n))
        ncomp, lab = sp.csgraph.connected_components(A, directed=False)
        big = np.argmax(np.bincount(lab)); keepn = lab == big
        remap = -np.ones(n, int); remap[keepn] = np.arange(keepn.sum())
        E = E[keepn[E[:, 0]] & keepn[E[:, 1]]]; E = remap[E]; self.xy = self.xy[keepn]
        self.E = E; self.n = len(self.xy)
        self.l = np.linalg.norm(self.xy[E[:, 0]] - self.xy[E[:, 1]], axis=1)
        self.deg = np.bincount(E.ravel(), minlength=self.n)
        # arterioles on a jittered grid, venules random (ratio 1:ven_ratio)
        tree = cKDTree(self.xy)
        g = np.arange(art_spacing / 2, W, art_spacing)
        grid = np.array([(x + rng.normal(0, 30), y + rng.normal(0, 30)) for x in g for y in g])
        self.art = np.unique(tree.query(grid)[1])
        cand = np.setdiff1d(np.arange(self.n), self.art)
        self.ven = rng.choice(cand, ven_ratio * len(self.art), replace=False)
        self.p = dict(r0=r0, ra0=ra0, lam_c=lam_c, v_c=v_c, Phi_max=Phi_max, A_K=A_K, k_th=k_th, s_k=s_k, k_off=k_off,
                      s_off=s_off, tau_a=tau_a, beta_a=beta_a, tau_psi=tau_psi, beta_c=beta_c, beta_d=beta_d, k_rest=k_rest)
        # arteriole conductance chosen so that arterioles (with precapillary segments) carry about half of the
        # inlet-to-outlet resistance at rest; network models put roughly half in the capillary bed (Gould 2017)
        self.c_a = c_a if c_a is not None else self._calib_ca()
        da = np.linalg.norm(self.xy[self.art][:, None] - self.xy[None], axis=2)
        self.Wd = np.exp(-da / ell_d); self.Wd /= self.Wd.sum(1, keepdims=True)
        self.reset()
        # path distances along capillaries (um) for the conduction kernel
        Wm = sp.coo_matrix((np.r_[self.l, self.l], (np.r_[E[:, 0], E[:, 1]], np.r_[E[:, 1], E[:, 0]])), shape=(self.n, self.n)).tocsr()
        self.Dpath = scipy.sparse.csgraph.dijkstra(Wm, directed=False)
        pr0 = self._solve()[0]
        up = pr0[E[:, 1]] > pr0[E[:, 0]]                    # edge 0->1 goes upstream
        c_fwd = self.l / lam_c + np.where(up, 0.0, np.log(b_div))
        c_bwd = self.l / lam_c + np.where(up, np.log(b_div), 0.0)
        Cd = sp.coo_matrix((np.r_[c_fwd, c_bwd], (np.r_[E[:, 0], E[:, 1]], np.r_[E[:, 1], E[:, 0]])), shape=(self.n, self.n)).tocsr()
        cost = scipy.sparse.csgraph.dijkstra(Cd, directed=True)       # cost[n, m]: from source n to target m
        self.G = np.exp(-cost.T)                                    # G[m, n]
        self._hist = None

    def reset(self):
        self.phi = np.zeros(self.n); self.psi = np.zeros(self.n)
        self.ra = np.full(len(self.art), self.p['ra0']); self.k = np.full(self.n, self.p['k_rest'])
        self.blocked = np.zeros(len(self.art), bool)
        if getattr(self, '_hist', None) is not None: self._hist[:] = 0

    def _solve(self, ra=None, re=None, blocked=None):
        n, E = self.n, self.E
        re = np.full(len(E), self.p['r0']) if re is None else re
        ra = self.ra if ra is None else ra
        blocked = self.blocked if blocked is None else blocked
        Ge = re**4 / self.l
        M = sp.coo_matrix((np.r_[Ge, Ge, -Ge, -Ge], (np.r_[E[:, 0], E[:, 1], E[:, 0], E[:, 1]],
                                                       np.r_[E[:, 0], E[:, 1], E[:, 1], E[:, 0]])), shape=(n, n)).tolil()
        b = np.zeros(n)
        Ga = np.where(blocked, 0.0, self.c_a * ra**4)
        for node, g_ in zip(self.art, Ga):
            M[node, node] += g_; b[node] += g_ * 1.0
        Gv = 50.0 * self.p['r0']**4 / 50.0
        for node in self.ven:
            M[node, node] += Gv
        pr = spla.spsolve(M.tocsr(), b)
        q = Ge * (pr[E[:, 0]] - pr[E[:, 1]])
        node_flow = 0.5 * np.bincount(E.ravel(), weights=np.r_[np.abs(q), np.abs(q)], minlength=n)
        art_flow = Ga * (1.0 - pr[self.art])
        return pr, q, node_flow, art_flow

    def _calib_ca(self):
        r0 = self.p['r0']; ra0 = self.p['ra0']
        best, target = None, 0.5
        for ca in np.logspace(-6, 2, 33):
            self.c_a = ca; self.ra = np.full(len(self.art), ra0); self.blocked = np.zeros(len(self.art), bool)
            pr, *_ = self._solve()
            drop_art = 1 - pr[self.art].mean()          # pressure lost across the arteriole
            if best is None or abs(drop_art - target) < abs(best[1] - target): best = (ca, drop_art)
        return best[0]

    def capillary_radii(self):
        psi_e = 0.5 * (self.psi[self.E[:, 0]] + self.psi[self.E[:, 1]])
        return self.p['r0'] * (1 + self.p['beta_c'] * psi_e)

    def step(self, dt, k=None, activity=None, kir=True, pericyte=True):
        p = self.p
        if k is not None: self.k = k
        src = lambda kk: sig((kk - p['k_th']) / p['s_k']) * sig((p['k_off'] - kk) / p['s_off'])
        sK = p['A_K'] * (src(self.k) - src(p['k_rest'])) if kir else 0 * self.k     # source relative to rest
        if self._hist is None or self._hist_dt != dt:
            nh = int(np.ceil(self.Dpath[np.isfinite(self.Dpath)].max() / p['v_c'] / dt)) + 2
            self._hist = np.zeros((nh, self.n)); self._hist_dt = dt; self._ptr = 0
            self._lag = np.minimum(np.round(self.Dpath / p['v_c'] / dt).astype(int), nh - 1)
        self._ptr = (self._ptr + 1) % len(self._hist); self._hist[self._ptr] = sK
        active = np.where(np.abs(self._hist).max(0) > 1e-9)[0]
        if len(active):
            rows = (self._ptr - self._lag[:, active]) % len(self._hist)
            delayed = self._hist[rows, active[None, :]]
            self.phi = p['Phi_max'] * np.tanh((self.G[:, active] * delayed).sum(1) / p['Phi_max'])
        else:
            self.phi = np.zeros(self.n)
        q = np.zeros(self.n) if activity is None else activity
        if pericyte: self.psi += dt * (-self.psi + q) / p['tau_psi']
        target = p['ra0'] * (1 + p['beta_a'] * self.phi[self.art] / p['A_K'] + p['beta_d'] * (self.Wd @ self.psi))
        self.ra += dt * (target - self.ra) / p['tau_a']

    def flows(self):
        return self._solve(re=self.capillary_radii())

    def supply_kernel(self, X, ell=20.0):
        """row-normalised weights of each neuron (rows, positions X) on each capillary node."""
        tree = cKDTree(self.xy); d, j = tree.query(X, k=8)
        w = np.exp(-d / ell); w /= w.sum(1, keepdims=True)
        K = sp.coo_matrix((w.ravel(), (np.repeat(np.arange(len(X)), 8), j.ravel())), shape=(len(X), self.n)).tocsr()
        return K

    def bfs_depth(self, src):
        A = sp.coo_matrix((np.ones(2 * len(self.E)), (np.r_[self.E[:, 0], self.E[:, 1]], np.r_[self.E[:, 1], self.E[:, 0]])),
                          shape=(self.n, self.n)).tocsr()
        return sp.csgraph.shortest_path(A, unweighted=True, indices=src)
