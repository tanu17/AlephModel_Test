"""Model A.6 multi-substrate metabolism (replaces the lumped ATP equivalent e_i of A.2-A.5).

One tissue voxel (attached to a capillary node of the supply mesh) holds five pools, all in mM (= umol/g):
  G  tissue glucose            L  lactate (extracellular + astrocytic, fast-exchanging)
  Gam astrocytic glycogen (glucosyl units)          o  tissue O2
and the neuronal compartment holds
  p  neuronal pyruvate         a  neuronal ATP (the old e_i, now produced rather than supplied)

Fluxes (mM/s):
  J_G   = T_G [1 + gam_G (f - 1)] [G_b/(G_b+K_T) - G/(G+K_T)]   facilitated BBB transport (GLUT1); the exchange
                                                               surface grows with perfused capillary flow (gam_G)
  J_O   = J_O0 f E(f)/E0 (o_a - o)/(o_a - o_0)                 Buxton O2 delivery with tissue back-pressure
  J_L   = k_Lb (L - L_b)                                       lactate exchange with blood
  v_gn  = V_gn m(G,K_G) theta(a) [1 + chi_g (D/D0 - 1)]        neuronal glycolysis: ADP-driven, plus pump-coupled
                                                               (Na/K-ATPase draws preferentially on glycolytic ATP)
  v_ga  = m(G,K_G) (V_ga0 + phi V_glu u)                       astrocytic glycolysis, glutamate-driven (ANLS)
  v_syn = V_syn m(G,K_Gs) (1 - Gam/Gam_max)                   glycogen synthesis
  v_gly = V_gl Gam/(Gam+K_Gam) [1 + c_K (u-1)_+ + c_NE NE + c_h sigma((G_h-G)/s_h)
                                 + c_h2 sigma((G_h2-G)/s_h2)]  glycogenolysis (mild and severe glucose lack)
  v_ox  = V_ox m(p,K_p) m(o,K_o) theta(a)                      neuronal pyruvate oxidation (OXPHOS)
  v_ex  = k_ex (p - L/rho)                                     LDH + MCT exchange, pyruvate -> lactate if > 0
  D = D_set(t) m(a,K_aD)/m(a_0,K_aD)                          neuronal ATP demand; falls as ATP falls (the pump and
                                                               housekeeping terms of A.2 carry the factor m(e))
with theta(a) = (a_max - a)/(a_max - a + K_d) (respiratory control by ADP), m(z,K) = z/(z+K).

Balances:
  dG/dt   = J_G - v_gn - v_ga - v_syn
  dL/dt   = 2 (v_ga + v_gly) + v_ex - J_L
  dGam/dt = v_syn - v_gly
  dp/dt   = 2 v_gn - v_ox - v_ex
  c_O do/dt = J_O - 3 v_ox
  da/dt   = 2 v_gn + Y_ox v_ox - D(t)              (Y_ox = 14.5 ATP per pyruvate oxidised)
Carbon ledger (glucose units): d/dt[G + Gam + (L+p)/2] = J_G - J_L/2 - v_ox/2  (exact).
Oxygen ledger: c_O do/dt = J_O - 3 v_ox (exact).
Measured quantities: CMRglc = J_G, CMRO2 = J_O, OGI = J_O / J_G (at steady state).
"""
import numpy as np

m = lambda z, K: z / (z + K)
sig = lambda z: 1 / (1 + np.exp(-z))

REST = dict(G=1.2, L=0.8, Gam=7.0, o=0.035, a=2.5)
TARGET = dict(CMRglc=0.30 / 60, OGI=5.3, aerobic_glycolysis=0.117, glycogen_turnover=0.35 / 3600,
              astro_share=0.30)

def calibrate(phi=1.0, astro_share=0.30, G_b=5.0, L_b=0.6, o_a=0.10, K_T=5.0, K_G=0.5, K_Gs=1.0,
              a_max=3.0, K_d=0.3, K_p=0.05, K_o=0.003, k_ex=1.0, K_aD=0.5, rho=10.0, Gam_max=12.0, K_Gam=2.0,
              E0=0.4, c_O=1.0, Y_ox=14.5, c_K=1.5, c_NE=0.0, c_h=4.0, G_h=0.4, s_h=0.1,
              chi_g=0.0, c_h2=40.0, G_h2=0.12, s_h2=0.03, gam_G=0.5):
    """Solve the rest state for the parameters that reproduce the resting targets exactly."""
    G, L, Gam, o, a = REST['G'], REST['L'], REST['Gam'], REST['o'], REST['a']
    cmr = TARGET['CMRglc']; ox_frac = 1 - TARGET['aerobic_glycolysis']
    v_ox = 2 * cmr * ox_frac                               # pyruvate oxidised per s
    J_L = 2 * cmr * TARGET['aerobic_glycolysis']
    v_gly = v_syn = TARGET['glycogen_turnover']
    glyc_total = cmr                                       # all glucose taken up is glycolysed at steady state
    astro = astro_share * glyc_total
    v_ga = astro - v_gly
    v_gn = glyc_total - astro
    v_ex = 2 * v_gn - v_ox                                 # neuronal pyruvate balance -> net export (<0: import)
    p = L / rho + v_ex / k_ex
    th = (a_max - a) / (a_max - a + K_d)
    P = dict(G_b=G_b, L_b=L_b, o_a=o_a, o0=o, K_T=K_T, K_G=K_G, K_Gs=K_Gs, a_max=a_max, K_d=K_d, K_p=K_p,
             K_o=K_o, k_ex=k_ex, K_aD=K_aD, rho=rho, Gam_max=Gam_max, K_Gam=K_Gam, E0=E0, c_O=c_O, Y_ox=Y_ox,
             c_K=c_K, c_NE=c_NE, c_h=c_h, G_h=G_h, s_h=s_h, phi=phi, chi_g=chi_g, c_h2=c_h2, G_h2=G_h2, s_h2=s_h2, gam_G=gam_G)
    P['T_G'] = cmr / (G_b / (G_b + K_T) - G / (G + K_T))
    P['k_Lb'] = J_L / (L - L_b)
    P['J_O0'] = 3 * v_ox
    P['V_gn'] = v_gn / (m(G, K_G) * th)
    # astrocytic glycolysis: a basal part plus a glutamate-driven part; phi = share that is glutamate-driven
    P['V_glu'] = v_ga / m(G, K_G)                          # at u = 1 (rest), glutamate-driven + basal = v_ga
    P['V_ga0'] = (1 - phi) * P['V_glu']
    P['V_ox'] = v_ox / (m(p, K_p) * m(o, K_o) * th)
    P['V_syn'] = v_syn / (m(G, K_Gs) * (1 - Gam / Gam_max))
    hypo0 = c_h * sig((G_h - G) / s_h) + c_h2 * sig((G_h2 - G) / s_h2)
    P['V_gl'] = v_gly / (m(Gam, K_Gam) * (1 + hypo0))
    P['D0'] = 2 * v_gn + Y_ox * v_ox
    P['a0'] = a
    x0 = np.array([G, L, Gam, p, o, a])
    return P, x0

def fluxes(x, P, f=1.0, u=1.0, D=None, NE=0.0, G_b=None, L_b=None):
    G, L, Gam, p, o, a = [np.maximum(v, 0.0) for v in x]
    Gb = P['G_b'] if G_b is None else G_b
    th = np.maximum(P['a_max'] - a, 0) / (np.maximum(P['a_max'] - a, 0) + P['K_d'])
    E = 1 - (1 - P['E0'])**(1.0 / np.maximum(f, 1e-3))
    J_G = P['T_G'] * (1 + P['gam_G'] * (f - 1)) * (Gb / (Gb + P['K_T']) - G / (G + P['K_T']))
    J_O = P['J_O0'] * f * E / P['E0'] * (P['o_a'] - o) / (P['o_a'] - P['o0'])
    J_L = P['k_Lb'] * (L - (P['L_b'] if L_b is None else L_b))
    Dset = P['D0'] if D is None else D
    Dn = Dset * m(a, P['K_aD']) / m(P['a0'], P['K_aD'])
    v_gn = P['V_gn'] * m(G, P['K_G']) * th * np.maximum(1 + P['chi_g'] * (Dset / P['D0'] - 1), 0)
    v_ga = m(G, P['K_G']) * (P['V_ga0'] + P['phi'] * P['V_glu'] * u)
    v_syn = P['V_syn'] * m(G, P['K_Gs']) * (1 - Gam / P['Gam_max'])
    v_gly = P['V_gl'] * m(Gam, P['K_Gam']) * (1 + P['c_K'] * np.maximum(u - 1, 0) + P['c_NE'] * NE
                                             + P['c_h'] * sig((P['G_h'] - G) / P['s_h'])
                                             + P['c_h2'] * sig((P['G_h2'] - G) / P['s_h2']))
    v_ox = P['V_ox'] * m(p, P['K_p']) * m(o, P['K_o']) * th
    v_ex = P['k_ex'] * (p - L / P['rho'])
    return dict(J_G=J_G, J_O=J_O, J_L=J_L, v_gn=v_gn, v_ga=v_ga, v_syn=v_syn, v_gly=v_gly, v_ox=v_ox, v_ex=v_ex, D=Dn)

def rhs(x, P, **kw):
    F = fluxes(x, P, **kw)
    dG = F['J_G'] - F['v_gn'] - F['v_ga'] - F['v_syn']
    dL = 2 * (F['v_ga'] + F['v_gly']) + F['v_ex'] - F['J_L']
    dGam = F['v_syn'] - F['v_gly']
    dp = 2 * F['v_gn'] - F['v_ox'] - F['v_ex']
    do = (F['J_O'] - 3 * F['v_ox']) / P['c_O']
    da = 2 * F['v_gn'] + P['Y_ox'] * F['v_ox'] - F['D']
    return np.array([dG, dL, dGam, dp, do, da]), F

def simulate(P, x0, T, dt=0.02, drive=None, record_every=1.0):
    """drive(t) -> dict(f=, u=, D=, NE=, G_b=). Returns times, states, fluxes (recorded every record_every s)."""
    x = x0.copy(); out_t, out_x, out_F = [], [], []
    n_rec = max(1, int(round(record_every / dt)))
    for k in range(int(round(T / dt))):
        t = k * dt
        kw = drive(t) if drive else {}
        dx, F = rhs(x, P, **kw)
        x = np.maximum(x + dt * dx, 0.0)
        if k % n_rec == 0:
            out_t.append(t); out_x.append(x.copy()); out_F.append(F)
    return np.array(out_t), np.array(out_x), out_F

def carbon(x):
    G, L, Gam, p, o, a = x
    return G + Gam + (L + p) / 2
